export interface IUploadFile {
    filename: string;
    data: string;
    fieldName: string;
    mimeType: string;
    _ext: string;
}
