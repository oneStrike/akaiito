"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SocialCircleController = void 0;
const base_controller_1 = require("../../shared/controller/base.controller");
const core_1 = require("@midwayjs/core");
const socialCircle_service_1 = require("../../service/socialCircle/socialCircle.service");
const socialCircle_dto_1 = require("../../service/socialCircle/dto/socialCircle.dto");
const base_dto_1 = require("../../shared/dto/base.dto");
let SocialCircleController = class SocialCircleController extends base_controller_1.BaseController {
    async getSocialCirclePageDto(query) {
        return await this.socialCircleService.getSocialCirclePage(query, true);
    }
    async getSocialCircleDetail({ id }) {
        return await this.socialCircleService.findByPk(id);
    }
    async getSocialCircleClassifyList() {
        return await this.socialCircleService.classifyMapping.findAll();
    }
    async createSocialCircle(body) {
        body.status = 1;
        return await this.socialCircleService.createSocialCircle(body);
    }
    async uploadSocialCircle(body) {
        return await this.socialCircleService.update(body, body.id);
    }
    async deleteSocialCircle(body) {
        return await this.socialCircleService.destroy(body.id);
    }
};
__decorate([
    (0, core_1.Inject)(),
    __metadata("design:type", socialCircle_service_1.SocialCircleService)
], SocialCircleController.prototype, "socialCircleService", void 0);
__decorate([
    (0, core_1.Get)("/getSocialCirclePage", { summary: "获取圈子分页列表" }),
    __param(0, (0, core_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [socialCircle_dto_1.getSocialCirclePageDto]),
    __metadata("design:returntype", Promise)
], SocialCircleController.prototype, "getSocialCirclePageDto", null);
__decorate([
    (0, core_1.Get)("/getSocialCircleDetail", { summary: "获取圈子详情" }),
    __param(0, (0, core_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [base_dto_1.IdDto]),
    __metadata("design:returntype", Promise)
], SocialCircleController.prototype, "getSocialCircleDetail", null);
__decorate([
    (0, core_1.Get)("/getSocialCircleClassifyList", { summary: "获取圈子分类列表" }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], SocialCircleController.prototype, "getSocialCircleClassifyList", null);
__decorate([
    (0, core_1.Post)("/createSocialCircle", { summary: "创建圈子" }),
    __param(0, (0, core_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [socialCircle_dto_1.CreateClientSocialCircleDto]),
    __metadata("design:returntype", Promise)
], SocialCircleController.prototype, "createSocialCircle", null);
__decorate([
    (0, core_1.Post)("/updateSocialCircle", { summary: "更新圈子" }),
    __param(0, (0, core_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [socialCircle_dto_1.UpdateSocialCircleDto]),
    __metadata("design:returntype", Promise)
], SocialCircleController.prototype, "uploadSocialCircle", null);
__decorate([
    (0, core_1.Post)("/deleteSocialCircle", { summary: "删除圈子" }),
    __param(0, (0, core_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [base_dto_1.IdDto]),
    __metadata("design:returntype", Promise)
], SocialCircleController.prototype, "deleteSocialCircle", null);
SocialCircleController = __decorate([
    (0, core_1.Controller)("/client/socialCircle")
], SocialCircleController);
exports.SocialCircleController = SocialCircleController;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic29jaWFsQ2lyY2xlLmNvbnRyb2xsZXIuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi9zcmMvY29udHJvbGxlci9jbGllbnQvc29jaWFsQ2lyY2xlLmNvbnRyb2xsZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7O0FBQUEsNkVBQXlFO0FBQ3pFLHlDQUE0RTtBQUM1RSwwRkFBc0Y7QUFDdEYsc0ZBSXlEO0FBQ3pELHdEQUFrRDtBQUkzQyxJQUFNLHNCQUFzQixHQUE1QixNQUFNLHNCQUF1QixTQUFRLGdDQUFjO0lBS2xELEFBQU4sS0FBSyxDQUFDLHNCQUFzQixDQUFVLEtBQTZCO1FBQ2pFLE9BQU8sTUFBTSxJQUFJLENBQUMsbUJBQW1CLENBQUMsbUJBQW1CLENBQUMsS0FBSyxFQUFFLElBQUksQ0FBQyxDQUFDO0lBQ3pFLENBQUM7SUFHSyxBQUFOLEtBQUssQ0FBQyxxQkFBcUIsQ0FBVSxFQUFFLEVBQUUsRUFBUztRQUNoRCxPQUFPLE1BQU0sSUFBSSxDQUFDLG1CQUFtQixDQUFDLFFBQVEsQ0FBQyxFQUFFLENBQUMsQ0FBQztJQUNyRCxDQUFDO0lBR0ssQUFBTixLQUFLLENBQUMsMkJBQTJCO1FBQy9CLE9BQU8sTUFBTSxJQUFJLENBQUMsbUJBQW1CLENBQUMsZUFBZSxDQUFDLE9BQU8sRUFBRSxDQUFDO0lBQ2xFLENBQUM7SUFHSyxBQUFOLEtBQUssQ0FBQyxrQkFBa0IsQ0FBUyxJQUFpQztRQUNoRSxJQUFJLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQztRQUNoQixPQUFPLE1BQU0sSUFBSSxDQUFDLG1CQUFtQixDQUFDLGtCQUFrQixDQUFDLElBQUksQ0FBQyxDQUFDO0lBQ2pFLENBQUM7SUFHSyxBQUFOLEtBQUssQ0FBQyxrQkFBa0IsQ0FBUyxJQUEyQjtRQUMxRCxPQUFPLE1BQU0sSUFBSSxDQUFDLG1CQUFtQixDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDO0lBQzlELENBQUM7SUFHSyxBQUFOLEtBQUssQ0FBQyxrQkFBa0IsQ0FBUyxJQUFXO1FBQzFDLE9BQU8sTUFBTSxJQUFJLENBQUMsbUJBQW1CLENBQUMsT0FBTyxDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQztJQUN6RCxDQUFDO0NBQ0YsQ0FBQTtBQWpDQztJQUFDLElBQUEsYUFBTSxHQUFFOzhCQUNZLDBDQUFtQjttRUFBQztBQUduQztJQURMLElBQUEsVUFBRyxFQUFDLHNCQUFzQixFQUFFLEVBQUUsT0FBTyxFQUFFLFVBQVUsRUFBRSxDQUFDO0lBQ3ZCLFdBQUEsSUFBQSxZQUFLLEdBQUUsQ0FBQTs7cUNBQVEseUNBQXNCOztvRUFFbEU7QUFHSztJQURMLElBQUEsVUFBRyxFQUFDLHdCQUF3QixFQUFFLEVBQUUsT0FBTyxFQUFFLFFBQVEsRUFBRSxDQUFDO0lBQ3hCLFdBQUEsSUFBQSxZQUFLLEdBQUUsQ0FBQTs7cUNBQVMsZ0JBQUs7O21FQUVqRDtBQUdLO0lBREwsSUFBQSxVQUFHLEVBQUMsOEJBQThCLEVBQUUsRUFBRSxPQUFPLEVBQUUsVUFBVSxFQUFFLENBQUM7Ozs7eUVBRzVEO0FBR0s7SUFETCxJQUFBLFdBQUksRUFBQyxxQkFBcUIsRUFBRSxFQUFFLE9BQU8sRUFBRSxNQUFNLEVBQUUsQ0FBQztJQUN2QixXQUFBLElBQUEsV0FBSSxHQUFFLENBQUE7O3FDQUFPLDhDQUEyQjs7Z0VBR2pFO0FBR0s7SUFETCxJQUFBLFdBQUksRUFBQyxxQkFBcUIsRUFBRSxFQUFFLE9BQU8sRUFBRSxNQUFNLEVBQUUsQ0FBQztJQUN2QixXQUFBLElBQUEsV0FBSSxHQUFFLENBQUE7O3FDQUFPLHdDQUFxQjs7Z0VBRTNEO0FBR0s7SUFETCxJQUFBLFdBQUksRUFBQyxxQkFBcUIsRUFBRSxFQUFFLE9BQU8sRUFBRSxNQUFNLEVBQUUsQ0FBQztJQUN2QixXQUFBLElBQUEsV0FBSSxHQUFFLENBQUE7O3FDQUFPLGdCQUFLOztnRUFFM0M7QUFqQ1Usc0JBQXNCO0lBRGxDLElBQUEsaUJBQVUsRUFBQyxzQkFBc0IsQ0FBQztHQUN0QixzQkFBc0IsQ0FrQ2xDO0FBbENZLHdEQUFzQiJ9