import { BaseController } from "../../shared/controller/base.controller";
import { SocialCircleService } from "../../service/socialCircle/socialCircle.service";
import { CreateClientSocialCircleDto, getSocialCirclePageDto, UpdateSocialCircleDto } from "../../service/socialCircle/dto/socialCircle.dto";
import { IdDto } from "../../shared/dto/base.dto";
export declare class SocialCircleController extends BaseController {
    socialCircleService: SocialCircleService;
    getSocialCirclePageDto(query: getSocialCirclePageDto): Promise<import("../../types/dto/list").ListResponseRes<import("sequelize-typescript").Model<any, any>>>;
    getSocialCircleDetail({ id }: IdDto): Promise<import("sequelize-typescript").Model<any, any>>;
    getSocialCircleClassifyList(): Promise<import("sequelize-typescript").Model<any, any>[]>;
    createSocialCircle(body: CreateClientSocialCircleDto): Promise<any>;
    uploadSocialCircle(body: UpdateSocialCircleDto): Promise<number | number[]>;
    deleteSocialCircle(body: IdDto): Promise<number | number[]>;
}
