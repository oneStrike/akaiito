import { BaseController } from '../../../shared/controller/base.controller';
import { PageService } from '../../../service/clientManage/page/page.service';
export declare class ManageController extends BaseController {
    pageService: PageService;
    getPage(): Promise<import("sequelize-typescript").Model<any, any>[]>;
}
