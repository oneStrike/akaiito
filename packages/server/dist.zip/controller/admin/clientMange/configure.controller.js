"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ConfigureController = void 0;
const base_controller_1 = require("../../../shared/controller/base.controller");
const core_1 = require("@midwayjs/core");
const configure_dto_1 = require("../../../service/clientManage/configure/dto/configure.dto");
const configure_service_1 = require("../../../service/clientManage/configure/configure.service");
const fs = require("fs");
let ConfigureController = class ConfigureController extends base_controller_1.BaseController {
    async getConfigure() {
        return this.configureService.getConfigure();
    }
    async updateConfigure(body) {
        return this.configureService.uploadConfigure(body);
    }
    async exportClientPackage() {
        const filePath = await this.configureService.exportClientPackage();
        return fs.createReadStream(filePath);
    }
};
__decorate([
    (0, core_1.Inject)(),
    __metadata("design:type", configure_service_1.ConfigureService)
], ConfigureController.prototype, "configureService", void 0);
__decorate([
    (0, core_1.Get)("/getClientConfig", { summary: "获取客户端配置" }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], ConfigureController.prototype, "getConfigure", null);
__decorate([
    (0, core_1.Post)("/updateClientConfig", { summary: "更新客户端配置" }),
    __param(0, (0, core_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [configure_dto_1.ClientConfigureDto]),
    __metadata("design:returntype", Promise)
], ConfigureController.prototype, "updateConfigure", null);
__decorate([
    (0, core_1.Get)("/exportClientPackage", { summary: "导出客户端代码包" }),
    (0, core_1.SetHeader)({
        "content-type": "application/octet-stream",
        "Content-Disposition": "attachment",
        "filename": "clientPackage.zip"
    }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], ConfigureController.prototype, "exportClientPackage", null);
ConfigureController = __decorate([
    (0, core_1.Controller)("admin/clientManage")
], ConfigureController);
exports.ConfigureController = ConfigureController;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29uZmlndXJlLmNvbnRyb2xsZXIuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zcmMvY29udHJvbGxlci9hZG1pbi9jbGllbnRNYW5nZS9jb25maWd1cmUuY29udHJvbGxlci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7QUFBQSxnRkFBNEU7QUFDNUUseUNBQWdGO0FBQ2hGLDZGQUErRjtBQUMvRixpR0FBNkY7QUFDN0YseUJBQXlCO0FBR2xCLElBQU0sbUJBQW1CLEdBQXpCLE1BQU0sbUJBQW9CLFNBQVEsZ0NBQWM7SUFLL0MsQUFBTixLQUFLLENBQUMsWUFBWTtRQUNoQixPQUFPLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxZQUFZLEVBQUUsQ0FBQztJQUM5QyxDQUFDO0lBR0ssQUFBTixLQUFLLENBQUMsZUFBZSxDQUFTLElBQXdCO1FBQ3BELE9BQU8sSUFBSSxDQUFDLGdCQUFnQixDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUNyRCxDQUFDO0lBUUssQUFBTixLQUFLLENBQUMsbUJBQW1CO1FBQ3ZCLE1BQU0sUUFBUSxHQUFHLE1BQU0sSUFBSSxDQUFDLGdCQUFnQixDQUFDLG1CQUFtQixFQUFFLENBQUM7UUFDbkUsT0FBTyxFQUFFLENBQUMsZ0JBQWdCLENBQUMsUUFBUSxDQUFDLENBQUE7SUFDdEMsQ0FBQztDQUNGLENBQUE7QUF2QkM7SUFBQyxJQUFBLGFBQU0sR0FBRTs4QkFDUyxvQ0FBZ0I7NkRBQUM7QUFHN0I7SUFETCxJQUFBLFVBQUcsRUFBQyxrQkFBa0IsRUFBRSxFQUFFLE9BQU8sRUFBRSxTQUFTLEVBQUUsQ0FBQzs7Ozt1REFHL0M7QUFHSztJQURMLElBQUEsV0FBSSxFQUFDLHFCQUFxQixFQUFFLEVBQUUsT0FBTyxFQUFFLFNBQVMsRUFBRSxDQUFDO0lBQzdCLFdBQUEsSUFBQSxXQUFJLEdBQUUsQ0FBQTs7cUNBQU8sa0NBQWtCOzswREFFckQ7QUFRSztJQU5MLElBQUEsVUFBRyxFQUFDLHNCQUFzQixFQUFFLEVBQUUsT0FBTyxFQUFFLFVBQVUsRUFBRSxDQUFDO0lBQ3BELElBQUEsZ0JBQVMsRUFBQztRQUNULGNBQWMsRUFBRSwwQkFBMEI7UUFDMUMscUJBQXFCLEVBQUUsWUFBWTtRQUNuQyxVQUFVLEVBQUUsbUJBQW1CO0tBQ2hDLENBQUM7Ozs7OERBSUQ7QUF2QlUsbUJBQW1CO0lBRC9CLElBQUEsaUJBQVUsRUFBQyxvQkFBb0IsQ0FBQztHQUNwQixtQkFBbUIsQ0F3Qi9CO0FBeEJZLGtEQUFtQiJ9