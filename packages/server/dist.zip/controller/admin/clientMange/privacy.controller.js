"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PrivacyController = void 0;
const core_1 = require("@midwayjs/core");
const base_controller_1 = require("../../../shared/controller/base.controller");
const privacy_service_1 = require("../../../service/privacy/privacy.service");
const privacy_dto_1 = require("../../../service/privacy/dto/privacy.dto");
const base_dto_1 = require("../../../shared/dto/base.dto");
let PrivacyController = class PrivacyController extends base_controller_1.BaseController {
    async getPrivacyPage(params) {
        return this.privacyService.getPrivacyList(params);
    }
    async getPrivacyDetail(query) {
        return this.privacyService.findByPk(query.id);
    }
    async addPrivacy(body) {
        return this.privacyService.create(body);
    }
    async toggleState(body) {
        return this.privacyService.update(body, body.ids);
    }
    async deletePrivacy(body) {
        return this.privacyService.destroy(body.ids);
    }
    async updatePrivacy(body) {
        return this.privacyService.update(body, body.id);
    }
};
__decorate([
    (0, core_1.Inject)(),
    __metadata("design:type", privacy_service_1.PrivacyService)
], PrivacyController.prototype, "privacyService", void 0);
__decorate([
    (0, core_1.Get)('/getPrivacyPage', { summary: '获取隐私申明列表' }),
    __param(0, (0, core_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [privacy_dto_1.GetPrivacyDto]),
    __metadata("design:returntype", Promise)
], PrivacyController.prototype, "getPrivacyPage", null);
__decorate([
    (0, core_1.Get)('/getPrivacyDetail', { summary: '获取隐私声明详情' }),
    __param(0, (0, core_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [base_dto_1.IdDto]),
    __metadata("design:returntype", Promise)
], PrivacyController.prototype, "getPrivacyDetail", null);
__decorate([
    (0, core_1.Post)('/addPrivacy', { summary: '添加隐私声明' }),
    __param(0, (0, core_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [privacy_dto_1.AddPrivacyDto]),
    __metadata("design:returntype", Promise)
], PrivacyController.prototype, "addPrivacy", null);
__decorate([
    (0, core_1.Post)('/switchPrivacyStatus', { summary: '启用或禁用隐私声明' }),
    __param(0, (0, core_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [base_dto_1.ToggleStatusDto]),
    __metadata("design:returntype", Promise)
], PrivacyController.prototype, "toggleState", null);
__decorate([
    (0, core_1.Post)('/deletePrivacy', { summary: '删除隐私声明' }),
    __param(0, (0, core_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [base_dto_1.IdsDto]),
    __metadata("design:returntype", Promise)
], PrivacyController.prototype, "deletePrivacy", null);
__decorate([
    (0, core_1.Post)('/updatePrivacy', { summary: '更新隐私声明' }),
    __param(0, (0, core_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", Promise)
], PrivacyController.prototype, "updatePrivacy", null);
PrivacyController = __decorate([
    (0, core_1.Controller)('/admin/privacy')
], PrivacyController);
exports.PrivacyController = PrivacyController;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHJpdmFjeS5jb250cm9sbGVyLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL2NvbnRyb2xsZXIvYWRtaW4vY2xpZW50TWFuZ2UvcHJpdmFjeS5jb250cm9sbGVyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7OztBQUFBLHlDQUEyRTtBQUMzRSxnRkFBMkU7QUFDM0UsOEVBQXlFO0FBQ3pFLDBFQUdpRDtBQUNqRCwyREFBNkU7QUFHdEUsSUFBTSxpQkFBaUIsR0FBdkIsTUFBTSxpQkFBa0IsU0FBUSxnQ0FBYztJQUs3QyxBQUFOLEtBQUssQ0FBQyxjQUFjLENBQVUsTUFBcUI7UUFDakQsT0FBTyxJQUFJLENBQUMsY0FBYyxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsQ0FBQTtJQUNuRCxDQUFDO0lBR0ssQUFBTixLQUFLLENBQUMsZ0JBQWdCLENBQVUsS0FBWTtRQUMxQyxPQUFPLElBQUksQ0FBQyxjQUFjLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsQ0FBQTtJQUMvQyxDQUFDO0lBR0ssQUFBTixLQUFLLENBQUMsVUFBVSxDQUFTLElBQW1CO1FBQzFDLE9BQU8sSUFBSSxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLENBQUE7SUFDekMsQ0FBQztJQUdLLEFBQU4sS0FBSyxDQUFDLFdBQVcsQ0FBUyxJQUFxQjtRQUM3QyxPQUFPLElBQUksQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsR0FBRyxDQUFDLENBQUE7SUFDbkQsQ0FBQztJQUdLLEFBQU4sS0FBSyxDQUFDLGFBQWEsQ0FBUyxJQUFZO1FBQ3RDLE9BQU8sSUFBSSxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEdBQUcsQ0FBQyxDQUFBO0lBQzlDLENBQUM7SUFFSyxBQUFOLEtBQUssQ0FBQyxhQUFhLENBQVMsSUFBMkI7UUFDckQsT0FBTyxJQUFJLENBQUMsY0FBYyxDQUFDLE1BQU0sQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFBO0lBQ2xELENBQUM7Q0FDRixDQUFBO0FBL0JDO0lBQUMsSUFBQSxhQUFNLEdBQUU7OEJBQ08sZ0NBQWM7eURBQUE7QUFHeEI7SUFETCxJQUFBLFVBQUcsRUFBQyxpQkFBaUIsRUFBRSxFQUFFLE9BQU8sRUFBRSxVQUFVLEVBQUUsQ0FBQztJQUMxQixXQUFBLElBQUEsWUFBSyxHQUFFLENBQUE7O3FDQUFTLDJCQUFhOzt1REFFbEQ7QUFHSztJQURMLElBQUEsVUFBRyxFQUFDLG1CQUFtQixFQUFFLEVBQUUsT0FBTyxFQUFFLFVBQVUsRUFBRSxDQUFDO0lBQzFCLFdBQUEsSUFBQSxZQUFLLEdBQUUsQ0FBQTs7cUNBQVEsZ0JBQUs7O3lEQUUzQztBQUdLO0lBREwsSUFBQSxXQUFJLEVBQUMsYUFBYSxFQUFFLEVBQUUsT0FBTyxFQUFFLFFBQVEsRUFBRSxDQUFDO0lBQ3pCLFdBQUEsSUFBQSxXQUFJLEdBQUUsQ0FBQTs7cUNBQU8sMkJBQWE7O21EQUUzQztBQUdLO0lBREwsSUFBQSxXQUFJLEVBQUMsc0JBQXNCLEVBQUUsRUFBRSxPQUFPLEVBQUUsV0FBVyxFQUFFLENBQUM7SUFDcEMsV0FBQSxJQUFBLFdBQUksR0FBRSxDQUFBOztxQ0FBTywwQkFBZTs7b0RBRTlDO0FBR0s7SUFETCxJQUFBLFdBQUksRUFBQyxnQkFBZ0IsRUFBRSxFQUFFLE9BQU8sRUFBRSxRQUFRLEVBQUUsQ0FBQztJQUN6QixXQUFBLElBQUEsV0FBSSxHQUFFLENBQUE7O3FDQUFPLGlCQUFNOztzREFFdkM7QUFFSztJQURMLElBQUEsV0FBSSxFQUFDLGdCQUFnQixFQUFFLEVBQUUsT0FBTyxFQUFFLFFBQVEsRUFBRSxDQUFDO0lBQ3pCLFdBQUEsSUFBQSxXQUFJLEdBQUUsQ0FBQTs7OztzREFFMUI7QUEvQlUsaUJBQWlCO0lBRDdCLElBQUEsaUJBQVUsRUFBQyxnQkFBZ0IsQ0FBQztHQUNoQixpQkFBaUIsQ0FnQzdCO0FBaENZLDhDQUFpQiJ9