import { BaseController } from '../../../shared/controller/base.controller';
import { PageService } from '../../../service/clientManage/page/page.service';
import { updatePageDto } from '../../../service/clientManage/page/dto/page.dto';
export declare class PageController extends BaseController {
    pageService: PageService;
    getClientPageList(): Promise<import("sequelize-typescript").Model<any, any>[]>;
    modifyClientPage(body: updatePageDto): Promise<number | number[]>;
}
