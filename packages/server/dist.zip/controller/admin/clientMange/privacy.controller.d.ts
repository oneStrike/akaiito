import { BaseController } from '../../../shared/controller/base.controller';
import { PrivacyService } from '../../../service/privacy/privacy.service';
import { AddPrivacyDto, GetPrivacyDto } from '../../../service/privacy/dto/privacy.dto';
import { IdDto, IdsDto, ToggleStatusDto } from '../../../shared/dto/base.dto';
export declare class PrivacyController extends BaseController {
    privacyService: PrivacyService;
    getPrivacyPage(params: GetPrivacyDto): Promise<import("../../../types/dto/list").ListResponseRes<import("sequelize-typescript").Model<any, any>>>;
    getPrivacyDetail(query: IdDto): Promise<import("sequelize-typescript").Model<any, any>>;
    addPrivacy(body: AddPrivacyDto): Promise<number>;
    toggleState(body: ToggleStatusDto): Promise<number | number[]>;
    deletePrivacy(body: IdsDto): Promise<number | number[]>;
    updatePrivacy(body: IdDto & AddPrivacyDto): Promise<number | number[]>;
}
