/// <reference types="node" />
import { BaseController } from "../../../shared/controller/base.controller";
import { ClientConfigureDto } from "../../../service/clientManage/configure/dto/configure.dto";
import { ConfigureService } from "../../../service/clientManage/configure/configure.service";
import * as fs from "fs";
export declare class ConfigureController extends BaseController {
    configureService: ConfigureService;
    getConfigure(): Promise<{
        privacyTitle: any;
        privacyMessage: any;
        privacySecondTitle: any;
        privacySecondMessage: any;
    }>;
    updateConfigure(body: ClientConfigureDto): Promise<any>;
    exportClientPackage(): Promise<fs.ReadStream>;
}
