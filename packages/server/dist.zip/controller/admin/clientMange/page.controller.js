"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PageController = void 0;
const core_1 = require("@midwayjs/core");
const base_controller_1 = require("../../../shared/controller/base.controller");
const page_service_1 = require("../../../service/clientManage/page/page.service");
const page_dto_1 = require("../../../service/clientManage/page/dto/page.dto");
let PageController = class PageController extends base_controller_1.BaseController {
    async getClientPageList() {
        return await this.pageService.findAll();
    }
    async modifyClientPage(body) {
        return await this.pageService.update(body, body.id);
    }
};
__decorate([
    (0, core_1.Inject)(),
    __metadata("design:type", page_service_1.PageService)
], PageController.prototype, "pageService", void 0);
__decorate([
    (0, core_1.Get)('/getClientPage', { summary: '获取客户端页面列表' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], PageController.prototype, "getClientPageList", null);
__decorate([
    (0, core_1.Post)('/updateClientPage', { summary: '修改客户端页面信息' }),
    __param(0, (0, core_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [page_dto_1.updatePageDto]),
    __metadata("design:returntype", Promise)
], PageController.prototype, "modifyClientPage", null);
PageController = __decorate([
    (0, core_1.Controller)('/admin/clientManage')
], PageController);
exports.PageController = PageController;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGFnZS5jb250cm9sbGVyLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL2NvbnRyb2xsZXIvYWRtaW4vY2xpZW50TWFuZ2UvcGFnZS5jb250cm9sbGVyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7OztBQUFBLHlDQUFvRTtBQUNwRSxnRkFBMkU7QUFDM0Usa0ZBQTZFO0FBQzdFLDhFQUErRTtBQUd4RSxJQUFNLGNBQWMsR0FBcEIsTUFBTSxjQUFlLFNBQVEsZ0NBQWM7SUFLMUMsQUFBTixLQUFLLENBQUMsaUJBQWlCO1FBQ3JCLE9BQU8sTUFBTSxJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sRUFBRSxDQUFBO0lBQ3pDLENBQUM7SUFHSyxBQUFOLEtBQUssQ0FBQyxnQkFBZ0IsQ0FBUyxJQUFtQjtRQUNoRCxPQUFPLE1BQU0sSUFBSSxDQUFDLFdBQVcsQ0FBQyxNQUFNLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQTtJQUNyRCxDQUFDO0NBQ0YsQ0FBQTtBQVpDO0lBQUMsSUFBQSxhQUFNLEdBQUU7OEJBQ0ksMEJBQVc7bURBQUE7QUFHbEI7SUFETCxJQUFBLFVBQUcsRUFBQyxnQkFBZ0IsRUFBRSxFQUFFLE9BQU8sRUFBRSxXQUFXLEVBQUUsQ0FBQzs7Ozt1REFHL0M7QUFHSztJQURMLElBQUEsV0FBSSxFQUFDLG1CQUFtQixFQUFFLEVBQUUsT0FBTyxFQUFFLFdBQVcsRUFBRSxDQUFDO0lBQzVCLFdBQUEsSUFBQSxXQUFJLEdBQUUsQ0FBQTs7cUNBQU8sd0JBQWE7O3NEQUVqRDtBQVpVLGNBQWM7SUFEMUIsSUFBQSxpQkFBVSxFQUFDLHFCQUFxQixDQUFDO0dBQ3JCLGNBQWMsQ0FhMUI7QUFiWSx3Q0FBYyJ9