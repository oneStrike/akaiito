"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.LogController = void 0;
const core_1 = require("@midwayjs/core");
const base_controller_1 = require("../../shared/controller/base.controller");
const log_service_1 = require("../../service/admin/log/log.service");
const loginLog_dto_1 = require("../../service/admin/log/dto/loginLog.dto");
const serialize_decorator_1 = require("../../decorator/serialize.decorator");
let LogController = class LogController extends base_controller_1.BaseController {
    async loginLog(query) {
        return await this.logService.findLoginLog(query);
    }
};
LogController.pure = ['path'];
__decorate([
    (0, core_1.Inject)(),
    __metadata("design:type", log_service_1.LogService)
], LogController.prototype, "logService", void 0);
__decorate([
    (0, core_1.Get)('/loginLog', { summary: '获取登录日志' }),
    (0, serialize_decorator_1.Serialize)('list'),
    __param(0, (0, core_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [loginLog_dto_1.LoginLogDto]),
    __metadata("design:returntype", Promise)
], LogController.prototype, "loginLog", null);
LogController = __decorate([
    (0, core_1.Controller)('/admin/log')
], LogController);
exports.LogController = LogController;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibG9nLmNvbnRyb2xsZXIuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi9zcmMvY29udHJvbGxlci9hZG1pbi9sb2cuY29udHJvbGxlci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7QUFBQSx5Q0FBK0Q7QUFDL0QsNkVBQXdFO0FBQ3hFLHFFQUFnRTtBQUNoRSwyRUFBc0U7QUFDdEUsNkVBQStEO0FBR3hELElBQU0sYUFBYSxHQUFuQixNQUFNLGFBQWMsU0FBUSxnQ0FBYztJQVF6QyxBQUFOLEtBQUssQ0FBQyxRQUFRLENBQVUsS0FBa0I7UUFDeEMsT0FBTyxNQUFNLElBQUksQ0FBQyxVQUFVLENBQUMsWUFBWSxDQUFDLEtBQUssQ0FBQyxDQUFBO0lBQ2xELENBQUM7O0FBTk0sa0JBQUksR0FBRyxDQUFDLE1BQU0sQ0FBQyxDQUFBO0FBSHRCO0lBQUMsSUFBQSxhQUFNLEdBQUU7OEJBQ0csd0JBQVU7aURBQUE7QUFNaEI7SUFGTCxJQUFBLFVBQUcsRUFBQyxXQUFXLEVBQUUsRUFBRSxPQUFPLEVBQUUsUUFBUSxFQUFFLENBQUM7SUFDdkMsSUFBQSwrQkFBUyxFQUFDLE1BQU0sQ0FBQztJQUNGLFdBQUEsSUFBQSxZQUFLLEdBQUUsQ0FBQTs7cUNBQVEsMEJBQVc7OzZDQUV6QztBQVZVLGFBQWE7SUFEekIsSUFBQSxpQkFBVSxFQUFDLFlBQVksQ0FBQztHQUNaLGFBQWEsQ0FXekI7QUFYWSxzQ0FBYSJ9