"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MaterialController = void 0;
const core_1 = require("@midwayjs/core");
const base_controller_1 = require("../../shared/controller/base.controller");
const material_service_1 = require("../../service/admin/materialLibrary/material.service");
const material_dto_1 = require("../../service/admin/materialLibrary/dto/material.dto");
const base_dto_1 = require("../../shared/dto/base.dto");
let MaterialController = class MaterialController extends base_controller_1.BaseController {
    async getMaterialLibrary() {
        return this.materialService.findMultiple({ params: { pageSize: 99 } });
    }
    async createMaterialLibrary(body) {
        return this.materialService.createMaterialLibrary(body.groupName);
    }
    async delete(body) {
        return this.materialService.destroyMaterialGroup(body.id);
    }
    async modify(body) {
        return this.materialService.update(body, body.id);
    }
    async getMaterial(query) {
        return this.materialService.materialFindMultiple(query);
    }
    async createMaterial(body) {
        return this.materialService.materialBulkCreate(body);
    }
    async deleteMaterial(body) {
        return this.materialService.materialDestroy(body.id);
    }
};
__decorate([
    (0, core_1.Inject)(),
    __metadata("design:type", material_service_1.MaterialService)
], MaterialController.prototype, "materialService", void 0);
__decorate([
    (0, core_1.Get)('/getMaterialGroup', { summary: '获取素材库分组' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], MaterialController.prototype, "getMaterialLibrary", null);
__decorate([
    (0, core_1.Post)('/createMaterialGroup', { summary: '创建素材库分组' }),
    __param(0, (0, core_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [material_dto_1.CreateMaterialLibraryDto]),
    __metadata("design:returntype", Promise)
], MaterialController.prototype, "createMaterialLibrary", null);
__decorate([
    (0, core_1.Post)('/deleteMaterialGroup', { summary: '删除素材库分组' }),
    __param(0, (0, core_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [base_dto_1.IdDto]),
    __metadata("design:returntype", Promise)
], MaterialController.prototype, "delete", null);
__decorate([
    (0, core_1.Post)('/updateMaterialGroup', { summary: '修改素材库分组' }),
    __param(0, (0, core_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [material_dto_1.MaterialLibraryDto]),
    __metadata("design:returntype", Promise)
], MaterialController.prototype, "modify", null);
__decorate([
    (0, core_1.Get)('/getMaterial', { summary: '获取素材' }),
    __param(0, (0, core_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [material_dto_1.FindMaterialDto]),
    __metadata("design:returntype", Promise)
], MaterialController.prototype, "getMaterial", null);
__decorate([
    (0, core_1.Post)('/createMaterial', { summary: '添加素材' }),
    __param(0, (0, core_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [material_dto_1.CreateMaterialDto]),
    __metadata("design:returntype", Promise)
], MaterialController.prototype, "createMaterial", null);
__decorate([
    (0, core_1.Post)('/deleteMaterial', { summary: '删除素材' }),
    __param(0, (0, core_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [base_dto_1.IdDto]),
    __metadata("design:returntype", Promise)
], MaterialController.prototype, "deleteMaterial", null);
MaterialController = __decorate([
    (0, core_1.Controller)('/admin/materialLibrary')
], MaterialController);
exports.MaterialController = MaterialController;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWF0ZXJpYWwuY29udHJvbGxlci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uL3NyYy9jb250cm9sbGVyL2FkbWluL21hdGVyaWFsLmNvbnRyb2xsZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7O0FBQUEseUNBQTJFO0FBQzNFLDZFQUF3RTtBQUN4RSwyRkFBc0Y7QUFDdEYsdUZBSzZEO0FBQzdELHdEQUFpRDtBQUcxQyxJQUFNLGtCQUFrQixHQUF4QixNQUFNLGtCQUFtQixTQUFRLGdDQUFjO0lBSzlDLEFBQU4sS0FBSyxDQUFDLGtCQUFrQjtRQUN0QixPQUFPLElBQUksQ0FBQyxlQUFlLENBQUMsWUFBWSxDQUFDLEVBQUUsTUFBTSxFQUFFLEVBQUUsUUFBUSxFQUFFLEVBQUUsRUFBRSxFQUFFLENBQUMsQ0FBQTtJQUN4RSxDQUFDO0lBR0ssQUFBTixLQUFLLENBQUMscUJBQXFCLENBQVMsSUFBOEI7UUFDaEUsT0FBTyxJQUFJLENBQUMsZUFBZSxDQUFDLHFCQUFxQixDQUFDLElBQUksQ0FBQyxTQUFTLENBQUMsQ0FBQTtJQUNuRSxDQUFDO0lBR0ssQUFBTixLQUFLLENBQUMsTUFBTSxDQUFTLElBQVc7UUFDOUIsT0FBTyxJQUFJLENBQUMsZUFBZSxDQUFDLG9CQUFvQixDQUFDLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQTtJQUMzRCxDQUFDO0lBR0ssQUFBTixLQUFLLENBQUMsTUFBTSxDQUFTLElBQXdCO1FBQzNDLE9BQU8sSUFBSSxDQUFDLGVBQWUsQ0FBQyxNQUFNLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQTtJQUNuRCxDQUFDO0lBR0ssQUFBTixLQUFLLENBQUMsV0FBVyxDQUFVLEtBQXNCO1FBQy9DLE9BQU8sSUFBSSxDQUFDLGVBQWUsQ0FBQyxvQkFBb0IsQ0FBQyxLQUFLLENBQUMsQ0FBQTtJQUN6RCxDQUFDO0lBR0ssQUFBTixLQUFLLENBQUMsY0FBYyxDQUFTLElBQXVCO1FBQ2xELE9BQU8sSUFBSSxDQUFDLGVBQWUsQ0FBQyxrQkFBa0IsQ0FBQyxJQUFJLENBQUMsQ0FBQTtJQUN0RCxDQUFDO0lBR0ssQUFBTixLQUFLLENBQUMsY0FBYyxDQUFTLElBQVc7UUFDdEMsT0FBTyxJQUFJLENBQUMsZUFBZSxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUE7SUFDdEQsQ0FBQztDQUNGLENBQUE7QUFyQ0M7SUFBQyxJQUFBLGFBQU0sR0FBRTs4QkFDUSxrQ0FBZTsyREFBQTtBQUcxQjtJQURMLElBQUEsVUFBRyxFQUFDLG1CQUFtQixFQUFFLEVBQUUsT0FBTyxFQUFFLFNBQVMsRUFBRSxDQUFDOzs7OzREQUdoRDtBQUdLO0lBREwsSUFBQSxXQUFJLEVBQUMsc0JBQXNCLEVBQUUsRUFBRSxPQUFPLEVBQUUsU0FBUyxFQUFFLENBQUM7SUFDeEIsV0FBQSxJQUFBLFdBQUksR0FBRSxDQUFBOztxQ0FBTyx1Q0FBd0I7OytEQUVqRTtBQUdLO0lBREwsSUFBQSxXQUFJLEVBQUMsc0JBQXNCLEVBQUUsRUFBRSxPQUFPLEVBQUUsU0FBUyxFQUFFLENBQUM7SUFDdkMsV0FBQSxJQUFBLFdBQUksR0FBRSxDQUFBOztxQ0FBTyxnQkFBSzs7Z0RBRS9CO0FBR0s7SUFETCxJQUFBLFdBQUksRUFBQyxzQkFBc0IsRUFBRSxFQUFFLE9BQU8sRUFBRSxTQUFTLEVBQUUsQ0FBQztJQUN2QyxXQUFBLElBQUEsV0FBSSxHQUFFLENBQUE7O3FDQUFPLGlDQUFrQjs7Z0RBRTVDO0FBR0s7SUFETCxJQUFBLFVBQUcsRUFBQyxjQUFjLEVBQUUsRUFBRSxPQUFPLEVBQUUsTUFBTSxFQUFFLENBQUM7SUFDdEIsV0FBQSxJQUFBLFlBQUssR0FBRSxDQUFBOztxQ0FBUSw4QkFBZTs7cURBRWhEO0FBR0s7SUFETCxJQUFBLFdBQUksRUFBQyxpQkFBaUIsRUFBRSxFQUFFLE9BQU8sRUFBRSxNQUFNLEVBQUUsQ0FBQztJQUN2QixXQUFBLElBQUEsV0FBSSxHQUFFLENBQUE7O3FDQUFPLGdDQUFpQjs7d0RBRW5EO0FBR0s7SUFETCxJQUFBLFdBQUksRUFBQyxpQkFBaUIsRUFBRSxFQUFFLE9BQU8sRUFBRSxNQUFNLEVBQUUsQ0FBQztJQUN2QixXQUFBLElBQUEsV0FBSSxHQUFFLENBQUE7O3FDQUFPLGdCQUFLOzt3REFFdkM7QUFyQ1Usa0JBQWtCO0lBRDlCLElBQUEsaUJBQVUsRUFBQyx3QkFBd0IsQ0FBQztHQUN4QixrQkFBa0IsQ0FzQzlCO0FBdENZLGdEQUFrQiJ9