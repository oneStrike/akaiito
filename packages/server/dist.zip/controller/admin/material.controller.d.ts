import { BaseController } from '../../shared/controller/base.controller';
import { MaterialService } from '../../service/admin/materialLibrary/material.service';
import { CreateMaterialDto, CreateMaterialLibraryDto, FindMaterialDto, MaterialLibraryDto } from '../../service/admin/materialLibrary/dto/material.dto';
import { IdDto } from '../../shared/dto/base.dto';
export declare class MaterialController extends BaseController {
    materialService: MaterialService;
    getMaterialLibrary(): Promise<import("../../types/dto/list").ListResponseRes<import("sequelize-typescript").Model<any, any>>>;
    createMaterialLibrary(body: CreateMaterialLibraryDto): Promise<number>;
    delete(body: IdDto): Promise<number>;
    modify(body: MaterialLibraryDto): Promise<number | number[]>;
    getMaterial(query: FindMaterialDto): Promise<import("../../types/dto/list").ListResponseRes<import("../../service/admin/materialLibrary/entities/materialLibrary.entity").MaterialEntity>>;
    createMaterial(body: CreateMaterialDto): Promise<void | any[]>;
    deleteMaterial(body: IdDto): Promise<number>;
}
