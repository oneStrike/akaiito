import { BaseController } from '../../shared/controller/base.controller';
import { LogService } from '../../service/admin/log/log.service';
import { LoginLogDto } from '../../service/admin/log/dto/loginLog.dto';
export declare class LogController extends BaseController {
    logService: LogService;
    static pure: string[];
    loginLog(query: LoginLogDto): Promise<import("../../types/dto/list").ListResponseRes<import("sequelize-typescript").Model<any, any>>>;
}
