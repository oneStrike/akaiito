import { BaseController } from '../../shared/controller/base.controller';
import { UserService } from '../../service/admin/user/user.service';
import { UpdateUserInfoDto, CreateUserDto, LoginDto, getUserListDto, UpdatePasswordDto } from '../../service/admin/user/dto/operate-user.dto';
import { AdminUserEntity } from '../../service/admin/user/entities/user.entity';
import { IdDto, ToggleStatusDto } from '../../shared/dto/base.dto';
export declare class UserController extends BaseController {
    userService: UserService;
    static pure: string[];
    createAccount(user: CreateUserDto): Promise<number>;
    login(body: LoginDto): Promise<{
        token: string;
        refreshToken: string;
        user: AdminUserEntity;
    }>;
    getUserInfo(): Promise<AdminUserEntity>;
    deleteUser(body: IdDto): Promise<number | number[]>;
    getUserList(params: getUserListDto): Promise<import("../../types/dto/list").ListResponseRes<import("sequelize-typescript").Model<any, any>>>;
    switchUserStatus(params: ToggleStatusDto): Promise<number | number[]>;
    updatePassword(params: UpdatePasswordDto): Promise<any>;
    updateUserInfo(params: UpdateUserInfoDto): Promise<number>;
    refreshToken(): Promise<string>;
}
