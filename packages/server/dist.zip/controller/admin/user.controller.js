"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserController = void 0;
const core_1 = require("@midwayjs/core");
const base_controller_1 = require("../../shared/controller/base.controller");
const user_service_1 = require("../../service/admin/user/user.service");
const operate_user_dto_1 = require("../../service/admin/user/dto/operate-user.dto");
const serialize_decorator_1 = require("../../decorator/serialize.decorator");
const base_dto_1 = require("../../shared/dto/base.dto");
let UserController = class UserController extends base_controller_1.BaseController {
    async createAccount(user) {
        return this.userService.createUser(user);
    }
    async login(body) {
        body.captchaId = this.ctx.session?.captchaId;
        return await this.userService.login(body);
    }
    async getUserInfo() {
        const userInfo = this.ctx.getAttr('userInfo');
        return this.userService.getUserInfo(userInfo.id);
    }
    async deleteUser(body) {
        return this.userService.destroy(body.id);
    }
    async getUserList(params) {
        return await this.userService.findMultiple({ params });
    }
    async switchUserStatus(params) {
        return this.userService.update(params, params.ids);
    }
    async updatePassword(params) {
        return this.userService.updatePassword(params);
    }
    async updateUserInfo(params) {
        return this.userService.updateUserInfo(params);
    }
    async refreshToken() {
        const { id } = this.ctx.getAttr('userInfo');
        return this.userService.refreshToken(id);
    }
};
UserController.pure = ['password'];
__decorate([
    (0, core_1.Inject)(),
    __metadata("design:type", user_service_1.UserService)
], UserController.prototype, "userService", void 0);
__decorate([
    (0, core_1.Post)('/createUser', { summary: '创建用户' }),
    __param(0, (0, core_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [operate_user_dto_1.CreateUserDto]),
    __metadata("design:returntype", Promise)
], UserController.prototype, "createAccount", null);
__decorate([
    (0, core_1.Post)('/login', { summary: '登录' }),
    (0, serialize_decorator_1.Serialize)('user'),
    __param(0, (0, core_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [operate_user_dto_1.LoginDto]),
    __metadata("design:returntype", Promise)
], UserController.prototype, "login", null);
__decorate([
    (0, core_1.Get)('/userInfo', { summary: '获取用户信息' }),
    (0, serialize_decorator_1.Serialize)(),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], UserController.prototype, "getUserInfo", null);
__decorate([
    (0, core_1.Post)('/deleteUser', { summary: '删除用户' }),
    __param(0, (0, core_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [base_dto_1.IdDto]),
    __metadata("design:returntype", Promise)
], UserController.prototype, "deleteUser", null);
__decorate([
    (0, core_1.Get)('/userList', { summary: '获取用户列表' }),
    (0, serialize_decorator_1.Serialize)('list'),
    __param(0, (0, core_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [operate_user_dto_1.getUserListDto]),
    __metadata("design:returntype", Promise)
], UserController.prototype, "getUserList", null);
__decorate([
    (0, core_1.Post)('/switchUserStatus', { summary: '启用或禁用用户' }),
    __param(0, (0, core_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [base_dto_1.ToggleStatusDto]),
    __metadata("design:returntype", Promise)
], UserController.prototype, "switchUserStatus", null);
__decorate([
    (0, core_1.Post)('/updatePassword', { summary: '修改密码' }),
    __param(0, (0, core_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [operate_user_dto_1.UpdatePasswordDto]),
    __metadata("design:returntype", Promise)
], UserController.prototype, "updatePassword", null);
__decorate([
    (0, core_1.Post)('/updateUserInfo', { summary: '修改用户信息' }),
    __param(0, (0, core_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [operate_user_dto_1.UpdateUserInfoDto]),
    __metadata("design:returntype", Promise)
], UserController.prototype, "updateUserInfo", null);
__decorate([
    (0, core_1.Post)('/refreshToken', { summary: '刷新用户token' }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], UserController.prototype, "refreshToken", null);
UserController = __decorate([
    (0, core_1.Controller)('/admin/user', { tagName: '用户' })
], UserController);
exports.UserController = UserController;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidXNlci5jb250cm9sbGVyLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vc3JjL2NvbnRyb2xsZXIvYWRtaW4vdXNlci5jb250cm9sbGVyLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7Ozs7OztBQUFBLHlDQUEyRTtBQUMzRSw2RUFBd0U7QUFDeEUsd0VBQW1FO0FBQ25FLG9GQU1zRDtBQUN0RCw2RUFBK0Q7QUFHL0Qsd0RBQWtFO0FBRzNELElBQU0sY0FBYyxHQUFwQixNQUFNLGNBQWUsU0FBUSxnQ0FBYztJQU8xQyxBQUFOLEtBQUssQ0FBQyxhQUFhLENBQVMsSUFBbUI7UUFDN0MsT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQTtJQUMxQyxDQUFDO0lBSUssQUFBTixLQUFLLENBQUMsS0FBSyxDQUFTLElBQWM7UUFDaEMsSUFBSSxDQUFDLFNBQVMsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLE9BQU8sRUFBRSxTQUFTLENBQUE7UUFDNUMsT0FBTyxNQUFNLElBQUksQ0FBQyxXQUFXLENBQUMsS0FBSyxDQUFDLElBQUksQ0FBQyxDQUFBO0lBQzNDLENBQUM7SUFJSyxBQUFOLEtBQUssQ0FBQyxXQUFXO1FBQ2YsTUFBTSxRQUFRLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFZLENBQUE7UUFDeEQsT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLENBQUE7SUFDbEQsQ0FBQztJQUdLLEFBQU4sS0FBSyxDQUFDLFVBQVUsQ0FBUyxJQUFXO1FBQ2xDLE9BQU8sSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFBO0lBQzFDLENBQUM7SUFJSyxBQUFOLEtBQUssQ0FBQyxXQUFXLENBQVUsTUFBc0I7UUFDL0MsT0FBTyxNQUFNLElBQUksQ0FBQyxXQUFXLENBQUMsWUFBWSxDQUFDLEVBQUUsTUFBTSxFQUFFLENBQUMsQ0FBQTtJQUN4RCxDQUFDO0lBR0ssQUFBTixLQUFLLENBQUMsZ0JBQWdCLENBQVMsTUFBdUI7UUFDcEQsT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxNQUFNLEVBQUUsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFBO0lBQ3BELENBQUM7SUFHSyxBQUFOLEtBQUssQ0FBQyxjQUFjLENBQVMsTUFBeUI7UUFDcEQsT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDLGNBQWMsQ0FBQyxNQUFNLENBQUMsQ0FBQTtJQUNoRCxDQUFDO0lBR0ssQUFBTixLQUFLLENBQUMsY0FBYyxDQUFTLE1BQXlCO1FBQ3BELE9BQU8sSUFBSSxDQUFDLFdBQVcsQ0FBQyxjQUFjLENBQUMsTUFBTSxDQUFDLENBQUE7SUFDaEQsQ0FBQztJQUdLLEFBQU4sS0FBSyxDQUFDLFlBQVk7UUFDaEIsTUFBTSxFQUFFLEVBQUUsRUFBRSxHQUFHLElBQUksQ0FBQyxHQUFHLENBQUMsT0FBTyxDQUFDLFVBQVUsQ0FBb0IsQ0FBQTtRQUM5RCxPQUFPLElBQUksQ0FBQyxXQUFXLENBQUMsWUFBWSxDQUFDLEVBQUUsQ0FBQyxDQUFBO0lBQzFDLENBQUM7O0FBbkRNLG1CQUFJLEdBQUcsQ0FBQyxVQUFVLENBQUMsQ0FBQTtBQUgxQjtJQUFDLElBQUEsYUFBTSxHQUFFOzhCQUNJLDBCQUFXO21EQUFBO0FBS2xCO0lBREwsSUFBQSxXQUFJLEVBQUMsYUFBYSxFQUFFLEVBQUUsT0FBTyxFQUFFLE1BQU0sRUFBRSxDQUFDO0lBQ3BCLFdBQUEsSUFBQSxXQUFJLEdBQUUsQ0FBQTs7cUNBQU8sZ0NBQWE7O21EQUU5QztBQUlLO0lBRkwsSUFBQSxXQUFJLEVBQUMsUUFBUSxFQUFFLEVBQUUsT0FBTyxFQUFFLElBQUksRUFBRSxDQUFDO0lBQ2pDLElBQUEsK0JBQVMsRUFBQyxNQUFNLENBQUM7SUFDTCxXQUFBLElBQUEsV0FBSSxHQUFFLENBQUE7O3FDQUFPLDJCQUFROzsyQ0FHakM7QUFJSztJQUZMLElBQUEsVUFBRyxFQUFDLFdBQVcsRUFBRSxFQUFFLE9BQU8sRUFBRSxRQUFRLEVBQUUsQ0FBQztJQUN2QyxJQUFBLCtCQUFTLEdBQUU7Ozs7aURBSVg7QUFHSztJQURMLElBQUEsV0FBSSxFQUFDLGFBQWEsRUFBRSxFQUFFLE9BQU8sRUFBRSxNQUFNLEVBQUUsQ0FBQztJQUN2QixXQUFBLElBQUEsV0FBSSxHQUFFLENBQUE7O3FDQUFPLGdCQUFLOztnREFFbkM7QUFJSztJQUZMLElBQUEsVUFBRyxFQUFDLFdBQVcsRUFBRSxFQUFFLE9BQU8sRUFBRSxRQUFRLEVBQUUsQ0FBQztJQUN2QyxJQUFBLCtCQUFTLEVBQUMsTUFBTSxDQUFDO0lBQ0MsV0FBQSxJQUFBLFlBQUssR0FBRSxDQUFBOztxQ0FBUyxpQ0FBYzs7aURBRWhEO0FBR0s7SUFETCxJQUFBLFdBQUksRUFBQyxtQkFBbUIsRUFBRSxFQUFFLE9BQU8sRUFBRSxTQUFTLEVBQUUsQ0FBQztJQUMxQixXQUFBLElBQUEsV0FBSSxHQUFFLENBQUE7O3FDQUFTLDBCQUFlOztzREFFckQ7QUFHSztJQURMLElBQUEsV0FBSSxFQUFDLGlCQUFpQixFQUFFLEVBQUUsT0FBTyxFQUFFLE1BQU0sRUFBRSxDQUFDO0lBQ3ZCLFdBQUEsSUFBQSxXQUFJLEdBQUUsQ0FBQTs7cUNBQVMsb0NBQWlCOztvREFFckQ7QUFHSztJQURMLElBQUEsV0FBSSxFQUFDLGlCQUFpQixFQUFFLEVBQUUsT0FBTyxFQUFFLFFBQVEsRUFBRSxDQUFDO0lBQ3pCLFdBQUEsSUFBQSxXQUFJLEdBQUUsQ0FBQTs7cUNBQVMsb0NBQWlCOztvREFFckQ7QUFHSztJQURMLElBQUEsV0FBSSxFQUFDLGVBQWUsRUFBRSxFQUFFLE9BQU8sRUFBRSxXQUFXLEVBQUUsQ0FBQzs7OztrREFJL0M7QUF2RFUsY0FBYztJQUQxQixJQUFBLGlCQUFVLEVBQUMsYUFBYSxFQUFFLEVBQUUsT0FBTyxFQUFFLElBQUksRUFBRSxDQUFDO0dBQ2hDLGNBQWMsQ0F3RDFCO0FBeERZLHdDQUFjIn0=