"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SocialCircleController = void 0;
const base_controller_1 = require("../../shared/controller/base.controller");
const core_1 = require("@midwayjs/core");
const socialCircle_service_1 = require("../../service/socialCircle/socialCircle.service");
const socialCircle_dto_1 = require("../../service/socialCircle/dto/socialCircle.dto");
const base_dto_1 = require("../../shared/dto/base.dto");
let SocialCircleController = class SocialCircleController extends base_controller_1.BaseController {
    async createSocialCircleClassify(body) {
        return await this.socialCircleService.createSocialCircleClassify(body);
    }
    async updateSocialCircleClassify(body) {
        return await this.socialCircleService.classifyMapping.updateOne(body, { id: body.id });
    }
    async deleteSocialCircleClassify(body) {
        return await this.socialCircleService.classifyMapping.destroy({ id: body.id });
    }
    async createSocialCircle(body) {
        return await this.socialCircleService.createSocialCircle(body);
    }
    async uploadSocialCircle(body) {
        return await this.socialCircleService.update(body, body.id);
    }
    async deleteSocialCircle(body) {
        return await this.socialCircleService.destroy(body.id);
    }
    async UpdateSocialCircleStatus(body) {
        if (body.status === 1)
            body.bannedReason = null;
        return await this.socialCircleService.update({
            status: body.status
        }, body.id);
    }
    async updateSocialCircleGuideStatus(body) {
        return await this.socialCircleService.update({
            guide: body.guide
        }, body.id);
    }
    async getSocialCirclePage(query) {
        return await this.socialCircleService.getSocialCirclePage(query);
    }
    async getSocialCircleDetail({ id }) {
        return await this.socialCircleService.findByPk(id);
    }
    async getSocialCircleClassifyList() {
        return await this.socialCircleService.classifyMapping.findAll();
    }
};
__decorate([
    (0, core_1.Inject)(),
    __metadata("design:type", socialCircle_service_1.SocialCircleService)
], SocialCircleController.prototype, "socialCircleService", void 0);
__decorate([
    (0, core_1.Post)("/createSocialCircleClassify", { summary: "创建圈子分类" }),
    __param(0, (0, core_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [socialCircle_dto_1.CreateSocialCircleClassifyDto]),
    __metadata("design:returntype", Promise)
], SocialCircleController.prototype, "createSocialCircleClassify", null);
__decorate([
    (0, core_1.Post)("/updateSocialCircleClassify", { summary: "更新圈子分类" }),
    __param(0, (0, core_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [socialCircle_dto_1.UpdateSocialCircleClassifyDto]),
    __metadata("design:returntype", Promise)
], SocialCircleController.prototype, "updateSocialCircleClassify", null);
__decorate([
    (0, core_1.Post)("/deleteSocialCircleClassify", { summary: "删除圈子分类" }),
    __param(0, (0, core_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [base_dto_1.IdDto]),
    __metadata("design:returntype", Promise)
], SocialCircleController.prototype, "deleteSocialCircleClassify", null);
__decorate([
    (0, core_1.Post)("/createSocialCircle", { summary: "创建圈子" }),
    __param(0, (0, core_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [socialCircle_dto_1.CreateSocialCircleDto]),
    __metadata("design:returntype", Promise)
], SocialCircleController.prototype, "createSocialCircle", null);
__decorate([
    (0, core_1.Post)("/updateSocialCircle", { summary: "更新圈子" }),
    __param(0, (0, core_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [socialCircle_dto_1.UpdateSocialCircleDto]),
    __metadata("design:returntype", Promise)
], SocialCircleController.prototype, "uploadSocialCircle", null);
__decorate([
    (0, core_1.Post)("/deleteSocialCircle", { summary: "删除圈子" }),
    __param(0, (0, core_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [base_dto_1.IdDto]),
    __metadata("design:returntype", Promise)
], SocialCircleController.prototype, "deleteSocialCircle", null);
__decorate([
    (0, core_1.Post)("/updateSocialCircleStatus", { summary: "更新圈子状态" }),
    __param(0, (0, core_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [socialCircle_dto_1.UpdateSocialCircleStatusDto]),
    __metadata("design:returntype", Promise)
], SocialCircleController.prototype, "UpdateSocialCircleStatus", null);
__decorate([
    (0, core_1.Post)("/updateSocialCircleGuideStatus", { summary: "更新圈子首页展示状态状态" }),
    __param(0, (0, core_1.Body)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [socialCircle_dto_1.UpdateSocialCircleGuideStatusDto]),
    __metadata("design:returntype", Promise)
], SocialCircleController.prototype, "updateSocialCircleGuideStatus", null);
__decorate([
    (0, core_1.Get)("/getSocialCirclePage", { summary: "获取圈子分页列表" }),
    __param(0, (0, core_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [socialCircle_dto_1.getSocialCirclePageDto]),
    __metadata("design:returntype", Promise)
], SocialCircleController.prototype, "getSocialCirclePage", null);
__decorate([
    (0, core_1.Get)("/getSocialCircleDetail", { summary: "获取圈子详情" }),
    __param(0, (0, core_1.Query)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [base_dto_1.IdDto]),
    __metadata("design:returntype", Promise)
], SocialCircleController.prototype, "getSocialCircleDetail", null);
__decorate([
    (0, core_1.Get)("/getSocialCircleClassifyList", { summary: "获取圈子分类列表" }),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], SocialCircleController.prototype, "getSocialCircleClassifyList", null);
SocialCircleController = __decorate([
    (0, core_1.Controller)("/admin/socialCircle")
], SocialCircleController);
exports.SocialCircleController = SocialCircleController;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic29jaWFsQ2lyY2xlLmNvbnRyb2xsZXIuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi9zcmMvY29udHJvbGxlci9hZG1pbi9zb2NpYWxDaXJjbGUuY29udHJvbGxlci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7Ozs7QUFBQSw2RUFBeUU7QUFDekUseUNBQTRFO0FBQzVFLDBGQUFzRjtBQUN0RixzRkFLeUQ7QUFDekQsd0RBQWtEO0FBSTNDLElBQU0sc0JBQXNCLEdBQTVCLE1BQU0sc0JBQXVCLFNBQVEsZ0NBQWM7SUFLbEQsQUFBTixLQUFLLENBQUMsMEJBQTBCLENBQVMsSUFBbUM7UUFDMUUsT0FBTyxNQUFNLElBQUksQ0FBQyxtQkFBbUIsQ0FBQywwQkFBMEIsQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUN6RSxDQUFDO0lBR0ssQUFBTixLQUFLLENBQUMsMEJBQTBCLENBQVMsSUFBbUM7UUFDMUUsT0FBTyxNQUFNLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxlQUFlLENBQUMsU0FBUyxDQUFDLElBQUksRUFBRSxFQUFFLEVBQUUsRUFBRSxJQUFJLENBQUMsRUFBRSxFQUFFLENBQUMsQ0FBQztJQUN6RixDQUFDO0lBR0ssQUFBTixLQUFLLENBQUMsMEJBQTBCLENBQVMsSUFBVztRQUNsRCxPQUFPLE1BQU0sSUFBSSxDQUFDLG1CQUFtQixDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUMsRUFBRSxFQUFFLEVBQUUsSUFBSSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUM7SUFDakYsQ0FBQztJQUdLLEFBQU4sS0FBSyxDQUFDLGtCQUFrQixDQUFTLElBQTJCO1FBQzFELE9BQU8sTUFBTSxJQUFJLENBQUMsbUJBQW1CLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDLENBQUM7SUFDakUsQ0FBQztJQUdLLEFBQU4sS0FBSyxDQUFDLGtCQUFrQixDQUFTLElBQTJCO1FBQzFELE9BQU8sTUFBTSxJQUFJLENBQUMsbUJBQW1CLENBQUMsTUFBTSxDQUFDLElBQUksRUFBRSxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUM7SUFDOUQsQ0FBQztJQUlLLEFBQU4sS0FBSyxDQUFDLGtCQUFrQixDQUFTLElBQVc7UUFDMUMsT0FBTyxNQUFNLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxPQUFPLENBQUMsSUFBSSxDQUFDLEVBQUUsQ0FBQyxDQUFDO0lBQ3pELENBQUM7SUFHSyxBQUFOLEtBQUssQ0FBQyx3QkFBd0IsQ0FBUyxJQUFpQztRQUN0RSxJQUFJLElBQUksQ0FBQyxNQUFNLEtBQUssQ0FBQztZQUFFLElBQUksQ0FBQyxZQUFZLEdBQUcsSUFBSSxDQUFDO1FBQ2hELE9BQU8sTUFBTSxJQUFJLENBQUMsbUJBQW1CLENBQUMsTUFBTSxDQUFDO1lBQzNDLE1BQU0sRUFBRSxJQUFJLENBQUMsTUFBTTtTQUNwQixFQUFFLElBQUksQ0FBQyxFQUFFLENBQUMsQ0FBQztJQUNkLENBQUM7SUFHSyxBQUFOLEtBQUssQ0FBQyw2QkFBNkIsQ0FBUyxJQUFzQztRQUNoRixPQUFPLE1BQU0sSUFBSSxDQUFDLG1CQUFtQixDQUFDLE1BQU0sQ0FBQztZQUMzQyxLQUFLLEVBQUUsSUFBSSxDQUFDLEtBQUs7U0FDbEIsRUFBRSxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUM7SUFDZCxDQUFDO0lBR0ssQUFBTixLQUFLLENBQUMsbUJBQW1CLENBQVUsS0FBNkI7UUFDOUQsT0FBTyxNQUFNLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxtQkFBbUIsQ0FBQyxLQUFLLENBQUMsQ0FBQztJQUNuRSxDQUFDO0lBSUssQUFBTixLQUFLLENBQUMscUJBQXFCLENBQVUsRUFBRSxFQUFFLEVBQVM7UUFDaEQsT0FBTyxNQUFNLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxRQUFRLENBQUMsRUFBRSxDQUFDLENBQUM7SUFDckQsQ0FBQztJQUdLLEFBQU4sS0FBSyxDQUFDLDJCQUEyQjtRQUMvQixPQUFPLE1BQU0sSUFBSSxDQUFDLG1CQUFtQixDQUFDLGVBQWUsQ0FBQyxPQUFPLEVBQUUsQ0FBQztJQUNsRSxDQUFDO0NBQ0YsQ0FBQTtBQWhFQztJQUFDLElBQUEsYUFBTSxHQUFFOzhCQUNZLDBDQUFtQjttRUFBQztBQUduQztJQURMLElBQUEsV0FBSSxFQUFDLDZCQUE2QixFQUFFLEVBQUUsT0FBTyxFQUFFLFFBQVEsRUFBRSxDQUFDO0lBQ3pCLFdBQUEsSUFBQSxXQUFJLEdBQUUsQ0FBQTs7cUNBQU8sZ0RBQTZCOzt3RUFFM0U7QUFHSztJQURMLElBQUEsV0FBSSxFQUFDLDZCQUE2QixFQUFFLEVBQUUsT0FBTyxFQUFFLFFBQVEsRUFBRSxDQUFDO0lBQ3pCLFdBQUEsSUFBQSxXQUFJLEdBQUUsQ0FBQTs7cUNBQU8sZ0RBQTZCOzt3RUFFM0U7QUFHSztJQURMLElBQUEsV0FBSSxFQUFDLDZCQUE2QixFQUFFLEVBQUUsT0FBTyxFQUFFLFFBQVEsRUFBRSxDQUFDO0lBQ3pCLFdBQUEsSUFBQSxXQUFJLEdBQUUsQ0FBQTs7cUNBQU8sZ0JBQUs7O3dFQUVuRDtBQUdLO0lBREwsSUFBQSxXQUFJLEVBQUMscUJBQXFCLEVBQUUsRUFBRSxPQUFPLEVBQUUsTUFBTSxFQUFFLENBQUM7SUFDdkIsV0FBQSxJQUFBLFdBQUksR0FBRSxDQUFBOztxQ0FBTyx3Q0FBcUI7O2dFQUUzRDtBQUdLO0lBREwsSUFBQSxXQUFJLEVBQUMscUJBQXFCLEVBQUUsRUFBRSxPQUFPLEVBQUUsTUFBTSxFQUFFLENBQUM7SUFDdkIsV0FBQSxJQUFBLFdBQUksR0FBRSxDQUFBOztxQ0FBTyx3Q0FBcUI7O2dFQUUzRDtBQUlLO0lBREwsSUFBQSxXQUFJLEVBQUMscUJBQXFCLEVBQUUsRUFBRSxPQUFPLEVBQUUsTUFBTSxFQUFFLENBQUM7SUFDdkIsV0FBQSxJQUFBLFdBQUksR0FBRSxDQUFBOztxQ0FBTyxnQkFBSzs7Z0VBRTNDO0FBR0s7SUFETCxJQUFBLFdBQUksRUFBQywyQkFBMkIsRUFBRSxFQUFFLE9BQU8sRUFBRSxRQUFRLEVBQUUsQ0FBQztJQUN6QixXQUFBLElBQUEsV0FBSSxHQUFFLENBQUE7O3FDQUFPLDhDQUEyQjs7c0VBS3ZFO0FBR0s7SUFETCxJQUFBLFdBQUksRUFBQyxnQ0FBZ0MsRUFBRSxFQUFFLE9BQU8sRUFBRSxjQUFjLEVBQUUsQ0FBQztJQUMvQixXQUFBLElBQUEsV0FBSSxHQUFFLENBQUE7O3FDQUFPLG1EQUFnQzs7MkVBSWpGO0FBR0s7SUFETCxJQUFBLFVBQUcsRUFBQyxzQkFBc0IsRUFBRSxFQUFFLE9BQU8sRUFBRSxVQUFVLEVBQUUsQ0FBQztJQUMxQixXQUFBLElBQUEsWUFBSyxHQUFFLENBQUE7O3FDQUFRLHlDQUFzQjs7aUVBRS9EO0FBSUs7SUFETCxJQUFBLFVBQUcsRUFBQyx3QkFBd0IsRUFBRSxFQUFFLE9BQU8sRUFBRSxRQUFRLEVBQUUsQ0FBQztJQUN4QixXQUFBLElBQUEsWUFBSyxHQUFFLENBQUE7O3FDQUFTLGdCQUFLOzttRUFFakQ7QUFHSztJQURMLElBQUEsVUFBRyxFQUFDLDhCQUE4QixFQUFFLEVBQUUsT0FBTyxFQUFFLFVBQVUsRUFBRSxDQUFDOzs7O3lFQUc1RDtBQWhFVSxzQkFBc0I7SUFEbEMsSUFBQSxpQkFBVSxFQUFDLHFCQUFxQixDQUFDO0dBQ3JCLHNCQUFzQixDQWlFbEM7QUFqRVksd0RBQXNCIn0=