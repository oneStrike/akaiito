import { BaseController } from "../../shared/controller/base.controller";
import { SocialCircleService } from "../../service/socialCircle/socialCircle.service";
import { CreateSocialCircleClassifyDto, CreateSocialCircleDto, getSocialCirclePageDto, UpdateSocialCircleClassifyDto, UpdateSocialCircleDto, UpdateSocialCircleGuideStatusDto, UpdateSocialCircleStatusDto } from "../../service/socialCircle/dto/socialCircle.dto";
import { IdDto } from "../../shared/dto/base.dto";
export declare class SocialCircleController extends BaseController {
    socialCircleService: SocialCircleService;
    createSocialCircleClassify(body: CreateSocialCircleClassifyDto): Promise<any>;
    updateSocialCircleClassify(body: UpdateSocialCircleClassifyDto): Promise<[affectedCount: number]>;
    deleteSocialCircleClassify(body: IdDto): Promise<number>;
    createSocialCircle(body: CreateSocialCircleDto): Promise<any>;
    uploadSocialCircle(body: UpdateSocialCircleDto): Promise<number | number[]>;
    deleteSocialCircle(body: IdDto): Promise<number | number[]>;
    UpdateSocialCircleStatus(body: UpdateSocialCircleStatusDto): Promise<number | number[]>;
    updateSocialCircleGuideStatus(body: UpdateSocialCircleGuideStatusDto): Promise<number | number[]>;
    getSocialCirclePage(query: getSocialCirclePageDto): Promise<import("../../types/dto/list").ListResponseRes<import("sequelize-typescript").Model<any, any>>>;
    getSocialCircleDetail({ id }: IdDto): Promise<import("sequelize-typescript").Model<any, any>>;
    getSocialCircleClassifyList(): Promise<import("sequelize-typescript").Model<any, any>[]>;
}
