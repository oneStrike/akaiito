"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
const core_1 = require("@midwayjs/core");
const encryption_util_1 = require("./encryption.util");
const _ = require("lodash");
const commonUtil = require("./common.util");
const systemUtil = require("./system.util");
const fsUtil = require("./fs.util");
const dayjs = require("dayjs");
const fs = require("fs-extra");
let Utils = class Utils {
    constructor() {
        this.lodash = _;
        this.dayjs = dayjs;
        this.commonUtil = commonUtil;
        this.systemUtil = systemUtil;
        this.fsUtil = fsUtil;
        this.fs = fs;
        this.encryption = encryption_util_1.encryption;
    }
};
__decorate([
    (0, core_1.Inject)(),
    __metadata("design:type", Object)
], Utils.prototype, "baseDir", void 0);
Utils = __decorate([
    (0, core_1.Provide)(),
    (0, core_1.Scope)(core_1.ScopeEnum.Singleton)
], Utils);
exports.default = Utils;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiaW5kZXguanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi9zcmMvdXRpbHMvaW5kZXgudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7QUFBQSx5Q0FBa0U7QUFDbEUsdURBQThDO0FBQzlDLDRCQUEyQjtBQUMzQiw0Q0FBMkM7QUFDM0MsNENBQTJDO0FBQzNDLG9DQUFtQztBQUNuQywrQkFBK0I7QUFDL0IsK0JBQThCO0FBR2YsSUFBTSxLQUFLLEdBQVgsTUFBTSxLQUFLO0lBQVg7UUFJYixXQUFNLEdBQUcsQ0FBQyxDQUFBO1FBRVYsVUFBSyxHQUFHLEtBQUssQ0FBQTtRQUViLGVBQVUsR0FBRyxVQUFVLENBQUE7UUFFdkIsZUFBVSxHQUFHLFVBQVUsQ0FBQTtRQUV2QixXQUFNLEdBQWtCLE1BQU0sQ0FBQTtRQUM5QixPQUFFLEdBQWMsRUFBRSxDQUFBO1FBRWxCLGVBQVUsR0FBc0IsNEJBQVUsQ0FBQTtJQUM1QyxDQUFDO0NBQUEsQ0FBQTtBQWZDO0lBQUMsSUFBQSxhQUFNLEdBQUU7O3NDQUNHO0FBRk8sS0FBSztJQUZ6QixJQUFBLGNBQU8sR0FBRTtJQUNULElBQUEsWUFBSyxFQUFDLGdCQUFTLENBQUMsU0FBUyxDQUFDO0dBQ04sS0FBSyxDQWdCekI7a0JBaEJvQixLQUFLIn0=