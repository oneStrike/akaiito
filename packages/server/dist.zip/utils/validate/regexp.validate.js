"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.validSocialCredit = exports.validWeChartAccount = exports.validPhone = exports.validTel = exports.validPhoneTel = exports.validPhoneTelSpa = exports.validPsw = void 0;
/**
 * 密码（密码至少包含大小写字母、数字、特殊字符、8~16位！）
 */
exports.validPsw = /^(?=.*[0-9])(?=.*[A-Z])(?=.*[a-z])(?=.*[!_#%&@*.?+$^[\](){}|/\\])[0-9A-Za-z!_#%&@*.?+$^[\](){}|/\\].{7,15}$/;
/**
 * 手机号码或者固话或者特殊电话
 */
exports.validPhoneTelSpa = /^((1[0-2|6-9]\d{+})|([0-9]{3,4}-)?[0-9]{7,8}|(1[3-9]\d{9}))$/;
/**
 * 手机号码或者固话
 */
exports.validPhoneTel = /^(([0-9]{3,4}-)?[0-9]{7,8}|(1[3-9]\d{9}))$/;
/**
 * 固话
 */
exports.validTel = /^\d{3}-\d{7,8}|\d{4}-\d{7,8}$/;
/**
 * 手机号
 */
exports.validPhone = /^1[3-9]\d{9}$/;
/**
 * 微信号
 */
exports.validWeChartAccount = /^[a-zA-Z][a-zA-Z\d_-]{5,19}$/;
/**
 * 社会信用代码
 */
exports.validSocialCredit = /(?!^[A-Z]+$)[0-9A-Z]{18}/;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmVnZXhwLnZhbGlkYXRlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vc3JjL3V0aWxzL3ZhbGlkYXRlL3JlZ2V4cC52YWxpZGF0ZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFBQTs7R0FFRztBQUNVLFFBQUEsUUFBUSxHQUNuQiw2R0FBNkcsQ0FBQTtBQUUvRzs7R0FFRztBQUNVLFFBQUEsZ0JBQWdCLEdBQzNCLDhEQUE4RCxDQUFBO0FBRWhFOztHQUVHO0FBQ1UsUUFBQSxhQUFhLEdBQUcsNENBQTRDLENBQUE7QUFFekU7O0dBRUc7QUFDVSxRQUFBLFFBQVEsR0FBRywrQkFBK0IsQ0FBQTtBQUV2RDs7R0FFRztBQUNVLFFBQUEsVUFBVSxHQUFHLGVBQWUsQ0FBQTtBQUV6Qzs7R0FFRztBQUNVLFFBQUEsbUJBQW1CLEdBQUcsOEJBQThCLENBQUE7QUFFakU7O0dBRUc7QUFDVSxRQUFBLGlCQUFpQixHQUFHLDBCQUEwQixDQUFBIn0=