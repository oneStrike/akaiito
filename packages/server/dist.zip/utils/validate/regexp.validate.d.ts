/**
 * 密码（密码至少包含大小写字母、数字、特殊字符、8~16位！）
 */
export declare const validPsw: RegExp;
/**
 * 手机号码或者固话或者特殊电话
 */
export declare const validPhoneTelSpa: RegExp;
/**
 * 手机号码或者固话
 */
export declare const validPhoneTel: RegExp;
/**
 * 固话
 */
export declare const validTel: RegExp;
/**
 * 手机号
 */
export declare const validPhone: RegExp;
/**
 * 微信号
 */
export declare const validWeChartAccount: RegExp;
/**
 * 社会信用代码
 */
export declare const validSocialCredit: RegExp;
