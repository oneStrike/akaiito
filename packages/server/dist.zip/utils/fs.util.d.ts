export declare const isDirectory: (path: string) => Promise<boolean>;
export declare const mkdir: (path: string) => Promise<string>;
