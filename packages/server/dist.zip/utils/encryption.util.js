"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.encryption = void 0;
const crypto_1 = require("crypto");
const util_1 = require("util");
const scrypt = (0, util_1.promisify)(crypto_1.scrypt);
const encryption = async function encryption(str, salt) {
    if (!salt) {
        salt = (0, crypto_1.randomBytes)(8).toString('hex');
    }
    const key = (await scrypt(str, salt, 32));
    return salt + '.' + key.toString('hex');
};
exports.encryption = encryption;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZW5jcnlwdGlvbi51dGlsLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vc3JjL3V0aWxzL2VuY3J5cHRpb24udXRpbC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFBQSxtQ0FBdUQ7QUFDdkQsK0JBQWdDO0FBRWhDLE1BQU0sTUFBTSxHQUFHLElBQUEsZ0JBQVMsRUFBQyxlQUFPLENBQUMsQ0FBQTtBQUUxQixNQUFNLFVBQVUsR0FBRyxLQUFLLFVBQVUsVUFBVSxDQUNqRCxHQUFXLEVBQ1gsSUFBYTtJQUViLElBQUksQ0FBQyxJQUFJLEVBQUU7UUFDVCxJQUFJLEdBQUcsSUFBQSxvQkFBVyxFQUFDLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUMsQ0FBQTtLQUN0QztJQUNELE1BQU0sR0FBRyxHQUFHLENBQUMsTUFBTSxNQUFNLENBQUMsR0FBRyxFQUFFLElBQUksRUFBRSxFQUFFLENBQUMsQ0FBVyxDQUFBO0lBQ25ELE9BQU8sSUFBSSxHQUFHLEdBQUcsR0FBRyxHQUFHLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxDQUFBO0FBQ3pDLENBQUMsQ0FBQTtBQVRZLFFBQUEsVUFBVSxjQVN0QiJ9