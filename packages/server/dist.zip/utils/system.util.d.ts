import { IDisk, IMemory } from '../types/utils';
import { Context } from '@midwayjs/koa';
/**
 * 获取内存信息
 */
export declare const memory: () => IMemory;
/**
 * 获取磁盘信息
 */
export declare const disk: () => Promise<IDisk>;
export declare const getReqIP: (ctx: Context) => any;
export declare const getIpAddr: (ctx: Context, ip?: string | string[]) => Promise<string>;
export declare const sleep: (ms: number) => Promise<unknown>;
