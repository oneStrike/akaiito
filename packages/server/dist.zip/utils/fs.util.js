"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.mkdir = exports.isDirectory = void 0;
const fs = require("fs/promises");
const isDirectory = async (path) => {
    try {
        const stats = await fs.stat(path);
        return stats.isDirectory();
    }
    catch (e) {
        return false;
    }
};
exports.isDirectory = isDirectory;
const mkdir = async (path) => {
    return await fs.mkdir(path, { recursive: true });
};
exports.mkdir = mkdir;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZnMudXRpbC5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy91dGlscy9mcy51dGlsLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7OztBQUFBLGtDQUFpQztBQUUxQixNQUFNLFdBQVcsR0FBRyxLQUFLLEVBQUUsSUFBWSxFQUFFLEVBQUU7SUFDaEQsSUFBSTtRQUNGLE1BQU0sS0FBSyxHQUFHLE1BQU0sRUFBRSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQTtRQUNqQyxPQUFPLEtBQUssQ0FBQyxXQUFXLEVBQUUsQ0FBQTtLQUMzQjtJQUFDLE9BQU8sQ0FBQyxFQUFFO1FBQ1YsT0FBTyxLQUFLLENBQUE7S0FDYjtBQUNILENBQUMsQ0FBQTtBQVBZLFFBQUEsV0FBVyxlQU92QjtBQUVNLE1BQU0sS0FBSyxHQUFHLEtBQUssRUFBRSxJQUFZLEVBQUUsRUFBRTtJQUMxQyxPQUFPLE1BQU0sRUFBRSxDQUFDLEtBQUssQ0FBQyxJQUFJLEVBQUUsRUFBRSxTQUFTLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQTtBQUNsRCxDQUFDLENBQUE7QUFGWSxRQUFBLEtBQUssU0FFakIifQ==