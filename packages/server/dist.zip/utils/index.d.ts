import { encryption } from './encryption.util';
import * as _ from 'lodash';
import * as commonUtil from './common.util';
import * as systemUtil from './system.util';
import * as fsUtil from './fs.util';
import dayjs = require('dayjs');
import * as fs from 'fs-extra';
export default class Utils {
    baseDir: any;
    lodash: _.LoDashStatic;
    dayjs: typeof dayjs;
    commonUtil: typeof commonUtil;
    systemUtil: typeof systemUtil;
    fsUtil: typeof fsUtil;
    fs: typeof fs;
    encryption: typeof encryption;
}
