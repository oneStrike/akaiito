import { ServiceVersionEnum } from '../shared/enum/service-version.enum';
/**
 * 字节数单位转换
 * @param mem 字节数
 */
export declare const deal: (mem: number) => string;
/**
 * 随机数
 * @param length
 * @param charset
 */
export declare const getRandom: (length?: number, charset?: string) => any;
/**
 * 获取路由类型,管理端还是客户端
 * @param path 请求地址
 */
export declare const serviceVersionType: (path: string) => ServiceVersionEnum;
