"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.sleep = exports.getIpAddr = exports.getReqIP = exports.disk = exports.memory = void 0;
const os = require("os");
const check_disk_space_1 = require("check-disk-space");
const common_util_1 = require("./common.util");
const _ = require("lodash");
const ipdb = require("ipip-ipdb");
const path = require("path");
/**
 * 获取内存信息
 */
const memory = function () {
    const totalMemory = os.totalmem();
    const freeMemory = os.freemem();
    const memoryTotal = (0, common_util_1.deal)(totalMemory);
    const memoryFree = (0, common_util_1.deal)(freeMemory);
    const memoryUsed = (0, common_util_1.deal)(totalMemory - freeMemory);
    return { memoryTotal, memoryFree, memoryUsed };
};
exports.memory = memory;
/**
 * 获取磁盘信息
 */
const disk = async function () {
    const { diskPath, free, size } = await (0, check_disk_space_1.default)(__dirname);
    return {
        diskPath,
        diskFree: (0, common_util_1.deal)(free),
        diskTotal: size ? (0, common_util_1.deal)(size) : '未知',
        diskUsed: size ? (0, common_util_1.deal)(size - free) : '未知'
    };
};
exports.disk = disk;
// 获得请求IP
const getReqIP = (ctx) => {
    const req = ctx.req;
    return (req.headers['x-forwarded-for'] || // 判断是否有反向代理 IP
        req.connection.remoteAddress || // 判断 connection 的远程 IP
        req.socket.remoteAddress || // 判断后端的 socket 的 IP
        req.connection.socket.remoteAddress).replace('::ffff:', '');
};
exports.getReqIP = getReqIP;
// 根据IP获得请求地址
const getIpAddr = async (ctx, ip) => {
    try {
        if (!ip) {
            ip = await (0, exports.getReqIP)(ctx);
        }
        const bst = new ipdb.BaseStation(path.join(__dirname, '/ipipfree.ipdb'));
        const result = bst.findInfo(ip, 'CN');
        const addArr = [];
        if (result) {
            addArr.push(result.countryName);
            addArr.push(result.regionName);
            addArr.push(result.cityName);
            return _.uniq(addArr).join('');
        }
    }
    catch (err) {
        return '无法获取地址信息';
    }
};
exports.getIpAddr = getIpAddr;
const sleep = (ms) => {
    return new Promise((resolve) => setTimeout(resolve, ms));
};
exports.sleep = sleep;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3lzdGVtLnV0aWwuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi9zcmMvdXRpbHMvc3lzdGVtLnV0aWwudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEseUJBQXdCO0FBQ3hCLHVEQUE2QztBQUU3QywrQ0FBb0M7QUFFcEMsNEJBQTJCO0FBQzNCLGtDQUFpQztBQUNqQyw2QkFBNEI7QUFDNUI7O0dBRUc7QUFDSSxNQUFNLE1BQU0sR0FBRztJQUNwQixNQUFNLFdBQVcsR0FBRyxFQUFFLENBQUMsUUFBUSxFQUFFLENBQUE7SUFDakMsTUFBTSxVQUFVLEdBQUcsRUFBRSxDQUFDLE9BQU8sRUFBRSxDQUFBO0lBQy9CLE1BQU0sV0FBVyxHQUFHLElBQUEsa0JBQUksRUFBQyxXQUFXLENBQUMsQ0FBQTtJQUNyQyxNQUFNLFVBQVUsR0FBRyxJQUFBLGtCQUFJLEVBQUMsVUFBVSxDQUFDLENBQUE7SUFDbkMsTUFBTSxVQUFVLEdBQUcsSUFBQSxrQkFBSSxFQUFDLFdBQVcsR0FBRyxVQUFVLENBQUMsQ0FBQTtJQUNqRCxPQUFPLEVBQUUsV0FBVyxFQUFFLFVBQVUsRUFBRSxVQUFVLEVBQUUsQ0FBQTtBQUNoRCxDQUFDLENBQUE7QUFQWSxRQUFBLE1BQU0sVUFPbEI7QUFFRDs7R0FFRztBQUNJLE1BQU0sSUFBSSxHQUFHLEtBQUs7SUFDdkIsTUFBTSxFQUFFLFFBQVEsRUFBRSxJQUFJLEVBQUUsSUFBSSxFQUFFLEdBQUcsTUFBTSxJQUFBLDBCQUFjLEVBQUMsU0FBUyxDQUFDLENBQUE7SUFDaEUsT0FBTztRQUNMLFFBQVE7UUFDUixRQUFRLEVBQUUsSUFBQSxrQkFBSSxFQUFDLElBQUksQ0FBQztRQUNwQixTQUFTLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFBLGtCQUFJLEVBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUk7UUFDbkMsUUFBUSxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUMsSUFBQSxrQkFBSSxFQUFDLElBQUksR0FBRyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSTtLQUMxQyxDQUFBO0FBQ0gsQ0FBQyxDQUFBO0FBUlksUUFBQSxJQUFJLFFBUWhCO0FBRUQsU0FBUztBQUNGLE1BQU0sUUFBUSxHQUFHLENBQUMsR0FBWSxFQUFFLEVBQUU7SUFDdkMsTUFBTSxHQUFHLEdBQVEsR0FBRyxDQUFDLEdBQUcsQ0FBQTtJQUN4QixPQUFPLENBQ0wsR0FBRyxDQUFDLE9BQU8sQ0FBQyxpQkFBaUIsQ0FBQyxJQUFJLGVBQWU7UUFDakQsR0FBRyxDQUFDLFVBQVUsQ0FBQyxhQUFhLElBQUksdUJBQXVCO1FBQ3ZELEdBQUcsQ0FBQyxNQUFNLENBQUMsYUFBYSxJQUFJLG9CQUFvQjtRQUNoRCxHQUFHLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxhQUFhLENBQ3BDLENBQUMsT0FBTyxDQUFDLFNBQVMsRUFBRSxFQUFFLENBQUMsQ0FBQTtBQUMxQixDQUFDLENBQUE7QUFSWSxRQUFBLFFBQVEsWUFRcEI7QUFFRCxhQUFhO0FBQ04sTUFBTSxTQUFTLEdBQUcsS0FBSyxFQUFFLEdBQVksRUFBRSxFQUFzQixFQUFFLEVBQUU7SUFDdEUsSUFBSTtRQUNGLElBQUksQ0FBQyxFQUFFLEVBQUU7WUFDUCxFQUFFLEdBQUcsTUFBTSxJQUFBLGdCQUFRLEVBQUMsR0FBRyxDQUFDLENBQUE7U0FDekI7UUFDRCxNQUFNLEdBQUcsR0FBRyxJQUFJLElBQUksQ0FBQyxXQUFXLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsZ0JBQWdCLENBQUMsQ0FBQyxDQUFBO1FBQ3hFLE1BQU0sTUFBTSxHQUFHLEdBQUcsQ0FBQyxRQUFRLENBQUMsRUFBRSxFQUFFLElBQUksQ0FBQyxDQUFBO1FBQ3JDLE1BQU0sTUFBTSxHQUFRLEVBQUUsQ0FBQTtRQUN0QixJQUFJLE1BQU0sRUFBRTtZQUNWLE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxDQUFBO1lBQy9CLE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxDQUFBO1lBQzlCLE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxDQUFBO1lBQzVCLE9BQU8sQ0FBQyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsQ0FBQyxJQUFJLENBQUMsRUFBRSxDQUFDLENBQUE7U0FDL0I7S0FDRjtJQUFDLE9BQU8sR0FBRyxFQUFFO1FBQ1osT0FBTyxVQUFVLENBQUE7S0FDbEI7QUFDSCxDQUFDLENBQUE7QUFqQlksUUFBQSxTQUFTLGFBaUJyQjtBQUVNLE1BQU0sS0FBSyxHQUFHLENBQUMsRUFBVSxFQUFFLEVBQUU7SUFDbEMsT0FBTyxJQUFJLE9BQU8sQ0FBQyxDQUFDLE9BQU8sRUFBRSxFQUFFLENBQUMsVUFBVSxDQUFDLE9BQU8sRUFBRSxFQUFFLENBQUMsQ0FBQyxDQUFBO0FBQzFELENBQUMsQ0FBQTtBQUZZLFFBQUEsS0FBSyxTQUVqQiJ9