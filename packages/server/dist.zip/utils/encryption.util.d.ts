export declare const encryption: (str: string, salt?: string) => Promise<string>;
