"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.serviceVersionType = exports.getRandom = exports.deal = void 0;
const randomstring = require("randomstring");
const service_version_enum_1 = require("../shared/enum/service-version.enum");
/**
 * 字节数单位转换
 * @param mem 字节数
 */
const deal = (mem) => {
    let G = 0, M = 0, KB = 0;
    mem > 1 << 30 && (G = parseFloat((mem / (1 << 30)).toFixed(2)));
    mem > 1 << 20 &&
        mem < 1 << 30 &&
        (M = parseFloat((mem / (1 << 20)).toFixed(2)));
    mem > 1 << 10 &&
        mem > 1 << 20 &&
        (KB = parseFloat((mem / (1 << 10)).toFixed(2)));
    return G > 0 ? G + 'G' : M > 0 ? M + 'M' : KB > 0 ? KB + 'KB' : mem + 'B';
};
exports.deal = deal;
/**
 * 随机数
 * @param length
 * @param charset
 */
const getRandom = (length = 15, charset = 'alphabetic') => {
    return randomstring.generate({
        length,
        charset
    });
};
exports.getRandom = getRandom;
/**
 * 获取路由类型,管理端还是客户端
 * @param path 请求地址
 */
const serviceVersionType = (path) => {
    const prefix = path.split('/')[1];
    switch (prefix) {
        case 'admin':
            return service_version_enum_1.ServiceVersionEnum.ADMIN;
        case 'client':
            return service_version_enum_1.ServiceVersionEnum.CLIENT;
        case 'open':
            return service_version_enum_1.ServiceVersionEnum.OPEN;
        case 'common':
            return service_version_enum_1.ServiceVersionEnum.COMMON;
    }
};
exports.serviceVersionType = serviceVersionType;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29tbW9uLnV0aWwuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi9zcmMvdXRpbHMvY29tbW9uLnV0aWwudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEsNkNBQTRDO0FBQzVDLDhFQUF3RTtBQUV4RTs7O0dBR0c7QUFDSSxNQUFNLElBQUksR0FBRyxDQUFDLEdBQVcsRUFBRSxFQUFFO0lBQ2xDLElBQUksQ0FBQyxHQUFHLENBQUMsRUFDUCxDQUFDLEdBQUcsQ0FBQyxFQUNMLEVBQUUsR0FBRyxDQUFDLENBQUE7SUFDUixHQUFHLEdBQUcsQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDLENBQUMsR0FBRyxVQUFVLENBQUMsQ0FBQyxHQUFHLEdBQUcsQ0FBQyxDQUFDLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQyxPQUFPLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFBO0lBQy9ELEdBQUcsR0FBRyxDQUFDLElBQUksRUFBRTtRQUNYLEdBQUcsR0FBRyxDQUFDLElBQUksRUFBRTtRQUNiLENBQUMsQ0FBQyxHQUFHLFVBQVUsQ0FBQyxDQUFDLEdBQUcsR0FBRyxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDLE9BQU8sQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUE7SUFDaEQsR0FBRyxHQUFHLENBQUMsSUFBSSxFQUFFO1FBQ1gsR0FBRyxHQUFHLENBQUMsSUFBSSxFQUFFO1FBQ2IsQ0FBQyxFQUFFLEdBQUcsVUFBVSxDQUFDLENBQUMsR0FBRyxHQUFHLENBQUMsQ0FBQyxJQUFJLEVBQUUsQ0FBQyxDQUFDLENBQUMsT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQTtJQUNqRCxPQUFPLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLENBQUMsR0FBRyxHQUFHLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsR0FBRyxJQUFJLENBQUMsQ0FBQyxDQUFDLEdBQUcsR0FBRyxHQUFHLENBQUE7QUFDM0UsQ0FBQyxDQUFBO0FBWlksUUFBQSxJQUFJLFFBWWhCO0FBRUQ7Ozs7R0FJRztBQUNJLE1BQU0sU0FBUyxHQUFHLENBQUMsTUFBTSxHQUFHLEVBQUUsRUFBRSxPQUFPLEdBQUcsWUFBWSxFQUFFLEVBQUU7SUFDL0QsT0FBTyxZQUFZLENBQUMsUUFBUSxDQUFDO1FBQzNCLE1BQU07UUFDTixPQUFPO0tBQ1IsQ0FBQyxDQUFBO0FBQ0osQ0FBQyxDQUFBO0FBTFksUUFBQSxTQUFTLGFBS3JCO0FBRUQ7OztHQUdHO0FBQ0ksTUFBTSxrQkFBa0IsR0FBRyxDQUFDLElBQVksRUFBc0IsRUFBRTtJQUNyRSxNQUFNLE1BQU0sR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDLENBQUMsQ0FBQyxDQUFBO0lBQ2pDLFFBQVEsTUFBTSxFQUFFO1FBQ2QsS0FBSyxPQUFPO1lBQ1YsT0FBTyx5Q0FBa0IsQ0FBQyxLQUFLLENBQUE7UUFDakMsS0FBSyxRQUFRO1lBQ1gsT0FBTyx5Q0FBa0IsQ0FBQyxNQUFNLENBQUE7UUFDbEMsS0FBSyxNQUFNO1lBQ1QsT0FBTyx5Q0FBa0IsQ0FBQyxJQUFJLENBQUE7UUFDaEMsS0FBSyxRQUFRO1lBQ1gsT0FBTyx5Q0FBa0IsQ0FBQyxNQUFNLENBQUE7S0FDbkM7QUFDSCxDQUFDLENBQUE7QUFaWSxRQUFBLGtCQUFrQixzQkFZOUIifQ==