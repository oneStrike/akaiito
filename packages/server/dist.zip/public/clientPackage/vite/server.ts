import type { ServerOptions } from 'vite'

export const viteServer: ServerOptions = {
  port: 3300
}
