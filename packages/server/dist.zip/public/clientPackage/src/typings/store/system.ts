export type { AdminSystemConfigRes } from "@akaiito/typings/src/admin/apiTypes/clientManage";


