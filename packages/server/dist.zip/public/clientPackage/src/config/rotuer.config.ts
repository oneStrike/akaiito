/*
 * 路由白名单
 * */

export const routerWhiteList = ["/pages/guide/guide", "/pages/tab-bar/home/home"];
