/*
 * 路由白名单
 * */

export const routerWhiteList = ['pages/guide/guide']
