export const dev = {
	BASE_URL: "http://192.168.2.19:7001",
	FILE_PATH: "http://192.168.2.19:7001/public/upload/files/",
	REQUEST_PREFIX: "/client",
	UPLOAD_URL: "foo/common/upload/upload"
};
