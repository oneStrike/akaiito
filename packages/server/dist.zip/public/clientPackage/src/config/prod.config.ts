export const prod = {
  BASE_URL: 'http://192.168.2.10:7001',
  FILE_PATH: 'http://192.168.2.10:7001/public/upload/files/',
  REQUEST_PREFIX: '/client',
  UPLOAD_URL: 'common/upload/upload'
}
