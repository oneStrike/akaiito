export const useSystem = {
  appPlatform: plus.os.name?.toLowerCase() as 'android' | 'ios'
}
