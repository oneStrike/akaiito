export enum StorageEnum {
  FIRST_ENTERING = 'first_entering'
}
