<script setup lang="ts"></script>

<template>
  <lk-page custom-nav-bar>
    <text class="fs16">我是首页</text>
  </lk-page>
</template>
