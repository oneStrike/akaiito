"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.JwtGuard = void 0;
const core_1 = require("@midwayjs/core");
const jwt_1 = require("@midwayjs/jwt");
let JwtGuard = class JwtGuard {
    async canActivate(context) {
        if (!this.ignoreUrl(context)) {
            const token = context.get('Authorization');
            if (!token)
                throw new core_1.httpError.UnauthorizedError();
            try {
                context.setAttr('userInfo', await this.jwtService.verify(token));
                return true;
            }
            catch (e) {
                return false;
            }
        }
        else {
            return true;
        }
    }
    ignoreUrl(context) {
        let { url } = context;
        const openUrlReg = new RegExp('^/?.*open|client/').test(url);
        url = url.split('?')[0];
        return openUrlReg || this.routerWhitelist.includes(url);
    }
};
__decorate([
    (0, core_1.Config)('whitelist'),
    __metadata("design:type", Array)
], JwtGuard.prototype, "routerWhitelist", void 0);
__decorate([
    (0, core_1.Inject)(),
    __metadata("design:type", jwt_1.JwtService)
], JwtGuard.prototype, "jwtService", void 0);
JwtGuard = __decorate([
    (0, core_1.Guard)()
], JwtGuard);
exports.JwtGuard = JwtGuard;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiand0Lmd1YXJkLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vc3JjL2d1YXJkL2p3dC5ndWFyZC50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7QUFBQSx5Q0FBeUU7QUFFekUsdUNBQTBDO0FBR25DLElBQU0sUUFBUSxHQUFkLE1BQU0sUUFBUTtJQU9uQixLQUFLLENBQUMsV0FBVyxDQUFDLE9BQWdCO1FBQ2hDLElBQUksQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLE9BQU8sQ0FBQyxFQUFFO1lBQzVCLE1BQU0sS0FBSyxHQUFHLE9BQU8sQ0FBQyxHQUFHLENBQUMsZUFBZSxDQUFDLENBQUE7WUFDMUMsSUFBSSxDQUFDLEtBQUs7Z0JBQUUsTUFBTSxJQUFJLGdCQUFTLENBQUMsaUJBQWlCLEVBQUUsQ0FBQTtZQUNuRCxJQUFJO2dCQUNGLE9BQU8sQ0FBQyxPQUFPLENBQUMsVUFBVSxFQUFFLE1BQU0sSUFBSSxDQUFDLFVBQVUsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQTtnQkFDaEUsT0FBTyxJQUFJLENBQUE7YUFDWjtZQUFDLE9BQU8sQ0FBQyxFQUFFO2dCQUNWLE9BQU8sS0FBSyxDQUFBO2FBQ2I7U0FDRjthQUFNO1lBQ0wsT0FBTyxJQUFJLENBQUE7U0FDWjtJQUNILENBQUM7SUFFRCxTQUFTLENBQUMsT0FBZ0I7UUFDeEIsSUFBSSxFQUFFLEdBQUcsRUFBRSxHQUFHLE9BQU8sQ0FBQTtRQUNyQixNQUFNLFVBQVUsR0FBRyxJQUFJLE1BQU0sQ0FBQyxtQkFBbUIsQ0FBQyxDQUFDLElBQUksQ0FBQyxHQUFHLENBQUMsQ0FBQTtRQUM1RCxHQUFHLEdBQUcsR0FBRyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQTtRQUN2QixPQUFPLFVBQVUsSUFBSSxJQUFJLENBQUMsZUFBZSxDQUFDLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQTtJQUN6RCxDQUFDO0NBQ0YsQ0FBQTtBQTNCQztJQUFDLElBQUEsYUFBTSxFQUFDLFdBQVcsQ0FBQzs7aURBQ0s7QUFFekI7SUFBQyxJQUFBLGFBQU0sR0FBRTs4QkFDRyxnQkFBVTs0Q0FBQTtBQUxYLFFBQVE7SUFEcEIsSUFBQSxZQUFLLEdBQUU7R0FDSyxRQUFRLENBNEJwQjtBQTVCWSw0QkFBUSJ9