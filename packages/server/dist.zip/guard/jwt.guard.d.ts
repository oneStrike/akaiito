import { IGuard } from '@midwayjs/core';
import { Context } from '@midwayjs/koa';
import { JwtService } from '@midwayjs/jwt';
export declare class JwtGuard implements IGuard<Context> {
    routerWhitelist: string[];
    jwtService: JwtService;
    canActivate(context: Context): Promise<boolean>;
    ignoreUrl(context: Context): boolean;
}
