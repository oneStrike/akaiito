"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = {
    sequelize: {
        dataSource: {
            default: {
                dialect: 'mysql',
                host: 'localhost',
                benchmark: true,
                port: 3306,
                username: 'root',
                password: '259158',
                database: 'foo',
                sync: true,
                entities: ['**/entities/**'],
                timezone: '+08:00',
                logging: false,
                define: {
                    timestamps: true,
                    charset: 'utf8mb4',
                    paranoid: false,
                    underscored: true,
                    freezeTableName: true //不会尝试更改模型名以获取表名。否则，型号名称将是复数
                },
                dialectOptions: {
                    // 此处配置将直接传给数据库
                    connectTimeout: 30000,
                    dateStrings: true,
                    typeCast: true,
                    bigNumberStrings: true // bigInt和decimal 以字符串返回
                },
                repositoryMode: true
            }
        }
    }
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29uZmlnLmxvY2FsLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vc3JjL2NvbmZpZy9jb25maWcubG9jYWwudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7QUFFQSxrQkFBZTtJQUNiLFNBQVMsRUFBRTtRQUNULFVBQVUsRUFBRTtZQUNWLE9BQU8sRUFBRTtnQkFDUCxPQUFPLEVBQUUsT0FBTztnQkFDaEIsSUFBSSxFQUFFLFdBQVc7Z0JBQ2pCLFNBQVMsRUFBRSxJQUFJO2dCQUNmLElBQUksRUFBRSxJQUFJO2dCQUNWLFFBQVEsRUFBRSxNQUFNO2dCQUNoQixRQUFRLEVBQUUsUUFBUTtnQkFDbEIsUUFBUSxFQUFFLEtBQUs7Z0JBQ2YsSUFBSSxFQUFFLElBQUk7Z0JBQ1YsUUFBUSxFQUFFLENBQUMsZ0JBQWdCLENBQUM7Z0JBQzVCLFFBQVEsRUFBRSxRQUFRO2dCQUNsQixPQUFPLEVBQUUsS0FBSztnQkFDZCxNQUFNLEVBQUU7b0JBQ04sVUFBVSxFQUFFLElBQUk7b0JBQ2hCLE9BQU8sRUFBRSxTQUFTO29CQUNsQixRQUFRLEVBQUUsS0FBSztvQkFDZixXQUFXLEVBQUUsSUFBSTtvQkFDakIsZUFBZSxFQUFFLElBQUksQ0FBQyw0QkFBNEI7aUJBQ25EO2dCQUNELGNBQWMsRUFBRTtvQkFDZCxlQUFlO29CQUNmLGNBQWMsRUFBRSxLQUFLO29CQUNyQixXQUFXLEVBQUUsSUFBSTtvQkFDakIsUUFBUSxFQUFFLElBQUk7b0JBQ2QsZ0JBQWdCLEVBQUUsSUFBSSxDQUFDLHdCQUF3QjtpQkFDaEQ7Z0JBQ0QsY0FBYyxFQUFFLElBQUk7YUFDckI7U0FDRjtLQUNGO0NBQ2MsQ0FBQSJ9