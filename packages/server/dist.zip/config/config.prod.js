"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.default = {
    sequelize: {
        dataSource: {
            default: {
                dialect: 'mysql',
                host: '127.0.0.1',
                benchmark: true,
                port: 3306,
                username: 'foo',
                password: '15839038112',
                database: 'foo',
                sync: true,
                entities: ['**/entities/**'],
                timezone: '+08:00',
                define: {
                    charset: 'utf8',
                    paranoid: true,
                    underscored: true,
                    freezeTableName: true //不会尝试更改模型名以获取表名。否则，型号名称将是复数
                },
                dialectOptions: {
                    // 此处配置将直接传给数据库
                    connectTimeout: 30000,
                    dateStrings: true,
                    typeCast: true,
                    bigNumberStrings: true // bigInt和decimal 以字符串返回
                },
                repositoryMode: true
            }
        }
    }
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29uZmlnLnByb2QuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi9zcmMvY29uZmlnL2NvbmZpZy5wcm9kLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBRUEsa0JBQWU7SUFDYixTQUFTLEVBQUU7UUFDVCxVQUFVLEVBQUU7WUFDVixPQUFPLEVBQUU7Z0JBQ1AsT0FBTyxFQUFFLE9BQU87Z0JBQ2hCLElBQUksRUFBRSxXQUFXO2dCQUNqQixTQUFTLEVBQUUsSUFBSTtnQkFDZixJQUFJLEVBQUUsSUFBSTtnQkFDVixRQUFRLEVBQUUsS0FBSztnQkFDZixRQUFRLEVBQUUsYUFBYTtnQkFDdkIsUUFBUSxFQUFFLEtBQUs7Z0JBQ2YsSUFBSSxFQUFFLElBQUk7Z0JBQ1YsUUFBUSxFQUFFLENBQUMsZ0JBQWdCLENBQUM7Z0JBQzVCLFFBQVEsRUFBRSxRQUFRO2dCQUNsQixNQUFNLEVBQUU7b0JBQ04sT0FBTyxFQUFFLE1BQU07b0JBQ2YsUUFBUSxFQUFFLElBQUk7b0JBQ2QsV0FBVyxFQUFFLElBQUk7b0JBQ2pCLGVBQWUsRUFBRSxJQUFJLENBQUMsNEJBQTRCO2lCQUNuRDtnQkFDRCxjQUFjLEVBQUU7b0JBQ2QsZUFBZTtvQkFDZixjQUFjLEVBQUUsS0FBSztvQkFDckIsV0FBVyxFQUFFLElBQUk7b0JBQ2pCLFFBQVEsRUFBRSxJQUFJO29CQUNkLGdCQUFnQixFQUFFLElBQUksQ0FBQyx3QkFBd0I7aUJBQ2hEO2dCQUNELGNBQWMsRUFBRSxJQUFJO2FBQ3JCO1NBQ0Y7S0FDRjtDQUNjLENBQUEifQ==