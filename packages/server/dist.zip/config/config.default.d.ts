import { MidwayConfig } from '@midwayjs/core';
declare const _default: MidwayConfig;
export default _default;
