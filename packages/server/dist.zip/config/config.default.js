"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
const path_1 = require("path");
const rootPath = (0, path_1.join)(__dirname, '../../');
exports.default = {
    keys: '1661312321096_4541',
    koa: {
        port: 7001
    },
    midwayLogger: {
        default: {
            dir: rootPath + '/logs'
        }
    },
    validate: {
        validationOptions: {
            allowUnknown: true,
            stripUnknown: true
        }
    },
    cors: {
        credentials: true
    }
};
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29uZmlnLmRlZmF1bHQuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi9zcmMvY29uZmlnL2NvbmZpZy5kZWZhdWx0LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7O0FBQ0EsK0JBQTJCO0FBQzNCLE1BQU0sUUFBUSxHQUFHLElBQUEsV0FBSSxFQUFDLFNBQVMsRUFBRSxRQUFRLENBQUMsQ0FBQTtBQUMxQyxrQkFBZTtJQUNiLElBQUksRUFBRSxvQkFBb0I7SUFDMUIsR0FBRyxFQUFFO1FBQ0gsSUFBSSxFQUFFLElBQUk7S0FDWDtJQUNELFlBQVksRUFBRTtRQUNaLE9BQU8sRUFBRTtZQUNQLEdBQUcsRUFBRSxRQUFRLEdBQUcsT0FBTztTQUN4QjtLQUNGO0lBQ0QsUUFBUSxFQUFFO1FBQ1IsaUJBQWlCLEVBQUU7WUFDakIsWUFBWSxFQUFFLElBQUk7WUFDbEIsWUFBWSxFQUFFLElBQUk7U0FDbkI7S0FDRjtJQUNELElBQUksRUFBRTtRQUNKLFdBQVcsRUFBRSxJQUFJO0tBQ2xCO0NBQ2MsQ0FBQSJ9