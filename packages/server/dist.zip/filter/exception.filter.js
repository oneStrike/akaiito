"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ExceptionFilter = void 0;
const core_1 = require("@midwayjs/core");
const log_service_1 = require("../service/admin/log/log.service");
let ExceptionFilter = class ExceptionFilter {
    async catch(err, ctx) {
        //记录日志
        ctx.logger.error(err);
        // @ts-ignore
        const errorFields = err.fields;
        let desc = "";
        let code;
        if (errorFields) {
            //触发MySQL的unique错误
            const key = Object.keys(errorFields)[0];
            desc = `【${key}】字段值重复，【${errorFields[key]}】已经存在`;
        }
        else if (err.cause) {
            const errorDetails = err?.cause["details"];
            code = 0;
            const { context, type } = errorDetails[0];
            if (type === "any.required") {
                desc = `【 ${context.label} 】参数丢失`;
            }
            else {
                desc = `【 ${context.label} 】校验失败！请确认【 ${context.value} 】是否正确`;
            }
        }
        else {
            switch (err.status) {
                case 400:
                    code = 400;
                    desc = err.message;
                    break;
                case 401:
                    code = 401;
                    desc = "鉴权信息缺失";
                    break;
                case 403:
                    code = 403;
                    desc = "登陆失效，请重新登陆";
                    break;
                case 404:
                    code = 404;
                    desc = "请求路径错误";
                    break;
                case 500:
                    code = 500;
                    desc = "内部服务错误";
                    break;
                case 413:
                    code = 413;
                    desc = "超出大小限制";
                    break;
                default:
                    code = 0;
                    desc = "未知错误";
            }
        }
        err.status = 200;
        const responseRes = {
            desc,
            code,
            data: null,
            status: "error"
        };
        ctx.setAttr("responseRes", responseRes);
        const baseSysLogService = await ctx.requestContext.getAsync(log_service_1.LogService);
        await baseSysLogService.record(ctx);
        return responseRes;
    }
};
__decorate([
    (0, core_1.Logger)("adminLogger"),
    __metadata("design:type", Object)
], ExceptionFilter.prototype, "logger", void 0);
ExceptionFilter = __decorate([
    (0, core_1.Catch)()
], ExceptionFilter);
exports.ExceptionFilter = ExceptionFilter;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZXhjZXB0aW9uLmZpbHRlci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9maWx0ZXIvZXhjZXB0aW9uLmZpbHRlci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7QUFBQSx5Q0FBZ0U7QUFHaEUsa0VBQThEO0FBR3ZELElBQU0sZUFBZSxHQUFyQixNQUFNLGVBQWU7SUFJMUIsS0FBSyxDQUFDLEtBQUssQ0FBQyxHQUFvQixFQUFFLEdBQVk7UUFDNUMsTUFBTTtRQUNOLEdBQUcsQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQ3RCLGFBQWE7UUFDYixNQUFNLFdBQVcsR0FBaUMsR0FBRyxDQUFDLE1BQU0sQ0FBQztRQUM3RCxJQUFJLElBQUksR0FBRyxFQUFFLENBQUM7UUFDZCxJQUFJLElBQTJCLENBQUM7UUFDaEMsSUFBSSxXQUFXLEVBQUU7WUFDZixrQkFBa0I7WUFDbEIsTUFBTSxHQUFHLEdBQUcsTUFBTSxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQztZQUN4QyxJQUFJLEdBQUcsSUFBSSxHQUFHLFdBQVcsV0FBVyxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUM7U0FDbEQ7YUFBTSxJQUFJLEdBQUcsQ0FBQyxLQUFLLEVBQUU7WUFDcEIsTUFBTSxZQUFZLEdBQUcsR0FBRyxFQUFFLEtBQUssQ0FBQyxTQUFTLENBQXFCLENBQUM7WUFDL0QsSUFBSSxHQUFHLENBQUMsQ0FBQztZQUNULE1BQU0sRUFBRSxPQUFPLEVBQUUsSUFBSSxFQUFFLEdBQUcsWUFBWSxDQUFDLENBQUMsQ0FBQyxDQUFDO1lBRTFDLElBQUksSUFBSSxLQUFLLGNBQWMsRUFBRTtnQkFDM0IsSUFBSSxHQUFHLEtBQUssT0FBTyxDQUFDLEtBQUssUUFBUSxDQUFDO2FBQ25DO2lCQUFNO2dCQUNMLElBQUksR0FBRyxLQUFLLE9BQU8sQ0FBQyxLQUFLLGVBQWUsT0FBTyxDQUFDLEtBQUssUUFBUSxDQUFDO2FBQy9EO1NBQ0Y7YUFBTTtZQUNMLFFBQVEsR0FBRyxDQUFDLE1BQU0sRUFBRTtnQkFDbEIsS0FBSyxHQUFHO29CQUNOLElBQUksR0FBRyxHQUFHLENBQUM7b0JBQ1gsSUFBSSxHQUFHLEdBQUcsQ0FBQyxPQUFPLENBQUM7b0JBQ25CLE1BQU07Z0JBQ1IsS0FBSyxHQUFHO29CQUNOLElBQUksR0FBRyxHQUFHLENBQUM7b0JBQ1gsSUFBSSxHQUFHLFFBQVEsQ0FBQztvQkFDaEIsTUFBTTtnQkFDUixLQUFLLEdBQUc7b0JBQ04sSUFBSSxHQUFHLEdBQUcsQ0FBQztvQkFDWCxJQUFJLEdBQUcsWUFBWSxDQUFDO29CQUNwQixNQUFNO2dCQUNSLEtBQUssR0FBRztvQkFDTixJQUFJLEdBQUcsR0FBRyxDQUFDO29CQUNYLElBQUksR0FBRyxRQUFRLENBQUM7b0JBQ2hCLE1BQU07Z0JBQ1IsS0FBSyxHQUFHO29CQUNOLElBQUksR0FBRyxHQUFHLENBQUM7b0JBQ1gsSUFBSSxHQUFHLFFBQVEsQ0FBQztvQkFDaEIsTUFBTTtnQkFDUixLQUFLLEdBQUc7b0JBQ04sSUFBSSxHQUFHLEdBQUcsQ0FBQztvQkFDWCxJQUFJLEdBQUcsUUFBUSxDQUFDO29CQUNoQixNQUFNO2dCQUNSO29CQUNFLElBQUksR0FBRyxDQUFDLENBQUM7b0JBQ1QsSUFBSSxHQUFHLE1BQU0sQ0FBQzthQUNqQjtTQUNGO1FBRUQsR0FBRyxDQUFDLE1BQU0sR0FBRyxHQUFHLENBQUM7UUFDakIsTUFBTSxXQUFXLEdBQUc7WUFDbEIsSUFBSTtZQUNKLElBQUk7WUFDSixJQUFJLEVBQUUsSUFBSTtZQUNWLE1BQU0sRUFBRSxPQUFPO1NBQ2hCLENBQUM7UUFDRixHQUFHLENBQUMsT0FBTyxDQUFDLGFBQWEsRUFBRSxXQUFXLENBQUMsQ0FBQztRQUN4QyxNQUFNLGlCQUFpQixHQUFHLE1BQU0sR0FBRyxDQUFDLGNBQWMsQ0FBQyxRQUFRLENBQUMsd0JBQVUsQ0FBQyxDQUFDO1FBQ3hFLE1BQU0saUJBQWlCLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQ3BDLE9BQU8sV0FBVyxDQUFDO0lBQ3JCLENBQUM7Q0FDRixDQUFBO0FBcEVDO0lBQUMsSUFBQSxhQUFNLEVBQUMsYUFBYSxDQUFDOzsrQ0FDZjtBQUZJLGVBQWU7SUFEM0IsSUFBQSxZQUFLLEdBQUU7R0FDSyxlQUFlLENBcUUzQjtBQXJFWSwwQ0FBZSJ9