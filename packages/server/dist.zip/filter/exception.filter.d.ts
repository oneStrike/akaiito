import { MidwayHttpError } from "@midwayjs/core";
import { Context } from "@midwayjs/koa";
export declare class ExceptionFilter {
    logger: any;
    catch(err: MidwayHttpError, ctx: Context): Promise<{
        desc: string;
        code: 0 | 1 | 400 | 404 | 401 | 403 | 413 | 500;
        data: any;
        status: string;
    }>;
}
