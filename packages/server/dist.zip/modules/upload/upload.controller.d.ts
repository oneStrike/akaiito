import { BaseController } from '../../shared/controller/base.controller';
import { UploadService } from './upload.service';
export declare class UploadController extends BaseController {
    uploadService: UploadService;
    upload(files: any, fields: any): Promise<unknown>;
}
