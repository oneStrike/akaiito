"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UploadService = void 0;
const core_1 = require("@midwayjs/core");
const config_service_1 = require("../../service/config.service");
const qiniu = require("qiniu");
const base_service_1 = require("../../shared/service/base.service");
let UploadService = class UploadService extends base_service_1.BaseService {
    constructor() {
        super(...arguments);
        this.qiniuReturnBody = '{"url":"$(key)","size":$(fsize),"hash":"$(etag)"}';
    }
    /**
     * 静态资源的存储方式
     */
    async publicFileStorageMethod(files, fields) {
        if (!fields.fileClassify) {
            for await (const file of files) {
                await this.utils.fs.remove(file.data);
            }
            return this.normalError('文件未分类');
        }
        return await this.putPolicy(files, fields);
    }
    async putPolicy(files, fields) {
        if (!files.length)
            return [];
        const { use, qiniu } = this.uploadConfig;
        switch (use) {
            case 'qiniu':
                return await this.qiniuPutPolicy(qiniu, files);
            case 'local':
                return await this.formatLocal(files, fields);
        }
    }
    async formatLocal(files, fields) {
        const { tmpdir } = this.uploadConfig;
        const storagePath = tmpdir + '/' + fields.fileClassify;
        await this.utils.fs.ensureDir(storagePath);
        const result = [];
        for await (const file of files) {
            const separator = file.data.includes('\\') ? '\\' : '/';
            const filePathArr = file.data.split(separator);
            const fileName = filePathArr[filePathArr.length - 1];
            await this.utils.fs.move(file.data, storagePath + '/' + fileName);
            result.push({
                filename: file.filename,
                path: fields.fileClassify + '/' + fileName,
                mimeType: file.mimeType,
                _ext: file._ext
            });
        }
        return result;
    }
    /**
     * 七牛存储
     * @param qiniuAuthParams
     * @param files
     * @param flag
     */
    async qiniuPutPolicy(qiniuAuthParams, files) {
        const { accessKey, secretKey, scope, expires } = qiniuAuthParams;
        const mac = new qiniu.auth.digest.Mac(accessKey, secretKey);
        const config = new qiniu.conf.Config({ zone: qiniu.zone.Zone_z2 });
        const formUploader = new qiniu.form_up.FormUploader(config);
        const putExtra = new qiniu.form_up.PutExtra();
        const fileCount = files.length;
        let uploadCount = 0;
        return new Promise((resolve, reject) => {
            for (let i = 0; i < files.length; i++) {
                const item = files[i];
                const fileName = `${this.utils
                    .dayjs()
                    .format('YYYY-MM-DD')}_${this.utils.dayjs().valueOf()}_${item.filename}`;
                const options = {
                    scope: scope,
                    expires,
                    returnBody: this.qiniuReturnBody
                };
                const key = fileName;
                const localFile = item.data;
                const putPolicy = new qiniu.rs.PutPolicy(options);
                const uploadToken = putPolicy.uploadToken(mac);
                formUploader.putFile(uploadToken, key, localFile, putExtra, (respErr, respBody, respInfo) => {
                    if (respInfo.statusCode !== 200) {
                        reject('上传失败');
                    }
                    uploadCount++;
                    if (uploadCount === fileCount)
                        resolve([respBody]);
                });
            }
        });
    }
};
__decorate([
    (0, core_1.Config)('upload'),
    __metadata("design:type", Object)
], UploadService.prototype, "uploadConfig", void 0);
__decorate([
    (0, core_1.Inject)(),
    __metadata("design:type", config_service_1.ConfigService)
], UploadService.prototype, "configService", void 0);
UploadService = __decorate([
    (0, core_1.Provide)()
], UploadService);
exports.UploadService = UploadService;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidXBsb2FkLnNlcnZpY2UuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi9zcmMvbW9kdWxlcy91cGxvYWQvdXBsb2FkLnNlcnZpY2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7O0FBQUEseUNBQXdEO0FBQ3hELGlFQUE0RDtBQUM1RCwrQkFBOEI7QUFHOUIsb0VBQStEO0FBSXhELElBQU0sYUFBYSxHQUFuQixNQUFNLGFBQWMsU0FBUSwwQkFBVztJQUF2Qzs7UUFDRyxvQkFBZSxHQUFHLG1EQUFtRCxDQUFBO0lBd0cvRSxDQUFDO0lBOUZDOztPQUVHO0lBQ0gsS0FBSyxDQUFDLHVCQUF1QixDQUFDLEtBQW9CLEVBQUUsTUFBTTtRQUN4RCxJQUFJLENBQUMsTUFBTSxDQUFDLFlBQVksRUFBRTtZQUN4QixJQUFJLEtBQUssRUFBRSxNQUFNLElBQUksSUFBSSxLQUFLLEVBQUU7Z0JBQzlCLE1BQU0sSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxJQUFJLENBQUMsQ0FBQTthQUN0QztZQUNELE9BQU8sSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsQ0FBQTtTQUNqQztRQUNELE9BQU8sTUFBTSxJQUFJLENBQUMsU0FBUyxDQUFDLEtBQUssRUFBRSxNQUFNLENBQUMsQ0FBQTtJQUM1QyxDQUFDO0lBRUQsS0FBSyxDQUFDLFNBQVMsQ0FBQyxLQUFvQixFQUFFLE1BQTJCO1FBQy9ELElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTTtZQUFFLE9BQU8sRUFBRSxDQUFBO1FBQzVCLE1BQU0sRUFBRSxHQUFHLEVBQUUsS0FBSyxFQUFFLEdBQUcsSUFBSSxDQUFDLFlBQVksQ0FBQTtRQUN4QyxRQUFRLEdBQUcsRUFBRTtZQUNYLEtBQUssT0FBTztnQkFDVixPQUFPLE1BQU0sSUFBSSxDQUFDLGNBQWMsQ0FBQyxLQUFLLEVBQUUsS0FBSyxDQUFDLENBQUE7WUFDaEQsS0FBSyxPQUFPO2dCQUNWLE9BQU8sTUFBTSxJQUFJLENBQUMsV0FBVyxDQUFDLEtBQUssRUFBRSxNQUFNLENBQUMsQ0FBQTtTQUMvQztJQUNILENBQUM7SUFFRCxLQUFLLENBQUMsV0FBVyxDQUFDLEtBQW9CLEVBQUUsTUFBMkI7UUFDakUsTUFBTSxFQUFFLE1BQU0sRUFBRSxHQUFHLElBQUksQ0FBQyxZQUFZLENBQUE7UUFDcEMsTUFBTSxXQUFXLEdBQUcsTUFBTSxHQUFHLEdBQUcsR0FBRyxNQUFNLENBQUMsWUFBWSxDQUFBO1FBQ3RELE1BQU0sSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsU0FBUyxDQUFDLFdBQVcsQ0FBQyxDQUFBO1FBQzFDLE1BQU0sTUFBTSxHQUFHLEVBQUUsQ0FBQTtRQUNqQixJQUFJLEtBQUssRUFBRSxNQUFNLElBQUksSUFBSSxLQUFLLEVBQUU7WUFDOUIsTUFBTSxTQUFTLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQyxRQUFRLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFBO1lBQ3ZELE1BQU0sV0FBVyxHQUFHLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLFNBQVMsQ0FBQyxDQUFBO1lBQzlDLE1BQU0sUUFBUSxHQUFHLFdBQVcsQ0FBQyxXQUFXLENBQUMsTUFBTSxHQUFHLENBQUMsQ0FBQyxDQUFBO1lBQ3BELE1BQU0sSUFBSSxDQUFDLEtBQUssQ0FBQyxFQUFFLENBQUMsSUFBSSxDQUFDLElBQUksQ0FBQyxJQUFJLEVBQUUsV0FBVyxHQUFHLEdBQUcsR0FBRyxRQUFRLENBQUMsQ0FBQTtZQUNqRSxNQUFNLENBQUMsSUFBSSxDQUFDO2dCQUNWLFFBQVEsRUFBRSxJQUFJLENBQUMsUUFBUTtnQkFDdkIsSUFBSSxFQUFFLE1BQU0sQ0FBQyxZQUFZLEdBQUcsR0FBRyxHQUFHLFFBQVE7Z0JBQzFDLFFBQVEsRUFBRSxJQUFJLENBQUMsUUFBUTtnQkFDdkIsSUFBSSxFQUFFLElBQUksQ0FBQyxJQUFJO2FBQ2hCLENBQUMsQ0FBQTtTQUNIO1FBQ0QsT0FBTyxNQUFNLENBQUE7SUFDZixDQUFDO0lBRUQ7Ozs7O09BS0c7SUFDSCxLQUFLLENBQUMsY0FBYyxDQUNsQixlQUF1QyxFQUN2QyxLQUFvQjtRQUVwQixNQUFNLEVBQUUsU0FBUyxFQUFFLFNBQVMsRUFBRSxLQUFLLEVBQUUsT0FBTyxFQUFFLEdBQUcsZUFBZSxDQUFBO1FBQ2hFLE1BQU0sR0FBRyxHQUFHLElBQUksS0FBSyxDQUFDLElBQUksQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLFNBQVMsRUFBRSxTQUFTLENBQUMsQ0FBQTtRQUMzRCxNQUFNLE1BQU0sR0FBRyxJQUFJLEtBQUssQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsSUFBSSxFQUFFLEtBQUssQ0FBQyxJQUFJLENBQUMsT0FBTyxFQUFFLENBQUMsQ0FBQTtRQUNsRSxNQUFNLFlBQVksR0FBRyxJQUFJLEtBQUssQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDLE1BQU0sQ0FBQyxDQUFBO1FBQzNELE1BQU0sUUFBUSxHQUFHLElBQUksS0FBSyxDQUFDLE9BQU8sQ0FBQyxRQUFRLEVBQUUsQ0FBQTtRQUM3QyxNQUFNLFNBQVMsR0FBRyxLQUFLLENBQUMsTUFBTSxDQUFBO1FBQzlCLElBQUksV0FBVyxHQUFHLENBQUMsQ0FBQTtRQUNuQixPQUFPLElBQUksT0FBTyxDQUFDLENBQUMsT0FBTyxFQUFFLE1BQU0sRUFBRSxFQUFFO1lBQ3JDLEtBQUssSUFBSSxDQUFDLEdBQUcsQ0FBQyxFQUFFLENBQUMsR0FBRyxLQUFLLENBQUMsTUFBTSxFQUFFLENBQUMsRUFBRSxFQUFFO2dCQUNyQyxNQUFNLElBQUksR0FBRyxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUE7Z0JBQ3JCLE1BQU0sUUFBUSxHQUFHLEdBQUcsSUFBSSxDQUFDLEtBQUs7cUJBQzNCLEtBQUssRUFBRTtxQkFDUCxNQUFNLENBQUMsWUFBWSxDQUFDLElBQUksSUFBSSxDQUFDLEtBQUssQ0FBQyxLQUFLLEVBQUUsQ0FBQyxPQUFPLEVBQUUsSUFDckQsSUFBSSxDQUFDLFFBQ1AsRUFBRSxDQUFBO2dCQUNGLE1BQU0sT0FBTyxHQUFHO29CQUNkLEtBQUssRUFBRSxLQUFLO29CQUNaLE9BQU87b0JBQ1AsVUFBVSxFQUFFLElBQUksQ0FBQyxlQUFlO2lCQUNqQyxDQUFBO2dCQUNELE1BQU0sR0FBRyxHQUFHLFFBQVEsQ0FBQTtnQkFDcEIsTUFBTSxTQUFTLEdBQUcsSUFBSSxDQUFDLElBQUksQ0FBQTtnQkFDM0IsTUFBTSxTQUFTLEdBQUcsSUFBSSxLQUFLLENBQUMsRUFBRSxDQUFDLFNBQVMsQ0FBQyxPQUFPLENBQUMsQ0FBQTtnQkFDakQsTUFBTSxXQUFXLEdBQUcsU0FBUyxDQUFDLFdBQVcsQ0FBQyxHQUFHLENBQUMsQ0FBQTtnQkFDOUMsWUFBWSxDQUFDLE9BQU8sQ0FDbEIsV0FBVyxFQUNYLEdBQUcsRUFDSCxTQUFTLEVBQ1QsUUFBUSxFQUNSLENBQUMsT0FBTyxFQUFFLFFBQVEsRUFBRSxRQUFRLEVBQUUsRUFBRTtvQkFDOUIsSUFBSSxRQUFRLENBQUMsVUFBVSxLQUFLLEdBQUcsRUFBRTt3QkFDL0IsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFBO3FCQUNmO29CQUNELFdBQVcsRUFBRSxDQUFBO29CQUNiLElBQUksV0FBVyxLQUFLLFNBQVM7d0JBQUUsT0FBTyxDQUFDLENBQUMsUUFBUSxDQUFDLENBQUMsQ0FBQTtnQkFDcEQsQ0FBQyxDQUNGLENBQUE7YUFDRjtRQUNILENBQUMsQ0FBQyxDQUFBO0lBQ0osQ0FBQztDQUNGLENBQUE7QUF0R0M7SUFBQyxJQUFBLGFBQU0sRUFBQyxRQUFRLENBQUM7O21EQUNVO0FBRTNCO0lBQUMsSUFBQSxhQUFNLEdBQUU7OEJBQ00sOEJBQWE7b0RBQUE7QUFQakIsYUFBYTtJQUR6QixJQUFBLGNBQU8sR0FBRTtHQUNHLGFBQWEsQ0F5R3pCO0FBekdZLHNDQUFhIn0=