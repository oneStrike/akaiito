import { ConfigService } from '../../service/config.service';
import { IUploadConfig } from '../../types/service/config';
import { IUploadFile } from '../../types/service/upload';
import { BaseService } from '../../shared/service/base.service';
import { BaseMapping } from '../../shared/mapping/base.mapping';
export declare class UploadService extends BaseService {
    private qiniuReturnBody;
    uploadConfig: IUploadConfig;
    configService: ConfigService;
    protected mapping: BaseMapping;
    /**
     * 静态资源的存储方式
     */
    publicFileStorageMethod(files: IUploadFile[], fields: any): Promise<unknown>;
    putPolicy(files: IUploadFile[], fields: Record<string, any>): Promise<unknown>;
    formatLocal(files: IUploadFile[], fields: Record<string, any>): Promise<any[]>;
    /**
     * 七牛存储
     * @param qiniuAuthParams
     * @param files
     * @param flag
     */
    qiniuPutPolicy(qiniuAuthParams: IUploadConfig['qiniu'], files: IUploadFile[]): Promise<unknown>;
}
