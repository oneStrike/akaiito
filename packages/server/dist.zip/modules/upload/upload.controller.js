"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
var __param = (this && this.__param) || function (paramIndex, decorator) {
    return function (target, key) { decorator(target, key, paramIndex); }
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UploadController = void 0;
const core_1 = require("@midwayjs/core");
const base_controller_1 = require("../../shared/controller/base.controller");
const upload_service_1 = require("./upload.service");
let UploadController = class UploadController extends base_controller_1.BaseController {
    async upload(files, fields) {
        return await this.uploadService.publicFileStorageMethod(files, fields);
    }
};
__decorate([
    (0, core_1.Inject)(),
    __metadata("design:type", upload_service_1.UploadService)
], UploadController.prototype, "uploadService", void 0);
__decorate([
    (0, core_1.Post)('/upload', { summary: '上传静态资源' }),
    __param(0, (0, core_1.Files)()),
    __param(1, (0, core_1.Fields)()),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object, Object]),
    __metadata("design:returntype", Promise)
], UploadController.prototype, "upload", null);
UploadController = __decorate([
    (0, core_1.Controller)('/common/upload')
], UploadController);
exports.UploadController = UploadController;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidXBsb2FkLmNvbnRyb2xsZXIuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi9zcmMvbW9kdWxlcy91cGxvYWQvdXBsb2FkLmNvbnRyb2xsZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7Ozs7O0FBQUEseUNBQXdFO0FBQ3hFLDZFQUF3RTtBQUN4RSxxREFBZ0Q7QUFFekMsSUFBTSxnQkFBZ0IsR0FBdEIsTUFBTSxnQkFBaUIsU0FBUSxnQ0FBYztJQUs1QyxBQUFOLEtBQUssQ0FBQyxNQUFNLENBQVUsS0FBSyxFQUFZLE1BQU07UUFDM0MsT0FBTyxNQUFNLElBQUksQ0FBQyxhQUFhLENBQUMsdUJBQXVCLENBQUMsS0FBSyxFQUFFLE1BQU0sQ0FBQyxDQUFBO0lBQ3hFLENBQUM7Q0FDRixDQUFBO0FBUEM7SUFBQyxJQUFBLGFBQU0sR0FBRTs4QkFDTSw4QkFBYTt1REFBQTtBQUd0QjtJQURMLElBQUEsV0FBSSxFQUFDLFNBQVMsRUFBRSxFQUFFLE9BQU8sRUFBRSxRQUFRLEVBQUUsQ0FBQztJQUN6QixXQUFBLElBQUEsWUFBSyxHQUFFLENBQUE7SUFBUyxXQUFBLElBQUEsYUFBTSxHQUFFLENBQUE7Ozs7OENBRXJDO0FBUFUsZ0JBQWdCO0lBRDVCLElBQUEsaUJBQVUsRUFBQyxnQkFBZ0IsQ0FBQztHQUNoQixnQkFBZ0IsQ0FRNUI7QUFSWSw0Q0FBZ0IifQ==