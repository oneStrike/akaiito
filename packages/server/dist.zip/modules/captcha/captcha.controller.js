"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CaptchaController = void 0;
const core_1 = require("@midwayjs/core");
const base_controller_1 = require("../../shared/controller/base.controller");
const captcha_service_1 = require("./captcha.service");
let CaptchaController = class CaptchaController extends base_controller_1.BaseController {
    async captcha() {
        const { id, imageBase64 } = await this.captchaService.generateCaptcha();
        this.ctx.session.captchaId = id;
        return {
            data: imageBase64,
            id
        };
    }
};
__decorate([
    (0, core_1.Inject)(),
    __metadata("design:type", captcha_service_1.CaptchaServiceOpen)
], CaptchaController.prototype, "captchaService", void 0);
__decorate([
    (0, core_1.Get)('/getCaptcha'),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], CaptchaController.prototype, "captcha", null);
CaptchaController = __decorate([
    (0, core_1.Controller)('/open/captcha')
], CaptchaController);
exports.CaptchaController = CaptchaController;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2FwdGNoYS5jb250cm9sbGVyLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vc3JjL21vZHVsZXMvY2FwdGNoYS9jYXB0Y2hhLmNvbnRyb2xsZXIudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7O0FBQUEseUNBQXdEO0FBQ3hELDZFQUF3RTtBQUN4RSx1REFBc0Q7QUFHL0MsSUFBTSxpQkFBaUIsR0FBdkIsTUFBTSxpQkFBa0IsU0FBUSxnQ0FBYztJQUs3QyxBQUFOLEtBQUssQ0FBQyxPQUFPO1FBQ1gsTUFBTSxFQUFFLEVBQUUsRUFBRSxXQUFXLEVBQUUsR0FBRyxNQUFNLElBQUksQ0FBQyxjQUFjLENBQUMsZUFBZSxFQUFFLENBQUE7UUFDdkUsSUFBSSxDQUFDLEdBQUcsQ0FBQyxPQUFPLENBQUMsU0FBUyxHQUFHLEVBQUUsQ0FBQTtRQUMvQixPQUFPO1lBQ0wsSUFBSSxFQUFFLFdBQVc7WUFDakIsRUFBRTtTQUNILENBQUE7SUFDSCxDQUFDO0NBQ0YsQ0FBQTtBQVpDO0lBQUMsSUFBQSxhQUFNLEdBQUU7OEJBQ08sb0NBQWtCO3lEQUFBO0FBRzVCO0lBREwsSUFBQSxVQUFHLEVBQUMsYUFBYSxDQUFDOzs7O2dEQVFsQjtBQVpVLGlCQUFpQjtJQUQ3QixJQUFBLGlCQUFVLEVBQUMsZUFBZSxDQUFDO0dBQ2YsaUJBQWlCLENBYTdCO0FBYlksOENBQWlCIn0=