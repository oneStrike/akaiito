import { BaseController } from '../../shared/controller/base.controller';
import { CaptchaServiceOpen } from './captcha.service';
export declare class CaptchaController extends BaseController {
    captchaService: CaptchaServiceOpen;
    captcha(): Promise<{
        data: string;
        id: string;
    }>;
}
