import { CaptchaService } from '@midwayjs/captcha';
export declare class CaptchaServiceOpen {
    captchaService: CaptchaService;
    /**
     * 生成验证码，计算表达式
     * @returns
     */
    generateCaptcha(): Promise<{
        id: string;
        imageBase64: string;
    }>;
    /**
     * 校验验证码
     */
    captchaCheck(captchaId: string, value: string): Promise<boolean>;
}
