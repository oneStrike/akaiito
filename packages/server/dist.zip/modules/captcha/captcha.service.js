"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.CaptchaServiceOpen = void 0;
const core_1 = require("@midwayjs/core");
const captcha_1 = require("@midwayjs/captcha");
let CaptchaServiceOpen = class CaptchaServiceOpen {
    /**
     * 生成验证码，计算表达式
     * @returns
     */
    async generateCaptcha() {
        return await this.captchaService.formula({ noise: 3 });
    }
    /**
     * 校验验证码
     */
    async captchaCheck(captchaId, value) {
        return await this.captchaService.check(captchaId, value);
    }
};
__decorate([
    (0, core_1.Inject)(),
    __metadata("design:type", captcha_1.CaptchaService
    /**
     * 生成验证码，计算表达式
     * @returns
     */
    )
], CaptchaServiceOpen.prototype, "captchaService", void 0);
CaptchaServiceOpen = __decorate([
    (0, core_1.Provide)()
], CaptchaServiceOpen);
exports.CaptchaServiceOpen = CaptchaServiceOpen;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY2FwdGNoYS5zZXJ2aWNlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vc3JjL21vZHVsZXMvY2FwdGNoYS9jYXB0Y2hhLnNlcnZpY2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7O0FBQUEseUNBQWdEO0FBQ2hELCtDQUFrRDtBQUUzQyxJQUFNLGtCQUFrQixHQUF4QixNQUFNLGtCQUFrQjtJQUk3Qjs7O09BR0c7SUFDSCxLQUFLLENBQUMsZUFBZTtRQUNuQixPQUFPLE1BQU0sSUFBSSxDQUFDLGNBQWMsQ0FBQyxPQUFPLENBQUMsRUFBRSxLQUFLLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQTtJQUN4RCxDQUFDO0lBRUQ7O09BRUc7SUFDSCxLQUFLLENBQUMsWUFBWSxDQUFDLFNBQWlCLEVBQUUsS0FBYTtRQUNqRCxPQUFPLE1BQU0sSUFBSSxDQUFDLGNBQWMsQ0FBQyxLQUFLLENBQUMsU0FBUyxFQUFFLEtBQUssQ0FBQyxDQUFBO0lBQzFELENBQUM7Q0FDRixDQUFBO0FBakJDO0lBQUMsSUFBQSxhQUFNLEdBQUU7OEJBQ08sd0JBQWM7SUFFOUI7OztPQUdHOzswREFMMkI7QUFGbkIsa0JBQWtCO0lBRDlCLElBQUEsY0FBTyxHQUFFO0dBQ0csa0JBQWtCLENBa0I5QjtBQWxCWSxnREFBa0IifQ==