import { JwtService } from '@midwayjs/jwt';
export declare class AuthService {
    jwt: JwtService;
    jwtConfig: any;
    /**
     * 生成token
     */
    generateToken(user: any, isRefresh?: boolean): Promise<string>;
}
