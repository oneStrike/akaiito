import { BaseService } from '../shared/service/base.service';
import { InfoService } from '@midwayjs/info';
import { BaseMapping } from '../shared/mapping/base.mapping';
export declare class SystemService extends BaseService {
    infoService: InfoService;
    mapping: BaseMapping;
    /**
     * 获取系统基本信息
     */
    getSystemInfo(): Promise<{
        diskPath: string;
        diskFree: string;
        diskTotal: string;
        diskUsed: string;
        memoryTotal: string;
        memoryFree: string;
        memoryUsed: string;
        platform: string | number;
        node: string | number;
        v8: string | number;
        serverTime: string | number;
        Uptime: string | number;
        cpu: string | number;
        cpuUsage: string | number;
    }>;
}
