"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SystemService = void 0;
const core_1 = require("@midwayjs/core");
const base_service_1 = require("../shared/service/base.service");
const info_1 = require("@midwayjs/info");
const base_mapping_1 = require("../shared/mapping/base.mapping");
let SystemService = class SystemService extends base_service_1.BaseService {
    /**
     * 获取系统基本信息
     */
    async getSystemInfo() {
        const { Platform, Node, V8 } = this.infoService.systemInfo().info;
        const { Current, Uptime } = this.infoService.timeInfo().info;
        const resourceOccupationInfo = this.infoService.resourceOccupationInfo().info;
        return {
            platform: Platform,
            node: Node,
            v8: V8,
            serverTime: Current,
            Uptime,
            cpu: resourceOccupationInfo['CPU'],
            cpuUsage: resourceOccupationInfo['CPU Usage'],
            ...this.utils.systemUtil.memory(),
            ...(await this.utils.systemUtil.disk())
        };
    }
};
__decorate([
    (0, core_1.Inject)(),
    __metadata("design:type", info_1.InfoService)
], SystemService.prototype, "infoService", void 0);
__decorate([
    (0, core_1.Inject)(),
    __metadata("design:type", base_mapping_1.BaseMapping
    /**
     * 获取系统基本信息
     */
    )
], SystemService.prototype, "mapping", void 0);
SystemService = __decorate([
    (0, core_1.Provide)()
], SystemService);
exports.SystemService = SystemService;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic3lzdGVtLnNlcnZpY2UuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi9zcmMvc2VydmljZS9zeXN0ZW0uc2VydmljZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7QUFBQSx5Q0FBZ0Q7QUFDaEQsaUVBQTREO0FBQzVELHlDQUE0QztBQUM1QyxpRUFBNEQ7QUFHckQsSUFBTSxhQUFhLEdBQW5CLE1BQU0sYUFBYyxTQUFRLDBCQUFXO0lBTzVDOztPQUVHO0lBQ0gsS0FBSyxDQUFDLGFBQWE7UUFDakIsTUFBTSxFQUFFLFFBQVEsRUFBRSxJQUFJLEVBQUUsRUFBRSxFQUFFLEdBQUcsSUFBSSxDQUFDLFdBQVcsQ0FBQyxVQUFVLEVBQUUsQ0FBQyxJQUFJLENBQUE7UUFDakUsTUFBTSxFQUFFLE9BQU8sRUFBRSxNQUFNLEVBQUUsR0FBRyxJQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsRUFBRSxDQUFDLElBQUksQ0FBQTtRQUM1RCxNQUFNLHNCQUFzQixHQUMxQixJQUFJLENBQUMsV0FBVyxDQUFDLHNCQUFzQixFQUFFLENBQUMsSUFBSSxDQUFBO1FBQ2hELE9BQU87WUFDTCxRQUFRLEVBQUUsUUFBUTtZQUNsQixJQUFJLEVBQUUsSUFBSTtZQUNWLEVBQUUsRUFBRSxFQUFFO1lBQ04sVUFBVSxFQUFFLE9BQU87WUFDbkIsTUFBTTtZQUNOLEdBQUcsRUFBRSxzQkFBc0IsQ0FBQyxLQUFLLENBQUM7WUFDbEMsUUFBUSxFQUFFLHNCQUFzQixDQUFDLFdBQVcsQ0FBQztZQUM3QyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLE1BQU0sRUFBRTtZQUNqQyxHQUFHLENBQUMsTUFBTSxJQUFJLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxJQUFJLEVBQUUsQ0FBQztTQUN4QyxDQUFBO0lBQ0gsQ0FBQztDQUNGLENBQUE7QUExQkM7SUFBQyxJQUFBLGFBQU0sR0FBRTs4QkFDSSxrQkFBVztrREFBQTtBQUV4QjtJQUFDLElBQUEsYUFBTSxHQUFFOzhCQUNBLDBCQUFXO0lBRXBCOztPQUVHOzs4Q0FKaUI7QUFMVCxhQUFhO0lBRHpCLElBQUEsY0FBTyxHQUFFO0dBQ0csYUFBYSxDQTJCekI7QUEzQlksc0NBQWEifQ==