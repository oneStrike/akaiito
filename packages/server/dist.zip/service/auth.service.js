"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AuthService = void 0;
const core_1 = require("@midwayjs/core");
const jwt_1 = require("@midwayjs/jwt");
let AuthService = class AuthService {
    /**
     * 生成token
     */
    async generateToken(user, isRefresh = false) {
        const { id, username, account, isRoot } = user;
        if (!id || !username) {
            throw new core_1.httpError.ForbiddenError();
        }
        const tokenInfo = {
            id,
            username,
            account,
            isRoot,
            isRefresh
        };
        const { secret, token } = this.jwtConfig;
        const expiresIn = isRefresh ? token.refreshExpire : token.expire;
        return this.jwt.sign(tokenInfo, secret, {
            expiresIn
        });
    }
};
__decorate([
    (0, core_1.Inject)(),
    __metadata("design:type", jwt_1.JwtService)
], AuthService.prototype, "jwt", void 0);
__decorate([
    (0, core_1.Config)('jwt'),
    __metadata("design:type", Object)
], AuthService.prototype, "jwtConfig", void 0);
AuthService = __decorate([
    (0, core_1.Provide)()
], AuthService);
exports.AuthService = AuthService;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXV0aC5zZXJ2aWNlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vc3JjL3NlcnZpY2UvYXV0aC5zZXJ2aWNlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7OztBQUFBLHlDQUFtRTtBQUNuRSx1Q0FBMEM7QUFFbkMsSUFBTSxXQUFXLEdBQWpCLE1BQU0sV0FBVztJQU90Qjs7T0FFRztJQUNILEtBQUssQ0FBQyxhQUFhLENBQUMsSUFBSSxFQUFFLFNBQVMsR0FBRyxLQUFLO1FBQ3pDLE1BQU0sRUFBRSxFQUFFLEVBQUUsUUFBUSxFQUFFLE9BQU8sRUFBRSxNQUFNLEVBQUUsR0FBRyxJQUFJLENBQUE7UUFDOUMsSUFBSSxDQUFDLEVBQUUsSUFBSSxDQUFDLFFBQVEsRUFBRTtZQUNwQixNQUFNLElBQUksZ0JBQVMsQ0FBQyxjQUFjLEVBQUUsQ0FBQTtTQUNyQztRQUNELE1BQU0sU0FBUyxHQUFHO1lBQ2hCLEVBQUU7WUFDRixRQUFRO1lBQ1IsT0FBTztZQUNQLE1BQU07WUFDTixTQUFTO1NBQ1YsQ0FBQTtRQUNELE1BQU0sRUFBRSxNQUFNLEVBQUUsS0FBSyxFQUFFLEdBQUcsSUFBSSxDQUFDLFNBQVMsQ0FBQTtRQUN4QyxNQUFNLFNBQVMsR0FBRyxTQUFTLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUE7UUFDaEUsT0FBTyxJQUFJLENBQUMsR0FBRyxDQUFDLElBQUksQ0FBQyxTQUFTLEVBQUUsTUFBTSxFQUFFO1lBQ3RDLFNBQVM7U0FDVixDQUFDLENBQUE7SUFDSixDQUFDO0NBQ0YsQ0FBQTtBQTNCQztJQUFDLElBQUEsYUFBTSxHQUFFOzhCQUNKLGdCQUFVO3dDQUFBO0FBRWY7SUFBQyxJQUFBLGFBQU0sRUFBQyxLQUFLLENBQUM7OzhDQUNMO0FBTEUsV0FBVztJQUR2QixJQUFBLGNBQU8sR0FBRTtHQUNHLFdBQVcsQ0E0QnZCO0FBNUJZLGtDQUFXIn0=