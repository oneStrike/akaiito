import { ConfigEnum } from '../shared/enum/config.enum';
export declare class ConfigService {
    baseDir: string;
    getConfig<T>(type: ConfigEnum, filed?: keyof T): Promise<T | T[keyof T]>;
    setConfig<T>(type: ConfigEnum, config: T): Promise<void>;
}
