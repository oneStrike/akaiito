"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MaterialService = void 0;
const core_1 = require("@midwayjs/core");
const base_service_1 = require("../../../shared/service/base.service");
const materialLibrary_mapping_1 = require("./mapping/materialLibrary.mapping");
const sequelize_1 = require("sequelize");
let MaterialService = class MaterialService extends base_service_1.BaseService {
    async createMaterialLibrary(name) {
        await this.isExists({ groupName: name });
        const maxSort = await this.getMaxSort();
        return await this.create({ groupName: name, sort: maxSort + 1 });
    }
    //删除素材分组，并删除分组下的所有素材
    async destroyMaterialGroup(id) {
        await this.materialMapping.destroy({ groupId: id });
        await this.mapping.destroy({ id });
        return id;
    }
    async materialFindMultiple(params) {
        const { where, listOptions } = this.getWhere(params);
        const materialName = where.materialName;
        if (materialName) {
            where.materialName = {
                [sequelize_1.Op.substring]: materialName
            };
        }
        return this.materialMapping.findMultiple({ where, listOptions });
    }
    async materialBulkCreate(params) {
        const idExistsGroup = await this.isExists(params.groupId, true, false);
        if (idExistsGroup === null) {
            return this.normalError('分组不存在');
        }
        const materials = params.material.map((item) => {
            return {
                groupId: params.groupId,
                ...item
            };
        });
        return (await this.materialMapping.bulkCreate(materials)).map((item) => item.id);
    }
    async materialDestroy(id) {
        return this.materialMapping.destroy({ id });
    }
};
__decorate([
    (0, core_1.Inject)(),
    __metadata("design:type", materialLibrary_mapping_1.MaterialLibraryMapping)
], MaterialService.prototype, "mapping", void 0);
__decorate([
    (0, core_1.Inject)(),
    __metadata("design:type", materialLibrary_mapping_1.MaterialMapping)
], MaterialService.prototype, "materialMapping", void 0);
MaterialService = __decorate([
    (0, core_1.Provide)()
], MaterialService);
exports.MaterialService = MaterialService;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWF0ZXJpYWwuc2VydmljZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NyYy9zZXJ2aWNlL2FkbWluL21hdGVyaWFsTGlicmFyeS9tYXRlcmlhbC5zZXJ2aWNlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7OztBQUFBLHlDQUFnRDtBQUNoRCx1RUFBa0U7QUFDbEUsK0VBRzBDO0FBRTFDLHlDQUE4QjtBQUd2QixJQUFNLGVBQWUsR0FBckIsTUFBTSxlQUFnQixTQUFRLDBCQUFXO0lBTzlDLEtBQUssQ0FBQyxxQkFBcUIsQ0FBQyxJQUFZO1FBQ3RDLE1BQU0sSUFBSSxDQUFDLFFBQVEsQ0FBQyxFQUFFLFNBQVMsRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFBO1FBQ3hDLE1BQU0sT0FBTyxHQUFHLE1BQU0sSUFBSSxDQUFDLFVBQVUsRUFBRSxDQUFBO1FBQ3ZDLE9BQU8sTUFBTSxJQUFJLENBQUMsTUFBTSxDQUFDLEVBQUUsU0FBUyxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsT0FBTyxHQUFHLENBQUMsRUFBRSxDQUFDLENBQUE7SUFDbEUsQ0FBQztJQUVELG9CQUFvQjtJQUNwQixLQUFLLENBQUMsb0JBQW9CLENBQUMsRUFBVTtRQUNuQyxNQUFNLElBQUksQ0FBQyxlQUFlLENBQUMsT0FBTyxDQUFDLEVBQUUsT0FBTyxFQUFFLEVBQUUsRUFBRSxDQUFDLENBQUE7UUFDbkQsTUFBTSxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxFQUFFLEVBQUUsRUFBRSxDQUFDLENBQUE7UUFDbEMsT0FBTyxFQUFFLENBQUE7SUFDWCxDQUFDO0lBRUQsS0FBSyxDQUFDLG9CQUFvQixDQUFDLE1BQXVCO1FBQ2hELE1BQU0sRUFBRSxLQUFLLEVBQUUsV0FBVyxFQUFFLEdBQUcsSUFBSSxDQUFDLFFBQVEsQ0FBQyxNQUFNLENBQUMsQ0FBQTtRQUNwRCxNQUFNLFlBQVksR0FBRyxLQUFLLENBQUMsWUFBWSxDQUFBO1FBQ3ZDLElBQUksWUFBWSxFQUFFO1lBQ2hCLEtBQUssQ0FBQyxZQUFZLEdBQUc7Z0JBQ25CLENBQUMsY0FBRSxDQUFDLFNBQVMsQ0FBQyxFQUFFLFlBQVk7YUFDN0IsQ0FBQTtTQUNGO1FBRUQsT0FBTyxJQUFJLENBQUMsZUFBZSxDQUFDLFlBQVksQ0FBQyxFQUFFLEtBQUssRUFBRSxXQUFXLEVBQUUsQ0FBQyxDQUFBO0lBQ2xFLENBQUM7SUFFRCxLQUFLLENBQUMsa0JBQWtCLENBQUMsTUFBeUI7UUFDaEQsTUFBTSxhQUFhLEdBQUcsTUFBTSxJQUFJLENBQUMsUUFBUSxDQUFDLE1BQU0sQ0FBQyxPQUFPLEVBQUUsSUFBSSxFQUFFLEtBQUssQ0FBQyxDQUFBO1FBQ3RFLElBQUksYUFBYSxLQUFLLElBQUksRUFBRTtZQUMxQixPQUFPLElBQUksQ0FBQyxXQUFXLENBQUMsT0FBTyxDQUFDLENBQUE7U0FDakM7UUFDRCxNQUFNLFNBQVMsR0FBRyxNQUFNLENBQUMsUUFBUSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksRUFBRSxFQUFFO1lBQzdDLE9BQU87Z0JBQ0wsT0FBTyxFQUFFLE1BQU0sQ0FBQyxPQUFPO2dCQUN2QixHQUFHLElBQUk7YUFDUixDQUFBO1FBQ0gsQ0FBQyxDQUFDLENBQUE7UUFDRixPQUFPLENBQUMsTUFBTSxJQUFJLENBQUMsZUFBZSxDQUFDLFVBQVUsQ0FBQyxTQUFTLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FDM0QsQ0FBQyxJQUFJLEVBQUUsRUFBRSxDQUFDLElBQUksQ0FBQyxFQUFFLENBQ2xCLENBQUE7SUFDSCxDQUFDO0lBRUQsS0FBSyxDQUFDLGVBQWUsQ0FBQyxFQUFVO1FBQzlCLE9BQU8sSUFBSSxDQUFDLGVBQWUsQ0FBQyxPQUFPLENBQUMsRUFBRSxFQUFFLEVBQUUsQ0FBQyxDQUFBO0lBQzdDLENBQUM7Q0FDRixDQUFBO0FBbERDO0lBQUMsSUFBQSxhQUFNLEdBQUU7OEJBQ0EsZ0RBQXNCO2dEQUFBO0FBRS9CO0lBQUMsSUFBQSxhQUFNLEdBQUU7OEJBQ1EseUNBQWU7d0RBQUE7QUFMckIsZUFBZTtJQUQzQixJQUFBLGNBQU8sR0FBRTtHQUNHLGVBQWUsQ0FtRDNCO0FBbkRZLDBDQUFlIn0=