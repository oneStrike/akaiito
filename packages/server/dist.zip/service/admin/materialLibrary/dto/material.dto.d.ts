import { ListDto } from '../../../../shared/dto/base.dto';
export declare class MaterialLibraryDto {
    id: number;
    groupName: string;
}
declare const CreateMaterialLibraryDto_base: import("@midwayjs/validate").Dto<Pick<MaterialLibraryDto, "groupName">>;
export declare class CreateMaterialLibraryDto extends CreateMaterialLibraryDto_base {
}
export declare class MaterialDto {
    path: string;
    materialName: string;
    materialType: string;
}
export declare class CreateMaterialDto {
    groupId: number;
    material: MaterialDto[];
}
export declare class FindMaterialDto extends ListDto {
    groupId?: number;
    materialName?: string;
    materialType?: string;
}
export {};
