"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.FindMaterialDto = exports.CreateMaterialDto = exports.MaterialDto = exports.CreateMaterialLibraryDto = exports.MaterialLibraryDto = void 0;
const validate_1 = require("@midwayjs/validate");
const base_validate_1 = require("../../../../utils/validate/base.validate");
const base_dto_1 = require("../../../../shared/dto/base.dto");
//素材库
class MaterialLibraryDto {
}
__decorate([
    (0, validate_1.Rule)(base_validate_1.requiredNumber),
    __metadata("design:type", Number)
], MaterialLibraryDto.prototype, "id", void 0);
__decorate([
    (0, validate_1.Rule)(base_validate_1.requiredString),
    __metadata("design:type", String)
], MaterialLibraryDto.prototype, "groupName", void 0);
exports.MaterialLibraryDto = MaterialLibraryDto;
class CreateMaterialLibraryDto extends (0, validate_1.PickDto)(MaterialLibraryDto, [
    'groupName'
]) {
}
exports.CreateMaterialLibraryDto = CreateMaterialLibraryDto;
//素材
class MaterialDto {
}
__decorate([
    (0, validate_1.Rule)(base_validate_1.requiredString),
    __metadata("design:type", String)
], MaterialDto.prototype, "path", void 0);
__decorate([
    (0, validate_1.Rule)(base_validate_1.requiredString),
    __metadata("design:type", String)
], MaterialDto.prototype, "materialName", void 0);
__decorate([
    (0, validate_1.Rule)((0, base_validate_1.givenValue)(['image', 'video', 'url'], true)),
    __metadata("design:type", String)
], MaterialDto.prototype, "materialType", void 0);
exports.MaterialDto = MaterialDto;
//添加素材
class CreateMaterialDto {
}
__decorate([
    (0, validate_1.Rule)(base_validate_1.requiredNumber),
    __metadata("design:type", Number)
], CreateMaterialDto.prototype, "groupId", void 0);
__decorate([
    (0, validate_1.Rule)(MaterialDto),
    __metadata("design:type", Array)
], CreateMaterialDto.prototype, "material", void 0);
exports.CreateMaterialDto = CreateMaterialDto;
//查找素材
class FindMaterialDto extends base_dto_1.ListDto {
}
__decorate([
    (0, validate_1.Rule)(base_validate_1.validateNumber),
    __metadata("design:type", Number)
], FindMaterialDto.prototype, "groupId", void 0);
__decorate([
    (0, validate_1.Rule)(base_validate_1.validateString),
    __metadata("design:type", String)
], FindMaterialDto.prototype, "materialName", void 0);
__decorate([
    (0, validate_1.Rule)((0, base_validate_1.givenValue)(['image', 'video', 'url'], false)),
    __metadata("design:type", String)
], FindMaterialDto.prototype, "materialType", void 0);
exports.FindMaterialDto = FindMaterialDto;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWF0ZXJpYWwuZHRvLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vc3JjL3NlcnZpY2UvYWRtaW4vbWF0ZXJpYWxMaWJyYXJ5L2R0by9tYXRlcmlhbC5kdG8udHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7O0FBQUEsaURBQWtEO0FBQ2xELDRFQU1pRDtBQUNqRCw4REFBeUQ7QUFFekQsS0FBSztBQUNMLE1BQWEsa0JBQWtCO0NBTTlCO0FBTEM7SUFBQyxJQUFBLGVBQUksRUFBQyw4QkFBYyxDQUFDOzs4Q0FDWDtBQUVWO0lBQUMsSUFBQSxlQUFJLEVBQUMsOEJBQWMsQ0FBQzs7cURBQ0o7QUFMbkIsZ0RBTUM7QUFFRCxNQUFhLHdCQUF5QixTQUFRLElBQUEsa0JBQU8sRUFBQyxrQkFBa0IsRUFBRTtJQUN4RSxXQUFXO0NBQ1osQ0FBQztDQUFHO0FBRkwsNERBRUs7QUFFTCxJQUFJO0FBQ0osTUFBYSxXQUFXO0NBU3ZCO0FBUkM7SUFBQyxJQUFBLGVBQUksRUFBQyw4QkFBYyxDQUFDOzt5Q0FDVDtBQUVaO0lBQUMsSUFBQSxlQUFJLEVBQUMsOEJBQWMsQ0FBQzs7aURBQ0Q7QUFFcEI7SUFBQyxJQUFBLGVBQUksRUFBQyxJQUFBLDBCQUFVLEVBQUMsQ0FBQyxPQUFPLEVBQUUsT0FBTyxFQUFFLEtBQUssQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDOztpREFDOUI7QUFSdEIsa0NBU0M7QUFFRCxNQUFNO0FBQ04sTUFBYSxpQkFBaUI7Q0FNN0I7QUFMQztJQUFDLElBQUEsZUFBSSxFQUFDLDhCQUFjLENBQUM7O2tEQUNOO0FBRWY7SUFBQyxJQUFBLGVBQUksRUFBQyxXQUFXLENBQUM7O21EQUNLO0FBTHpCLDhDQU1DO0FBRUQsTUFBTTtBQUNOLE1BQWEsZUFBZ0IsU0FBUSxrQkFBTztDQVMzQztBQVJDO0lBQUMsSUFBQSxlQUFJLEVBQUMsOEJBQWMsQ0FBQzs7Z0RBQ0w7QUFFaEI7SUFBQyxJQUFBLGVBQUksRUFBQyw4QkFBYyxDQUFDOztxREFDQTtBQUVyQjtJQUFDLElBQUEsZUFBSSxFQUFDLElBQUEsMEJBQVUsRUFBQyxDQUFDLE9BQU8sRUFBRSxPQUFPLEVBQUUsS0FBSyxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUM7O3FEQUM5QjtBQVJ2QiwwQ0FTQyJ9