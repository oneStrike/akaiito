"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MaterialEntity = exports.MaterialGroupEntity = void 0;
const sequelize_typescript_1 = require("sequelize-typescript");
const basic_entity_1 = require("../../../../shared/entities/basic.entity");
/**
 * 素材分组表
 */
let MaterialGroupEntity = class MaterialGroupEntity extends basic_entity_1.BaseEntity {
};
__decorate([
    (0, sequelize_typescript_1.Column)({
        type: sequelize_typescript_1.DataType.STRING(50),
        allowNull: false,
        unique: true,
        comment: '素材库分组名称'
    }),
    __metadata("design:type", String)
], MaterialGroupEntity.prototype, "groupName", void 0);
__decorate([
    (0, sequelize_typescript_1.Column)({
        type: sequelize_typescript_1.DataType.INTEGER,
        allowNull: false,
        unique: true,
        comment: '排序'
    }),
    __metadata("design:type", Number)
], MaterialGroupEntity.prototype, "sort", void 0);
MaterialGroupEntity = __decorate([
    (0, sequelize_typescript_1.Table)({
        tableName: 'material_group'
    })
], MaterialGroupEntity);
exports.MaterialGroupEntity = MaterialGroupEntity;
/**
 * 素材表
 */
let MaterialEntity = class MaterialEntity extends basic_entity_1.BaseEntity {
};
__decorate([
    (0, sequelize_typescript_1.ForeignKey)(() => MaterialGroupEntity),
    (0, sequelize_typescript_1.Column)({
        type: sequelize_typescript_1.DataType.INTEGER,
        allowNull: false,
        comment: '分组id'
    }),
    __metadata("design:type", Number)
], MaterialEntity.prototype, "groupId", void 0);
__decorate([
    (0, sequelize_typescript_1.Column)({
        type: sequelize_typescript_1.DataType.STRING(50),
        allowNull: false,
        comment: '素材名称'
    }),
    __metadata("design:type", String)
], MaterialEntity.prototype, "materialName", void 0);
__decorate([
    (0, sequelize_typescript_1.Column)({
        type: sequelize_typescript_1.DataType.STRING,
        allowNull: false,
        comment: '素材路径',
        unique: true
    }),
    __metadata("design:type", String)
], MaterialEntity.prototype, "path", void 0);
__decorate([
    (0, sequelize_typescript_1.Column)({
        type: sequelize_typescript_1.DataType.STRING,
        allowNull: false,
        comment: '素材类型'
    }),
    __metadata("design:type", String)
], MaterialEntity.prototype, "materialType", void 0);
MaterialEntity = __decorate([
    (0, sequelize_typescript_1.Table)({
        tableName: 'material'
    })
], MaterialEntity);
exports.MaterialEntity = MaterialEntity;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWF0ZXJpYWxMaWJyYXJ5LmVudGl0eS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NyYy9zZXJ2aWNlL2FkbWluL21hdGVyaWFsTGlicmFyeS9lbnRpdGllcy9tYXRlcmlhbExpYnJhcnkuZW50aXR5LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7OztBQUFBLCtEQUEwRTtBQUMxRSwyRUFBcUU7QUFFckU7O0dBRUc7QUFJSSxJQUFNLG1CQUFtQixHQUF6QixNQUFNLG1CQUFvQixTQUFRLHlCQUFVO0NBZ0JsRCxDQUFBO0FBZkM7SUFBQyxJQUFBLDZCQUFNLEVBQUM7UUFDTixJQUFJLEVBQUUsK0JBQVEsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDO1FBQ3pCLFNBQVMsRUFBRSxLQUFLO1FBQ2hCLE1BQU0sRUFBRSxJQUFJO1FBQ1osT0FBTyxFQUFFLFNBQVM7S0FDbkIsQ0FBQzs7c0RBQ2U7QUFFakI7SUFBQyxJQUFBLDZCQUFNLEVBQUM7UUFDTixJQUFJLEVBQUUsK0JBQVEsQ0FBQyxPQUFPO1FBQ3RCLFNBQVMsRUFBRSxLQUFLO1FBQ2hCLE1BQU0sRUFBRSxJQUFJO1FBQ1osT0FBTyxFQUFFLElBQUk7S0FDZCxDQUFDOztpREFDVTtBQWZELG1CQUFtQjtJQUgvQixJQUFBLDRCQUFLLEVBQUM7UUFDTCxTQUFTLEVBQUUsZ0JBQWdCO0tBQzVCLENBQUM7R0FDVyxtQkFBbUIsQ0FnQi9CO0FBaEJZLGtEQUFtQjtBQWtCaEM7O0dBRUc7QUFJSSxJQUFNLGNBQWMsR0FBcEIsTUFBTSxjQUFlLFNBQVEseUJBQVU7Q0E4QjdDLENBQUE7QUE3QkM7SUFBQyxJQUFBLGlDQUFVLEVBQUMsR0FBRyxFQUFFLENBQUMsbUJBQW1CLENBQUM7SUFDckMsSUFBQSw2QkFBTSxFQUFDO1FBQ04sSUFBSSxFQUFFLCtCQUFRLENBQUMsT0FBTztRQUN0QixTQUFTLEVBQUUsS0FBSztRQUNoQixPQUFPLEVBQUUsTUFBTTtLQUNoQixDQUFDOzsrQ0FDYTtBQUVmO0lBQUMsSUFBQSw2QkFBTSxFQUFDO1FBQ04sSUFBSSxFQUFFLCtCQUFRLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQztRQUN6QixTQUFTLEVBQUUsS0FBSztRQUNoQixPQUFPLEVBQUUsTUFBTTtLQUNoQixDQUFDOztvREFDa0I7QUFFcEI7SUFBQyxJQUFBLDZCQUFNLEVBQUM7UUFDTixJQUFJLEVBQUUsK0JBQVEsQ0FBQyxNQUFNO1FBQ3JCLFNBQVMsRUFBRSxLQUFLO1FBQ2hCLE9BQU8sRUFBRSxNQUFNO1FBQ2YsTUFBTSxFQUFFLElBQUk7S0FDYixDQUFDOzs0Q0FDVTtBQUVaO0lBQUMsSUFBQSw2QkFBTSxFQUFDO1FBQ04sSUFBSSxFQUFFLCtCQUFRLENBQUMsTUFBTTtRQUNyQixTQUFTLEVBQUUsS0FBSztRQUNoQixPQUFPLEVBQUUsTUFBTTtLQUNoQixDQUFDOztvREFDa0I7QUE3QlQsY0FBYztJQUgxQixJQUFBLDRCQUFLLEVBQUM7UUFDTCxTQUFTLEVBQUUsVUFBVTtLQUN0QixDQUFDO0dBQ1csY0FBYyxDQThCMUI7QUE5Qlksd0NBQWMifQ==