import { BaseEntity } from '../../../../shared/entities/basic.entity';
/**
 * 素材分组表
 */
export declare class MaterialGroupEntity extends BaseEntity {
    groupName: string;
    sort: number;
}
/**
 * 素材表
 */
export declare class MaterialEntity extends BaseEntity {
    groupId: number;
    materialName: string;
    path: string;
    materialType: string;
}
