import { BaseMapping } from '../../../../shared/mapping/base.mapping';
import { Repository } from 'sequelize-typescript';
import { MaterialEntity, MaterialGroupEntity } from '../entities/materialLibrary.entity';
export declare class MaterialLibraryMapping extends BaseMapping<MaterialGroupEntity> {
    repository: Repository<MaterialGroupEntity>;
}
export declare class MaterialMapping extends BaseMapping<MaterialEntity> {
    repository: Repository<MaterialEntity>;
}
