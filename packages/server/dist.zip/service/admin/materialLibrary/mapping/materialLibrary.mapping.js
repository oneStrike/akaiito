"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.MaterialMapping = exports.MaterialLibraryMapping = void 0;
const core_1 = require("@midwayjs/core");
const base_mapping_1 = require("../../../../shared/mapping/base.mapping");
const materialLibrary_entity_1 = require("../entities/materialLibrary.entity");
const sequelize_1 = require("@midwayjs/sequelize");
let MaterialLibraryMapping = class MaterialLibraryMapping extends base_mapping_1.BaseMapping {
};
__decorate([
    (0, sequelize_1.InjectRepository)(materialLibrary_entity_1.MaterialGroupEntity),
    __metadata("design:type", Object)
], MaterialLibraryMapping.prototype, "repository", void 0);
MaterialLibraryMapping = __decorate([
    (0, core_1.Provide)()
], MaterialLibraryMapping);
exports.MaterialLibraryMapping = MaterialLibraryMapping;
let MaterialMapping = class MaterialMapping extends base_mapping_1.BaseMapping {
};
__decorate([
    (0, sequelize_1.InjectRepository)(materialLibrary_entity_1.MaterialEntity),
    __metadata("design:type", Object)
], MaterialMapping.prototype, "repository", void 0);
MaterialMapping = __decorate([
    (0, core_1.Provide)()
], MaterialMapping);
exports.MaterialMapping = MaterialMapping;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibWF0ZXJpYWxMaWJyYXJ5Lm1hcHBpbmcuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zcmMvc2VydmljZS9hZG1pbi9tYXRlcmlhbExpYnJhcnkvbWFwcGluZy9tYXRlcmlhbExpYnJhcnkubWFwcGluZy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7QUFBQSx5Q0FBd0M7QUFDeEMsMEVBQXFFO0FBRXJFLCtFQUcyQztBQUMzQyxtREFBc0Q7QUFHL0MsSUFBTSxzQkFBc0IsR0FBNUIsTUFBTSxzQkFBdUIsU0FBUSwwQkFBZ0M7Q0FHM0UsQ0FBQTtBQUZDO0lBQUMsSUFBQSw0QkFBZ0IsRUFBQyw0Q0FBbUIsQ0FBQzs7MERBQ0s7QUFGaEMsc0JBQXNCO0lBRGxDLElBQUEsY0FBTyxHQUFFO0dBQ0csc0JBQXNCLENBR2xDO0FBSFksd0RBQXNCO0FBTTVCLElBQU0sZUFBZSxHQUFyQixNQUFNLGVBQWdCLFNBQVEsMEJBQTJCO0NBRy9ELENBQUE7QUFGQztJQUFDLElBQUEsNEJBQWdCLEVBQUMsdUNBQWMsQ0FBQzs7bURBQ0s7QUFGM0IsZUFBZTtJQUQzQixJQUFBLGNBQU8sR0FBRTtHQUNHLGVBQWUsQ0FHM0I7QUFIWSwwQ0FBZSJ9