import { BaseService } from '../../../shared/service/base.service';
import { MaterialLibraryMapping, MaterialMapping } from './mapping/materialLibrary.mapping';
import { CreateMaterialDto, FindMaterialDto } from './dto/material.dto';
export declare class MaterialService extends BaseService {
    mapping: MaterialLibraryMapping;
    materialMapping: MaterialMapping;
    createMaterialLibrary(name: string): Promise<number>;
    destroyMaterialGroup(id: number): Promise<number>;
    materialFindMultiple(params: FindMaterialDto): Promise<import("../../../types/dto/list").ListResponseRes<import("./entities/materialLibrary.entity").MaterialEntity>>;
    materialBulkCreate(params: CreateMaterialDto): Promise<void | any[]>;
    materialDestroy(id: number): Promise<number>;
}
