import { Repository } from 'sequelize-typescript';
import { AdminUserEntity } from '../entities/user.entity';
import { BaseMapping } from '../../../../shared/mapping/base.mapping';
export declare class UserMapping extends BaseMapping<AdminUserEntity> {
    repository: Repository<AdminUserEntity>;
}
