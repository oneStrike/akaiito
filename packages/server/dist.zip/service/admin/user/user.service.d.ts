import { WhereOptions } from 'sequelize';
import { BaseService } from '../../../shared/service/base.service';
import { AuthService } from '../../auth.service';
import { UserMapping } from './mapping/user.mappping';
import { AdminUserEntity } from './entities/user.entity';
import { UpdatePasswordDto, UpdateUserInfoDto } from './dto/operate-user.dto';
import { CreateUserDto, LoginDto } from './dto/operate-user.dto';
import { CaptchaServiceOpen } from '../../../modules/captcha/captcha.service';
export declare class UserService extends BaseService {
    authService: AuthService;
    captchaService: CaptchaServiceOpen;
    mapping: UserMapping;
    getUserInfo(field: WhereOptions | number): Promise<AdminUserEntity>;
    /**
     * 创建新用户
     * @param params
     */
    createUser(params: CreateUserDto): Promise<number>;
    /**
     * 登陆
     * @param params
     */
    login(params: LoginDto): Promise<{
        token: string;
        refreshToken: string;
        user: AdminUserEntity;
    }>;
    refreshToken(id: number): Promise<string>;
    /**
     * 修改密码
     */
    updatePassword(params: UpdatePasswordDto): Promise<any>;
    /**
     * 修改用户信息
     */
    updateUserInfo(params: UpdateUserInfoDto): Promise<number>;
    /**
     * 密码比对
     * @param newPwd
     * @param oldPwd
     * @private
     */
    private diffPassword;
}
