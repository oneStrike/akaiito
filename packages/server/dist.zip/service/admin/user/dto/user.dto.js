"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserDto = void 0;
const validate_1 = require("@midwayjs/validate");
const base_validate_1 = require("../../../../utils/validate/base.validate");
class UserDto {
}
__decorate([
    (0, validate_1.Rule)(base_validate_1.requiredNumber),
    __metadata("design:type", Number)
], UserDto.prototype, "id", void 0);
__decorate([
    (0, validate_1.Rule)((0, base_validate_1.scopeLengthString)(2)),
    __metadata("design:type", String)
], UserDto.prototype, "username", void 0);
__decorate([
    (0, validate_1.Rule)((0, base_validate_1.scopeLengthString)(5)),
    __metadata("design:type", String)
], UserDto.prototype, "account", void 0);
__decorate([
    (0, validate_1.Rule)(base_validate_1.validateString),
    __metadata("design:type", String)
], UserDto.prototype, "avatar", void 0);
__decorate([
    (0, validate_1.Rule)(base_validate_1.validatePwd),
    __metadata("design:type", String)
], UserDto.prototype, "password", void 0);
__decorate([
    (0, validate_1.Rule)(base_validate_1.validatePwd),
    __metadata("design:type", String)
], UserDto.prototype, "confirmPassword", void 0);
__decorate([
    (0, validate_1.Rule)((0, base_validate_1.givenValue)([1, 0])),
    __metadata("design:type", Number)
], UserDto.prototype, "isRoot", void 0);
__decorate([
    (0, validate_1.Rule)((0, base_validate_1.givenValue)([1, 0])),
    __metadata("design:type", Number)
], UserDto.prototype, "status", void 0);
__decorate([
    (0, validate_1.Rule)(base_validate_1.validatePhone),
    __metadata("design:type", String)
], UserDto.prototype, "mobile", void 0);
__decorate([
    (0, validate_1.Rule)(base_validate_1.validateEmail),
    __metadata("design:type", String)
], UserDto.prototype, "email", void 0);
__decorate([
    (0, validate_1.Rule)(base_validate_1.requiredDate),
    __metadata("design:type", String)
], UserDto.prototype, "createdAt", void 0);
exports.UserDto = UserDto;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidXNlci5kdG8uanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zcmMvc2VydmljZS9hZG1pbi91c2VyL2R0by91c2VyLmR0by50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7QUFBQSxpREFBeUM7QUFDekMsNEVBU2lEO0FBRWpELE1BQWEsT0FBTztDQWlDbkI7QUFoQ0M7SUFBQyxJQUFBLGVBQUksRUFBQyw4QkFBYyxDQUFDOzttQ0FDWDtBQUVWO0lBQUMsSUFBQSxlQUFJLEVBQUMsSUFBQSxpQ0FBaUIsRUFBQyxDQUFDLENBQUMsQ0FBQzs7eUNBQ1g7QUFFaEI7SUFBQyxJQUFBLGVBQUksRUFBQyxJQUFBLGlDQUFpQixFQUFDLENBQUMsQ0FBQyxDQUFDOzt3Q0FDWjtBQUVmO0lBQUMsSUFBQSxlQUFJLEVBQUMsOEJBQWMsQ0FBQzs7dUNBQ047QUFFZjtJQUFDLElBQUEsZUFBSSxFQUFDLDJCQUFXLENBQUM7O3lDQUNGO0FBRWhCO0lBQUMsSUFBQSxlQUFJLEVBQUMsMkJBQVcsQ0FBQzs7Z0RBQ007QUFFeEI7SUFBQyxJQUFBLGVBQUksRUFBQyxJQUFBLDBCQUFVLEVBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQzs7dUNBQ1g7QUFFZDtJQUFDLElBQUEsZUFBSSxFQUFDLElBQUEsMEJBQVUsRUFBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsQ0FBQyxDQUFDOzt1Q0FDWDtBQUVkO0lBQUMsSUFBQSxlQUFJLEVBQUMsNkJBQWEsQ0FBQzs7dUNBQ047QUFFZDtJQUFDLElBQUEsZUFBSSxFQUFDLDZCQUFhLENBQUM7O3NDQUNQO0FBRWI7SUFBQyxJQUFBLGVBQUksRUFBQyw0QkFBWSxDQUFDOzswQ0FDRjtBQWhDbkIsMEJBaUNDIn0=