export declare class UserDto {
    id: number;
    username: string;
    account: string;
    avatar?: string;
    password: string;
    confirmPassword: string;
    isRoot: number;
    status: number;
    mobile: string;
    email: string;
    createdAt: string;
}
