import { UserDto } from './user.dto';
import { ListDto } from '../../../../shared/dto/base.dto';
declare const CreateUserDto_base: import("@midwayjs/validate").Dto<Omit<UserDto, "id" | "createdAt" | "status">>;
/**
 * 创建新用户
 */
export declare class CreateUserDto extends CreateUserDto_base {
}
declare const LoginDto_base: import("@midwayjs/validate").Dto<Pick<UserDto, "account" | "password">>;
/**
 * 登录
 */
export declare class LoginDto extends LoginDto_base {
    captchaId?: string;
    captcha: string;
}
declare const UpdatePasswordDto_base: import("@midwayjs/validate").Dto<Pick<UserDto, "password" | "confirmPassword">>;
/**
 * 修改密码
 */
export declare class UpdatePasswordDto extends UpdatePasswordDto_base {
    originalPassword: string;
}
declare const UpdateUserInfoDto_base: import("@midwayjs/validate").Dto<Omit<UserDto, "password" | "confirmPassword">>;
/**
 * 修改用户信息
 */
export declare class UpdateUserInfoDto extends UpdateUserInfoDto_base {
}
/**
 * 获取用户列表
 */
export declare class getUserListDto extends ListDto {
    isRoot?: number;
    status?: number;
    startDate?: Date;
    endDate?: Date;
}
export {};
