"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getUserListDto = exports.UpdateUserInfoDto = exports.UpdatePasswordDto = exports.LoginDto = exports.CreateUserDto = void 0;
const validate_1 = require("@midwayjs/validate");
const base_validate_1 = require("../../../../utils/validate/base.validate");
const user_dto_1 = require("./user.dto");
const base_dto_1 = require("../../../../shared/dto/base.dto");
/**
 * 创建新用户
 */
class CreateUserDto extends (0, validate_1.OmitDto)(user_dto_1.UserDto, [
    'id',
    'status',
    'createdAt'
]) {
}
exports.CreateUserDto = CreateUserDto;
/**
 * 登录
 */
class LoginDto extends (0, validate_1.PickDto)(user_dto_1.UserDto, ['account', 'password']) {
}
__decorate([
    (0, validate_1.Rule)(base_validate_1.validateString),
    __metadata("design:type", String)
], LoginDto.prototype, "captchaId", void 0);
__decorate([
    (0, validate_1.Rule)(base_validate_1.requiredString),
    __metadata("design:type", String)
], LoginDto.prototype, "captcha", void 0);
exports.LoginDto = LoginDto;
/**
 * 修改密码
 */
class UpdatePasswordDto extends (0, validate_1.PickDto)(user_dto_1.UserDto, [
    'password',
    'confirmPassword'
]) {
}
__decorate([
    (0, validate_1.Rule)(base_validate_1.validatePwd),
    __metadata("design:type", String)
], UpdatePasswordDto.prototype, "originalPassword", void 0);
exports.UpdatePasswordDto = UpdatePasswordDto;
/**
 * 修改用户信息
 */
class UpdateUserInfoDto extends (0, validate_1.OmitDto)(user_dto_1.UserDto, [
    'password',
    'confirmPassword'
]) {
}
exports.UpdateUserInfoDto = UpdateUserInfoDto;
/**
 * 获取用户列表
 */
class getUserListDto extends base_dto_1.ListDto {
}
__decorate([
    (0, validate_1.Rule)((0, base_validate_1.givenValue)([1, 0], false)),
    __metadata("design:type", Number)
], getUserListDto.prototype, "isRoot", void 0);
__decorate([
    (0, validate_1.Rule)((0, base_validate_1.givenValue)([1, 0], false)),
    __metadata("design:type", Number)
], getUserListDto.prototype, "status", void 0);
__decorate([
    (0, validate_1.Rule)(base_validate_1.validateDate),
    __metadata("design:type", Date)
], getUserListDto.prototype, "startDate", void 0);
__decorate([
    (0, validate_1.Rule)(base_validate_1.validateDate),
    __metadata("design:type", Date)
], getUserListDto.prototype, "endDate", void 0);
exports.getUserListDto = getUserListDto;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoib3BlcmF0ZS11c2VyLmR0by5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NyYy9zZXJ2aWNlL2FkbWluL3VzZXIvZHRvL29wZXJhdGUtdXNlci5kdG8udHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7O0FBQUEsaURBQTJEO0FBQzNELDRFQU1pRDtBQUVqRCx5Q0FBb0M7QUFDcEMsOERBQXlEO0FBRXpEOztHQUVHO0FBQ0gsTUFBYSxhQUFjLFNBQVEsSUFBQSxrQkFBTyxFQUFDLGtCQUFPLEVBQUU7SUFDbEQsSUFBSTtJQUNKLFFBQVE7SUFDUixXQUFXO0NBQ1osQ0FBQztDQUFHO0FBSkwsc0NBSUs7QUFFTDs7R0FFRztBQUVILE1BQWEsUUFBUyxTQUFRLElBQUEsa0JBQU8sRUFBQyxrQkFBTyxFQUFFLENBQUMsU0FBUyxFQUFFLFVBQVUsQ0FBQyxDQUFDO0NBTXRFO0FBTEM7SUFBQyxJQUFBLGVBQUksRUFBQyw4QkFBYyxDQUFDOzsyQ0FDSDtBQUVsQjtJQUFDLElBQUEsZUFBSSxFQUFDLDhCQUFjLENBQUM7O3lDQUNOO0FBTGpCLDRCQU1DO0FBRUQ7O0dBRUc7QUFDSCxNQUFhLGlCQUFrQixTQUFRLElBQUEsa0JBQU8sRUFBQyxrQkFBTyxFQUFFO0lBQ3RELFVBQVU7SUFDVixpQkFBaUI7Q0FDbEIsQ0FBQztDQUdEO0FBRkM7SUFBQyxJQUFBLGVBQUksRUFBQywyQkFBVyxDQUFDOzsyREFDTTtBQUwxQiw4Q0FNQztBQUVEOztHQUVHO0FBRUgsTUFBYSxpQkFBa0IsU0FBUSxJQUFBLGtCQUFPLEVBQUMsa0JBQU8sRUFBRTtJQUN0RCxVQUFVO0lBQ1YsaUJBQWlCO0NBQ2xCLENBQUM7Q0FBRztBQUhMLDhDQUdLO0FBRUw7O0dBRUc7QUFFSCxNQUFhLGNBQWUsU0FBUSxrQkFBTztDQVkxQztBQVhDO0lBQUMsSUFBQSxlQUFJLEVBQUMsSUFBQSwwQkFBVSxFQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxDQUFDOzs4Q0FDakI7QUFFZjtJQUFDLElBQUEsZUFBSSxFQUFDLElBQUEsMEJBQVUsRUFBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQzs7OENBQ2pCO0FBRWY7SUFBQyxJQUFBLGVBQUksRUFBQyw0QkFBWSxDQUFDOzhCQUNQLElBQUk7aURBQUE7QUFFaEI7SUFBQyxJQUFBLGVBQUksRUFBQyw0QkFBWSxDQUFDOzhCQUNULElBQUk7K0NBQUE7QUFYaEIsd0NBWUMifQ==