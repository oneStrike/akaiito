"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.UserService = void 0;
const core_1 = require("@midwayjs/core");
const sequelize_1 = require("sequelize");
const base_service_1 = require("../../../shared/service/base.service");
const auth_service_1 = require("../../auth.service");
const user_mappping_1 = require("./mapping/user.mappping");
const captcha_service_1 = require("../../../modules/captcha/captcha.service");
let UserService = class UserService extends base_service_1.BaseService {
    //获取用户数据，不会查询被软删除的数据
    async getUserInfo(field) {
        const user = this.utils.lodash.isFinite(field)
            ? await this.mapping.findByPk(field)
            : await this.mapping.findOne(field);
        if (user)
            return user;
        this.normalError('用户不存在');
    }
    /**
     * 创建新用户
     * @param params
     */
    async createUser(params) {
        const { username, account, email, mobile, password, confirmPassword } = params;
        if (password !== confirmPassword) {
            this.normalError('密码不一致');
        }
        //检查用户属性是否以被使用
        const where = this.generateORSql({ username, account, email, mobile });
        const accountResult = await this.mapping.findOne(where, true);
        if (accountResult) {
            this.normalError('用户信息重复');
        }
        //密码加密
        delete params.confirmPassword;
        params.password = await this.utils.encryption(password);
        return await this.create(params);
    }
    /**
     * 登陆
     * @param params
     */
    async login(params) {
        const captchaRes = await this.captchaService.captchaCheck(params.captchaId, params.captcha);
        if (!captchaRes && params.captcha !== '999') {
            this.normalError('验证码错误');
        }
        const { account, password } = params;
        const user = await this.getUserInfo({ account });
        const matchPwd = await this.diffPassword(password, user.password);
        if (!matchPwd) {
            this.normalError('用户名或密码错误');
        }
        if (!user.status) {
            this.normalError('当前账号以被禁用，请联系管理员');
        }
        delete user.password;
        return {
            token: await this.authService.generateToken(user),
            refreshToken: await this.authService.generateToken(user, true),
            user
        };
    }
    //刷新token
    async refreshToken(id) {
        const user = await this.getUserInfo(id);
        return this.authService.generateToken(user);
    }
    /**
     * 修改密码
     */
    async updatePassword(params) {
        const { password, confirmPassword, originalPassword } = params;
        if (password !== confirmPassword) {
            this.normalError('密码不一致');
        }
        const { id } = this.ctx.getAttr('userInfo');
        const user = await this.getUserInfo(id);
        const matchPwd = await this.diffPassword(originalPassword, user.password);
        if (!matchPwd) {
            this.normalError('密码错误');
        }
        const salt = user.password.split('.')[0];
        user.password = await this.utils.encryption(password, salt);
        await this.mapping.updateOne(user, { id: user.id });
        return user.id;
    }
    /**
     * 修改用户信息
     */
    async updateUserInfo(params) {
        const { username, account, email, mobile, id } = params;
        const updateUser = await this.getUserInfo(id);
        const where = this.generateORSql({
            username,
            account,
            email,
            mobile
        });
        where[sequelize_1.Op.not] = { id };
        const user = await this.mapping.findOne(where, true);
        if (user) {
            this.normalError('信息已经存在');
        }
        await this.mapping.updateOne(params, { id: updateUser.id });
        return params.id;
    }
    /**
     * 密码比对
     * @param newPwd
     * @param oldPwd
     * @private
     */
    async diffPassword(newPwd, oldPwd) {
        const salt = oldPwd.split('.')[0];
        const currentPassword = await this.utils.encryption(newPwd, salt);
        return currentPassword === oldPwd;
    }
};
__decorate([
    (0, core_1.Inject)(),
    __metadata("design:type", auth_service_1.AuthService)
], UserService.prototype, "authService", void 0);
__decorate([
    (0, core_1.Inject)(),
    __metadata("design:type", captcha_service_1.CaptchaServiceOpen)
], UserService.prototype, "captchaService", void 0);
__decorate([
    (0, core_1.Inject)(),
    __metadata("design:type", user_mappping_1.UserMapping
    //获取用户数据，不会查询被软删除的数据
    )
], UserService.prototype, "mapping", void 0);
UserService = __decorate([
    (0, core_1.Provide)()
], UserService);
exports.UserService = UserService;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidXNlci5zZXJ2aWNlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vc3JjL3NlcnZpY2UvYWRtaW4vdXNlci91c2VyLnNlcnZpY2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7O0FBQUEseUNBQWdEO0FBQ2hELHlDQUE0QztBQUM1Qyx1RUFBa0U7QUFDbEUscURBQWdEO0FBQ2hELDJEQUFxRDtBQUlyRCw4RUFBNkU7QUFHdEUsSUFBTSxXQUFXLEdBQWpCLE1BQU0sV0FBWSxTQUFRLDBCQUFXO0lBVTFDLG9CQUFvQjtJQUNwQixLQUFLLENBQUMsV0FBVyxDQUFDLEtBQTRCO1FBQzVDLE1BQU0sSUFBSSxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLFFBQVEsQ0FBQyxLQUFLLENBQUM7WUFDNUMsQ0FBQyxDQUFDLE1BQU0sSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsS0FBZSxDQUFDO1lBQzlDLENBQUMsQ0FBQyxNQUFNLElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLEtBQXFCLENBQUMsQ0FBQTtRQUNyRCxJQUFJLElBQUk7WUFBRSxPQUFPLElBQUksQ0FBQTtRQUNyQixJQUFJLENBQUMsV0FBVyxDQUFDLE9BQU8sQ0FBQyxDQUFBO0lBQzNCLENBQUM7SUFFRDs7O09BR0c7SUFDSCxLQUFLLENBQUMsVUFBVSxDQUFDLE1BQXFCO1FBQ3BDLE1BQU0sRUFBRSxRQUFRLEVBQUUsT0FBTyxFQUFFLEtBQUssRUFBRSxNQUFNLEVBQUUsUUFBUSxFQUFFLGVBQWUsRUFBRSxHQUNuRSxNQUFNLENBQUE7UUFDUixJQUFJLFFBQVEsS0FBSyxlQUFlLEVBQUU7WUFDaEMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsQ0FBQTtTQUMxQjtRQUNELGNBQWM7UUFDZCxNQUFNLEtBQUssR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDLEVBQUUsUUFBUSxFQUFFLE9BQU8sRUFBRSxLQUFLLEVBQUUsTUFBTSxFQUFFLENBQUMsQ0FBQTtRQUN0RSxNQUFNLGFBQWEsR0FBMkIsTUFBTSxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FDdEUsS0FBSyxFQUNMLElBQUksQ0FDTCxDQUFBO1FBQ0QsSUFBSSxhQUFhLEVBQUU7WUFDakIsSUFBSSxDQUFDLFdBQVcsQ0FBQyxRQUFRLENBQUMsQ0FBQTtTQUMzQjtRQUNELE1BQU07UUFDTixPQUFPLE1BQU0sQ0FBQyxlQUFlLENBQUE7UUFDN0IsTUFBTSxDQUFDLFFBQVEsR0FBRyxNQUFNLElBQUksQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLFFBQVEsQ0FBQyxDQUFBO1FBQ3ZELE9BQU8sTUFBTSxJQUFJLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFBO0lBQ2xDLENBQUM7SUFFRDs7O09BR0c7SUFDSCxLQUFLLENBQUMsS0FBSyxDQUFDLE1BQWdCO1FBQzFCLE1BQU0sVUFBVSxHQUFHLE1BQU0sSUFBSSxDQUFDLGNBQWMsQ0FBQyxZQUFZLENBQ3ZELE1BQU0sQ0FBQyxTQUFTLEVBQ2hCLE1BQU0sQ0FBQyxPQUFPLENBQ2YsQ0FBQTtRQUVELElBQUksQ0FBQyxVQUFVLElBQUksTUFBTSxDQUFDLE9BQU8sS0FBSyxLQUFLLEVBQUU7WUFDM0MsSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsQ0FBQTtTQUMxQjtRQUVELE1BQU0sRUFBRSxPQUFPLEVBQUUsUUFBUSxFQUFFLEdBQUcsTUFBTSxDQUFBO1FBQ3BDLE1BQU0sSUFBSSxHQUFHLE1BQU0sSUFBSSxDQUFDLFdBQVcsQ0FBQyxFQUFFLE9BQU8sRUFBRSxDQUFDLENBQUE7UUFDaEQsTUFBTSxRQUFRLEdBQUcsTUFBTSxJQUFJLENBQUMsWUFBWSxDQUFDLFFBQVEsRUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUE7UUFDakUsSUFBSSxDQUFDLFFBQVEsRUFBRTtZQUNiLElBQUksQ0FBQyxXQUFXLENBQUMsVUFBVSxDQUFDLENBQUE7U0FDN0I7UUFDRCxJQUFJLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRTtZQUNoQixJQUFJLENBQUMsV0FBVyxDQUFDLGlCQUFpQixDQUFDLENBQUE7U0FDcEM7UUFDRCxPQUFPLElBQUksQ0FBQyxRQUFRLENBQUE7UUFDcEIsT0FBTztZQUNMLEtBQUssRUFBRSxNQUFNLElBQUksQ0FBQyxXQUFXLENBQUMsYUFBYSxDQUFDLElBQUksQ0FBQztZQUNqRCxZQUFZLEVBQUUsTUFBTSxJQUFJLENBQUMsV0FBVyxDQUFDLGFBQWEsQ0FBQyxJQUFJLEVBQUUsSUFBSSxDQUFDO1lBQzlELElBQUk7U0FDTCxDQUFBO0lBQ0gsQ0FBQztJQUVELFNBQVM7SUFDVCxLQUFLLENBQUMsWUFBWSxDQUFDLEVBQVU7UUFDM0IsTUFBTSxJQUFJLEdBQUcsTUFBTSxJQUFJLENBQUMsV0FBVyxDQUFDLEVBQUUsQ0FBQyxDQUFBO1FBQ3ZDLE9BQU8sSUFBSSxDQUFDLFdBQVcsQ0FBQyxhQUFhLENBQUMsSUFBSSxDQUFDLENBQUE7SUFDN0MsQ0FBQztJQUVEOztPQUVHO0lBQ0gsS0FBSyxDQUFDLGNBQWMsQ0FBQyxNQUF5QjtRQUM1QyxNQUFNLEVBQUUsUUFBUSxFQUFFLGVBQWUsRUFBRSxnQkFBZ0IsRUFBRSxHQUFHLE1BQU0sQ0FBQTtRQUM5RCxJQUFJLFFBQVEsS0FBSyxlQUFlLEVBQUU7WUFDaEMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsQ0FBQTtTQUMxQjtRQUNELE1BQU0sRUFBRSxFQUFFLEVBQUUsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQW9CLENBQUE7UUFDOUQsTUFBTSxJQUFJLEdBQUcsTUFBTSxJQUFJLENBQUMsV0FBVyxDQUFDLEVBQUUsQ0FBQyxDQUFBO1FBQ3ZDLE1BQU0sUUFBUSxHQUFHLE1BQU0sSUFBSSxDQUFDLFlBQVksQ0FBQyxnQkFBZ0IsRUFBRSxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUE7UUFDekUsSUFBSSxDQUFDLFFBQVEsRUFBRTtZQUNiLElBQUksQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLENBQUE7U0FDekI7UUFDRCxNQUFNLElBQUksR0FBRyxJQUFJLENBQUMsUUFBUSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQTtRQUN4QyxJQUFJLENBQUMsUUFBUSxHQUFHLE1BQU0sSUFBSSxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsUUFBUSxFQUFFLElBQUksQ0FBQyxDQUFBO1FBQzNELE1BQU0sSUFBSSxDQUFDLE9BQU8sQ0FBQyxTQUFTLENBQUMsSUFBSSxFQUFFLEVBQUUsRUFBRSxFQUFFLElBQUksQ0FBQyxFQUFFLEVBQUUsQ0FBQyxDQUFBO1FBQ25ELE9BQU8sSUFBSSxDQUFDLEVBQUUsQ0FBQTtJQUNoQixDQUFDO0lBRUQ7O09BRUc7SUFDSCxLQUFLLENBQUMsY0FBYyxDQUFDLE1BQXlCO1FBQzVDLE1BQU0sRUFBRSxRQUFRLEVBQUUsT0FBTyxFQUFFLEtBQUssRUFBRSxNQUFNLEVBQUUsRUFBRSxFQUFFLEdBQUcsTUFBTSxDQUFBO1FBQ3ZELE1BQU0sVUFBVSxHQUFHLE1BQU0sSUFBSSxDQUFDLFdBQVcsQ0FBQyxFQUFFLENBQUMsQ0FBQTtRQUU3QyxNQUFNLEtBQUssR0FBRyxJQUFJLENBQUMsYUFBYSxDQUFDO1lBQy9CLFFBQVE7WUFDUixPQUFPO1lBQ1AsS0FBSztZQUNMLE1BQU07U0FDUCxDQUFDLENBQUE7UUFFRixLQUFLLENBQUMsY0FBRSxDQUFDLEdBQUcsQ0FBQyxHQUFHLEVBQUUsRUFBRSxFQUFFLENBQUE7UUFDdEIsTUFBTSxJQUFJLEdBQUcsTUFBTSxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUUsSUFBSSxDQUFDLENBQUE7UUFFcEQsSUFBSSxJQUFJLEVBQUU7WUFDUixJQUFJLENBQUMsV0FBVyxDQUFDLFFBQVEsQ0FBQyxDQUFBO1NBQzNCO1FBRUQsTUFBTSxJQUFJLENBQUMsT0FBTyxDQUFDLFNBQVMsQ0FBQyxNQUFNLEVBQUUsRUFBRSxFQUFFLEVBQUUsVUFBVSxDQUFDLEVBQUUsRUFBRSxDQUFDLENBQUE7UUFDM0QsT0FBTyxNQUFNLENBQUMsRUFBRSxDQUFBO0lBQ2xCLENBQUM7SUFFRDs7Ozs7T0FLRztJQUNLLEtBQUssQ0FBQyxZQUFZLENBQUMsTUFBTSxFQUFFLE1BQU07UUFDdkMsTUFBTSxJQUFJLEdBQUcsTUFBTSxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUMsQ0FBQTtRQUNqQyxNQUFNLGVBQWUsR0FBRyxNQUFNLElBQUksQ0FBQyxLQUFLLENBQUMsVUFBVSxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsQ0FBQTtRQUNqRSxPQUFPLGVBQWUsS0FBSyxNQUFNLENBQUE7SUFDbkMsQ0FBQztDQUNGLENBQUE7QUF4SUM7SUFBQyxJQUFBLGFBQU0sR0FBRTs4QkFDSSwwQkFBVztnREFBQTtBQUV4QjtJQUFDLElBQUEsYUFBTSxHQUFFOzhCQUNPLG9DQUFrQjttREFBQTtBQUVsQztJQUFDLElBQUEsYUFBTSxHQUFFOzhCQUNBLDJCQUFXO0lBRXBCLG9CQUFvQjs7NENBRkE7QUFSVCxXQUFXO0lBRHZCLElBQUEsY0FBTyxHQUFFO0dBQ0csV0FBVyxDQXlJdkI7QUF6SVksa0NBQVcifQ==