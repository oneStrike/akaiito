import { BaseEntity } from '../../../../shared/entities/basic.entity';
export declare class AdminUserEntity extends BaseEntity {
    username: string;
    account: string;
    password: string;
    avatar: string;
    mobile: string;
    email: string;
    isRoot: number;
    status: number;
}
