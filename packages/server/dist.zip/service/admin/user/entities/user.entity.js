"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AdminUserEntity = void 0;
const sequelize_typescript_1 = require("sequelize-typescript");
const basic_entity_1 = require("../../../../shared/entities/basic.entity");
let AdminUserEntity = class AdminUserEntity extends basic_entity_1.BaseEntity {
};
__decorate([
    (0, sequelize_typescript_1.Column)({
        comment: '昵称',
        type: sequelize_typescript_1.DataType.STRING(50),
        unique: true
    }),
    __metadata("design:type", String)
], AdminUserEntity.prototype, "username", void 0);
__decorate([
    (0, sequelize_typescript_1.Column)({
        comment: '账号',
        type: sequelize_typescript_1.DataType.STRING(50),
        unique: true
    }),
    __metadata("design:type", String)
], AdminUserEntity.prototype, "account", void 0);
__decorate([
    (0, sequelize_typescript_1.Column)({
        comment: '密码',
        type: sequelize_typescript_1.DataType.STRING(100)
    }),
    __metadata("design:type", String)
], AdminUserEntity.prototype, "password", void 0);
__decorate([
    (0, sequelize_typescript_1.Column)({
        comment: '头像',
        type: sequelize_typescript_1.DataType.STRING(100)
    }),
    __metadata("design:type", String)
], AdminUserEntity.prototype, "avatar", void 0);
__decorate([
    (0, sequelize_typescript_1.Column)({
        comment: '手机号',
        type: sequelize_typescript_1.DataType.STRING(20),
        unique: true
    }),
    __metadata("design:type", String)
], AdminUserEntity.prototype, "mobile", void 0);
__decorate([
    (0, sequelize_typescript_1.Column)({
        comment: '邮箱',
        type: sequelize_typescript_1.DataType.STRING(100),
        unique: true
    }),
    __metadata("design:type", String)
], AdminUserEntity.prototype, "email", void 0);
__decorate([
    (0, sequelize_typescript_1.Column)({
        type: sequelize_typescript_1.DataType.TINYINT,
        comment: '1超管0普通',
        defaultValue: 0,
    }),
    __metadata("design:type", Number)
], AdminUserEntity.prototype, "isRoot", void 0);
__decorate([
    (0, sequelize_typescript_1.Column)({
        type: sequelize_typescript_1.DataType.TINYINT,
        defaultValue: 1,
        comment: ' 1启用  0禁用',
    }),
    __metadata("design:type", Number)
], AdminUserEntity.prototype, "status", void 0);
AdminUserEntity = __decorate([
    (0, sequelize_typescript_1.Table)({
        tableName: 'admin_user'
    })
], AdminUserEntity);
exports.AdminUserEntity = AdminUserEntity;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoidXNlci5lbnRpdHkuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zcmMvc2VydmljZS9hZG1pbi91c2VyL2VudGl0aWVzL3VzZXIuZW50aXR5LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7OztBQUFBLCtEQUE4RDtBQUM5RCwyRUFBcUU7QUFLOUQsSUFBTSxlQUFlLEdBQXJCLE1BQU0sZUFBZ0IsU0FBUSx5QkFBVTtDQXNEOUMsQ0FBQTtBQXJEQztJQUFDLElBQUEsNkJBQU0sRUFBQztRQUNOLE9BQU8sRUFBRSxJQUFJO1FBQ2IsSUFBSSxFQUFFLCtCQUFRLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQztRQUN6QixNQUFNLEVBQUUsSUFBSTtLQUNiLENBQUM7O2lEQUNjO0FBRWhCO0lBQUMsSUFBQSw2QkFBTSxFQUFDO1FBQ04sT0FBTyxFQUFFLElBQUk7UUFDYixJQUFJLEVBQUUsK0JBQVEsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDO1FBQ3pCLE1BQU0sRUFBRSxJQUFJO0tBQ2IsQ0FBQzs7Z0RBQ2E7QUFFZjtJQUFDLElBQUEsNkJBQU0sRUFBQztRQUNOLE9BQU8sRUFBRSxJQUFJO1FBQ2IsSUFBSSxFQUFFLCtCQUFRLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQztLQUMzQixDQUFDOztpREFDYztBQUVoQjtJQUFDLElBQUEsNkJBQU0sRUFBQztRQUNOLE9BQU8sRUFBRSxJQUFJO1FBQ2IsSUFBSSxFQUFFLCtCQUFRLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQztLQUMzQixDQUFDOzsrQ0FDWTtBQUVkO0lBQUMsSUFBQSw2QkFBTSxFQUFDO1FBQ04sT0FBTyxFQUFFLEtBQUs7UUFDZCxJQUFJLEVBQUUsK0JBQVEsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDO1FBQ3pCLE1BQU0sRUFBRSxJQUFJO0tBQ2IsQ0FBQzs7K0NBQ1k7QUFFZDtJQUFDLElBQUEsNkJBQU0sRUFBQztRQUNOLE9BQU8sRUFBRSxJQUFJO1FBQ2IsSUFBSSxFQUFFLCtCQUFRLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQztRQUMxQixNQUFNLEVBQUUsSUFBSTtLQUNiLENBQUM7OzhDQUNXO0FBRWI7SUFBQyxJQUFBLDZCQUFNLEVBQUM7UUFDTixJQUFJLEVBQUUsK0JBQVEsQ0FBQyxPQUFPO1FBQ3RCLE9BQU8sRUFBRSxRQUFRO1FBQ2pCLFlBQVksRUFBRSxDQUFDO0tBQ2hCLENBQUM7OytDQUNZO0FBRWQ7SUFBQyxJQUFBLDZCQUFNLEVBQUM7UUFDTixJQUFJLEVBQUUsK0JBQVEsQ0FBQyxPQUFPO1FBQ3RCLFlBQVksRUFBRSxDQUFDO1FBQ2YsT0FBTyxFQUFFLFdBQVc7S0FDckIsQ0FBQzs7K0NBQ1k7QUFyREgsZUFBZTtJQUgzQixJQUFBLDRCQUFLLEVBQUM7UUFDTCxTQUFTLEVBQUUsWUFBWTtLQUN4QixDQUFDO0dBQ1csZUFBZSxDQXNEM0I7QUF0RFksMENBQWUifQ==