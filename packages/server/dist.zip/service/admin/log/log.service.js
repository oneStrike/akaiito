"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.LogService = void 0;
const core_1 = require("@midwayjs/core");
const base_service_1 = require("../../../shared/service/base.service");
const log_mapping_1 = require("./mapping/log.mapping");
const service_version_enum_1 = require("../../../shared/enum/service-version.enum");
let LogService = class LogService extends base_service_1.BaseService {
    get repository() {
        return this.mapping.repository;
    }
    /**
     * 写入日志
     */
    async record(ctx) {
        const { path, method, header } = ctx;
        if (this.utils.commonUtil.serviceVersionType(path) ===
            service_version_enum_1.ServiceVersionEnum.CLIENT)
            return;
        let username = null, userAccount = null, userId = null, userInfo;
        const responseBody = ctx.response.body;
        if (path === '/admin/user/login' && responseBody) {
            userInfo = responseBody.user;
        }
        else {
            userInfo = ctx.getAttr('userInfo') || {};
        }
        username = userInfo.username;
        userId = userInfo.id;
        userAccount = userInfo.account;
        const params = method === 'POST' ? ctx.request.body : ctx.query;
        if (params) {
            delete params.password;
            delete params.confirmPassword;
        }
        const { fullUrl, summary } = (await this.webRouterService.getMatchedRouterInfo(path, method)) || {};
        const ip = await this.utils.systemUtil.getReqIP(ctx);
        const { code, desc, status } = ctx.getAttr('responseRes') || {};
        const ipAddress = await this.utils.systemUtil.getIpAddr(ctx, ip);
        const recordInfo = {
            username,
            userId,
            userAccount,
            action: summary,
            ip,
            ipAddress,
            receipt: code,
            receiptDesc: code !== 1 ? desc : status,
            path: fullUrl,
            userAgent: header['user-agent'],
            params: this.utils.lodash.isEmpty(params) ? null : JSON.stringify(params)
        };
        await this.create(recordInfo);
    }
    async findLoginLog(params) {
        params.path = '/admin/user/login';
        return await this.findMultiple({ params });
    }
};
__decorate([
    (0, core_1.Inject)(),
    __metadata("design:type", log_mapping_1.LogMapping)
], LogService.prototype, "mapping", void 0);
LogService = __decorate([
    (0, core_1.Provide)()
], LogService);
exports.LogService = LogService;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibG9nLnNlcnZpY2UuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zcmMvc2VydmljZS9hZG1pbi9sb2cvbG9nLnNlcnZpY2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7O0FBQUEseUNBQWdEO0FBQ2hELHVFQUFrRTtBQUNsRSx1REFBa0Q7QUFFbEQsb0ZBQThFO0FBTXZFLElBQU0sVUFBVSxHQUFoQixNQUFNLFVBQVcsU0FBUSwwQkFBVztJQUl6QyxJQUFjLFVBQVU7UUFDdEIsT0FBTyxJQUFJLENBQUMsT0FBTyxDQUFDLFVBQVUsQ0FBQTtJQUNoQyxDQUFDO0lBRUQ7O09BRUc7SUFDSCxLQUFLLENBQUMsTUFBTSxDQUFDLEdBQVk7UUFDdkIsTUFBTSxFQUFFLElBQUksRUFBRSxNQUFNLEVBQUUsTUFBTSxFQUFFLEdBQUcsR0FBRyxDQUFBO1FBQ3BDLElBQ0UsSUFBSSxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsa0JBQWtCLENBQUMsSUFBSSxDQUFDO1lBQzlDLHlDQUFrQixDQUFDLE1BQU07WUFFekIsT0FBTTtRQUNSLElBQUksUUFBUSxHQUFHLElBQUksRUFDakIsV0FBVyxHQUFHLElBQUksRUFDbEIsTUFBTSxHQUFHLElBQUksRUFDYixRQUFrQyxDQUFBO1FBQ3BDLE1BQU0sWUFBWSxHQUFHLEdBQUcsQ0FBQyxRQUFRLENBQUMsSUFFakMsQ0FBQTtRQUNELElBQUksSUFBSSxLQUFLLG1CQUFtQixJQUFJLFlBQVksRUFBRTtZQUNoRCxRQUFRLEdBQUcsWUFBWSxDQUFDLElBQUksQ0FBQTtTQUM3QjthQUFNO1lBQ0wsUUFBUSxHQUFHLEdBQUcsQ0FBQyxPQUFPLENBQUMsVUFBVSxDQUFDLElBQUksRUFBRSxDQUFBO1NBQ3pDO1FBQ0QsUUFBUSxHQUFHLFFBQVEsQ0FBQyxRQUFRLENBQUE7UUFDNUIsTUFBTSxHQUFHLFFBQVEsQ0FBQyxFQUFFLENBQUE7UUFDcEIsV0FBVyxHQUFHLFFBQVEsQ0FBQyxPQUFPLENBQUE7UUFDOUIsTUFBTSxNQUFNLEdBQVEsTUFBTSxLQUFLLE1BQU0sQ0FBQyxDQUFDLENBQUMsR0FBRyxDQUFDLE9BQU8sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEdBQUcsQ0FBQyxLQUFLLENBQUE7UUFDcEUsSUFBSSxNQUFNLEVBQUU7WUFDVixPQUFPLE1BQU0sQ0FBQyxRQUFRLENBQUE7WUFDdEIsT0FBTyxNQUFNLENBQUMsZUFBZSxDQUFBO1NBQzlCO1FBRUQsTUFBTSxFQUFFLE9BQU8sRUFBRSxPQUFPLEVBQUUsR0FDeEIsQ0FBQyxNQUFNLElBQUksQ0FBQyxnQkFBZ0IsQ0FBQyxvQkFBb0IsQ0FBQyxJQUFJLEVBQUUsTUFBTSxDQUFDLENBQUMsSUFBSSxFQUFFLENBQUE7UUFDeEUsTUFBTSxFQUFFLEdBQUcsTUFBTSxJQUFJLENBQUMsS0FBSyxDQUFDLFVBQVUsQ0FBQyxRQUFRLENBQUMsR0FBRyxDQUFDLENBQUE7UUFFcEQsTUFBTSxFQUFFLElBQUksRUFBRSxJQUFJLEVBQUUsTUFBTSxFQUFFLEdBQzFCLEdBQUcsQ0FBQyxPQUFPLENBQUMsYUFBYSxDQUFDLElBQUksRUFBRSxDQUFBO1FBQ2xDLE1BQU0sU0FBUyxHQUFHLE1BQU0sSUFBSSxDQUFDLEtBQUssQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDLEdBQUcsRUFBRSxFQUFFLENBQUMsQ0FBQTtRQUNoRSxNQUFNLFVBQVUsR0FBRztZQUNqQixRQUFRO1lBQ1IsTUFBTTtZQUNOLFdBQVc7WUFDWCxNQUFNLEVBQUUsT0FBTztZQUNmLEVBQUU7WUFDRixTQUFTO1lBQ1QsT0FBTyxFQUFFLElBQUk7WUFDYixXQUFXLEVBQUUsSUFBSSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxNQUFNO1lBQ3ZDLElBQUksRUFBRSxPQUFPO1lBQ2IsU0FBUyxFQUFFLE1BQU0sQ0FBQyxZQUFZLENBQUM7WUFDL0IsTUFBTSxFQUFFLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUMsU0FBUyxDQUFDLE1BQU0sQ0FBQztTQUMxRSxDQUFBO1FBQ0QsTUFBTSxJQUFJLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBQyxDQUFBO0lBQy9CLENBQUM7SUFFRCxLQUFLLENBQUMsWUFBWSxDQUFDLE1BQW1CO1FBQ3BDLE1BQU0sQ0FBQyxJQUFJLEdBQUcsbUJBQW1CLENBQUE7UUFDakMsT0FBTyxNQUFNLElBQUksQ0FBQyxZQUFZLENBQUMsRUFBQyxNQUFNLEVBQUMsQ0FBQyxDQUFBO0lBQzFDLENBQUM7Q0FDRixDQUFBO0FBakVDO0lBQUMsSUFBQSxhQUFNLEdBQUU7OEJBQ0Esd0JBQVU7MkNBQUE7QUFGUixVQUFVO0lBRHRCLElBQUEsY0FBTyxHQUFFO0dBQ0csVUFBVSxDQWtFdEI7QUFsRVksZ0NBQVUifQ==