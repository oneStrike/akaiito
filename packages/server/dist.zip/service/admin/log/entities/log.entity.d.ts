import { BaseEntity } from '../../../../shared/entities/basic.entity';
export declare class LogEntity extends BaseEntity {
    username?: string;
    userAccount?: string;
    userId?: number;
    action: string;
    ip: string;
    ipAddress: string;
    receipt: number;
    receiptDesc?: string;
    path: string;
    userAgent: string;
    params?: string;
}
