"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.LogEntity = void 0;
const sequelize_typescript_1 = require("sequelize-typescript");
const basic_entity_1 = require("../../../../shared/entities/basic.entity");
let LogEntity = class LogEntity extends basic_entity_1.BaseEntity {
};
__decorate([
    (0, sequelize_typescript_1.Column)({
        type: sequelize_typescript_1.DataType.STRING(50),
        allowNull: true,
        comment: '操作用户'
    }),
    __metadata("design:type", String)
], LogEntity.prototype, "username", void 0);
__decorate([
    (0, sequelize_typescript_1.Column)({
        type: sequelize_typescript_1.DataType.STRING(50),
        allowNull: true,
        comment: '操作账号'
    }),
    __metadata("design:type", String)
], LogEntity.prototype, "userAccount", void 0);
__decorate([
    (0, sequelize_typescript_1.Column)({
        type: sequelize_typescript_1.DataType.INTEGER,
        allowNull: true,
        comment: '用户id'
    }),
    __metadata("design:type", Number)
], LogEntity.prototype, "userId", void 0);
__decorate([
    (0, sequelize_typescript_1.Column)({
        type: sequelize_typescript_1.DataType.STRING(50),
        allowNull: true,
        comment: '行为'
    }),
    __metadata("design:type", String)
], LogEntity.prototype, "action", void 0);
__decorate([
    (0, sequelize_typescript_1.Column)({
        type: sequelize_typescript_1.DataType.STRING(20),
        comment: 'ip'
    }),
    __metadata("design:type", String)
], LogEntity.prototype, "ip", void 0);
__decorate([
    (0, sequelize_typescript_1.Column)({
        type: sequelize_typescript_1.DataType.STRING(300),
        comment: '地址'
    }),
    __metadata("design:type", String)
], LogEntity.prototype, "ipAddress", void 0);
__decorate([
    (0, sequelize_typescript_1.Column)({
        type: sequelize_typescript_1.DataType.INTEGER,
        comment: '回执结果',
        defaultValue: 1
    }),
    __metadata("design:type", Number)
], LogEntity.prototype, "receipt", void 0);
__decorate([
    (0, sequelize_typescript_1.Column)({
        type: sequelize_typescript_1.DataType.STRING(300),
        comment: '回执结果描述',
        allowNull: true
    }),
    __metadata("design:type", String)
], LogEntity.prototype, "receiptDesc", void 0);
__decorate([
    (0, sequelize_typescript_1.Column)({
        type: sequelize_typescript_1.DataType.STRING,
        allowNull: true,
        comment: '路由地址'
    }),
    __metadata("design:type", String)
], LogEntity.prototype, "path", void 0);
__decorate([
    (0, sequelize_typescript_1.Column)({
        type: sequelize_typescript_1.DataType.STRING,
        allowNull: true,
        comment: 'user-agent'
    }),
    __metadata("design:type", String)
], LogEntity.prototype, "userAgent", void 0);
__decorate([
    (0, sequelize_typescript_1.Column)({
        type: sequelize_typescript_1.DataType.TEXT('long'),
        allowNull: true,
        comment: '参数'
    }),
    __metadata("design:type", String)
], LogEntity.prototype, "params", void 0);
LogEntity = __decorate([
    (0, sequelize_typescript_1.Table)({
        tableName: 'admin_log'
    })
], LogEntity);
exports.LogEntity = LogEntity;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibG9nLmVudGl0eS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NyYy9zZXJ2aWNlL2FkbWluL2xvZy9lbnRpdGllcy9sb2cuZW50aXR5LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7OztBQUFBLCtEQUE4RDtBQUM5RCwyRUFBcUU7QUFLOUQsSUFBTSxTQUFTLEdBQWYsTUFBTSxTQUFVLFNBQVEseUJBQVU7Q0EyRXhDLENBQUE7QUExRUM7SUFBQyxJQUFBLDZCQUFNLEVBQUM7UUFDTixJQUFJLEVBQUUsK0JBQVEsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDO1FBQ3pCLFNBQVMsRUFBRSxJQUFJO1FBQ2YsT0FBTyxFQUFFLE1BQU07S0FDaEIsQ0FBQzs7MkNBQ2U7QUFFakI7SUFBQyxJQUFBLDZCQUFNLEVBQUM7UUFDTixJQUFJLEVBQUUsK0JBQVEsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDO1FBQ3pCLFNBQVMsRUFBRSxJQUFJO1FBQ2YsT0FBTyxFQUFFLE1BQU07S0FDaEIsQ0FBQzs7OENBQ2tCO0FBRXBCO0lBQUMsSUFBQSw2QkFBTSxFQUFDO1FBQ04sSUFBSSxFQUFFLCtCQUFRLENBQUMsT0FBTztRQUN0QixTQUFTLEVBQUUsSUFBSTtRQUNmLE9BQU8sRUFBRSxNQUFNO0tBQ2hCLENBQUM7O3lDQUNhO0FBRWY7SUFBQyxJQUFBLDZCQUFNLEVBQUM7UUFDTixJQUFJLEVBQUUsK0JBQVEsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDO1FBQ3pCLFNBQVMsRUFBRSxJQUFJO1FBQ2YsT0FBTyxFQUFFLElBQUk7S0FDZCxDQUFDOzt5Q0FDYTtBQUVmO0lBQUMsSUFBQSw2QkFBTSxFQUFDO1FBQ04sSUFBSSxFQUFFLCtCQUFRLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQztRQUN6QixPQUFPLEVBQUUsSUFBSTtLQUNkLENBQUM7O3FDQUNTO0FBRVg7SUFBQyxJQUFBLDZCQUFNLEVBQUM7UUFDTixJQUFJLEVBQUUsK0JBQVEsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDO1FBQzFCLE9BQU8sRUFBRSxJQUFJO0tBQ2QsQ0FBQzs7NENBQ2dCO0FBRWxCO0lBQUMsSUFBQSw2QkFBTSxFQUFDO1FBQ04sSUFBSSxFQUFFLCtCQUFRLENBQUMsT0FBTztRQUN0QixPQUFPLEVBQUUsTUFBTTtRQUNmLFlBQVksRUFBRSxDQUFDO0tBQ2hCLENBQUM7OzBDQUNjO0FBRWhCO0lBQUMsSUFBQSw2QkFBTSxFQUFDO1FBQ04sSUFBSSxFQUFFLCtCQUFRLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQztRQUMxQixPQUFPLEVBQUUsUUFBUTtRQUNqQixTQUFTLEVBQUUsSUFBSTtLQUNoQixDQUFDOzs4Q0FDa0I7QUFFcEI7SUFBQyxJQUFBLDZCQUFNLEVBQUM7UUFDTixJQUFJLEVBQUUsK0JBQVEsQ0FBQyxNQUFNO1FBQ3JCLFNBQVMsRUFBRSxJQUFJO1FBQ2YsT0FBTyxFQUFFLE1BQU07S0FDaEIsQ0FBQzs7dUNBQ1c7QUFFYjtJQUFDLElBQUEsNkJBQU0sRUFBQztRQUNOLElBQUksRUFBRSwrQkFBUSxDQUFDLE1BQU07UUFDckIsU0FBUyxFQUFFLElBQUk7UUFDZixPQUFPLEVBQUUsWUFBWTtLQUN0QixDQUFDOzs0Q0FDZ0I7QUFFbEI7SUFBQyxJQUFBLDZCQUFNLEVBQUM7UUFDTixJQUFJLEVBQUUsK0JBQVEsQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDO1FBQzNCLFNBQVMsRUFBRSxJQUFJO1FBQ2YsT0FBTyxFQUFFLElBQUk7S0FDZCxDQUFDOzt5Q0FDYTtBQTFFSixTQUFTO0lBSHJCLElBQUEsNEJBQUssRUFBQztRQUNMLFNBQVMsRUFBRSxXQUFXO0tBQ3ZCLENBQUM7R0FDVyxTQUFTLENBMkVyQjtBQTNFWSw4QkFBUyJ9