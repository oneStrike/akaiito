"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.LoginLogDto = void 0;
const validate_1 = require("@midwayjs/validate");
const base_validate_1 = require("../../../../utils/validate/base.validate");
const base_dto_1 = require("../../../../shared/dto/base.dto");
class LoginLogDto extends (0, validate_1.PickDto)(base_dto_1.ListDto, [
    'pageIndex',
    'pageSize',
    'sort',
    'sortField'
]) {
}
__decorate([
    (0, validate_1.Rule)(base_validate_1.validateString),
    __metadata("design:type", String)
], LoginLogDto.prototype, "path", void 0);
__decorate([
    (0, validate_1.Rule)(base_validate_1.validateString),
    __metadata("design:type", String)
], LoginLogDto.prototype, "username", void 0);
__decorate([
    (0, validate_1.Rule)(base_validate_1.validateNumber),
    __metadata("design:type", Number)
], LoginLogDto.prototype, "receipt", void 0);
__decorate([
    (0, validate_1.Rule)(base_validate_1.validateDate),
    __metadata("design:type", Date)
], LoginLogDto.prototype, "startDate", void 0);
__decorate([
    (0, validate_1.Rule)(base_validate_1.validateDate),
    __metadata("design:type", Date)
], LoginLogDto.prototype, "endDate", void 0);
exports.LoginLogDto = LoginLogDto;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibG9naW5Mb2cuZHRvLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vc3JjL3NlcnZpY2UvYWRtaW4vbG9nL2R0by9sb2dpbkxvZy5kdG8udHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7O0FBQUEsaURBQWtEO0FBQ2xELDRFQUlpRDtBQUNqRCw4REFBeUQ7QUFFekQsTUFBYSxXQUFZLFNBQVEsSUFBQSxrQkFBTyxFQUFDLGtCQUFPLEVBQUU7SUFDaEQsV0FBVztJQUNYLFVBQVU7SUFDVixNQUFNO0lBQ04sV0FBVztDQUNaLENBQUM7Q0FlRDtBQWRDO0lBQUMsSUFBQSxlQUFJLEVBQUMsOEJBQWMsQ0FBQzs7eUNBQ1I7QUFFYjtJQUFDLElBQUEsZUFBSSxFQUFDLDhCQUFjLENBQUM7OzZDQUNKO0FBRWpCO0lBQUMsSUFBQSxlQUFJLEVBQUMsOEJBQWMsQ0FBQzs7NENBQ0w7QUFFaEI7SUFBQyxJQUFBLGVBQUksRUFBQyw0QkFBWSxDQUFDOzhCQUNQLElBQUk7OENBQUE7QUFFaEI7SUFBQyxJQUFBLGVBQUksRUFBQyw0QkFBWSxDQUFDOzhCQUNULElBQUk7NENBQUE7QUFuQmhCLGtDQW9CQyJ9