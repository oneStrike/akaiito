import { ListDto } from '../../../../shared/dto/base.dto';
declare const LoginLogDto_base: import("@midwayjs/validate").Dto<Pick<ListDto, "sort" | "sortField" | "pageIndex" | "pageSize">>;
export declare class LoginLogDto extends LoginLogDto_base {
    path?: string;
    username?: string;
    receipt?: number;
    startDate?: Date;
    endDate?: Date;
}
export {};
