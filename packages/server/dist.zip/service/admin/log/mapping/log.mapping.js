"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.LogMapping = void 0;
const core_1 = require("@midwayjs/core");
const sequelize_1 = require("@midwayjs/sequelize");
const log_entity_1 = require("../entities/log.entity");
const base_mapping_1 = require("../../../../shared/mapping/base.mapping");
let LogMapping = class LogMapping extends base_mapping_1.BaseMapping {
};
__decorate([
    (0, sequelize_1.InjectRepository)(log_entity_1.LogEntity),
    __metadata("design:type", Object)
], LogMapping.prototype, "repository", void 0);
LogMapping = __decorate([
    (0, core_1.Provide)()
], LogMapping);
exports.LogMapping = LogMapping;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoibG9nLm1hcHBpbmcuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zcmMvc2VydmljZS9hZG1pbi9sb2cvbWFwcGluZy9sb2cubWFwcGluZy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7QUFBQSx5Q0FBd0M7QUFDeEMsbURBQXNEO0FBRXRELHVEQUFrRDtBQUNsRCwwRUFBcUU7QUFHOUQsSUFBTSxVQUFVLEdBQWhCLE1BQU0sVUFBVyxTQUFRLDBCQUFzQjtDQUdyRCxDQUFBO0FBRkM7SUFBQyxJQUFBLDRCQUFnQixFQUFDLHNCQUFTLENBQUM7OzhDQUNLO0FBRnRCLFVBQVU7SUFEdEIsSUFBQSxjQUFPLEdBQUU7R0FDRyxVQUFVLENBR3RCO0FBSFksZ0NBQVUifQ==