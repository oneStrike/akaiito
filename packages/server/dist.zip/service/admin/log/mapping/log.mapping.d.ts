import { Repository } from 'sequelize-typescript';
import { LogEntity } from '../entities/log.entity';
import { BaseMapping } from '../../../../shared/mapping/base.mapping';
export declare class LogMapping extends BaseMapping<LogEntity> {
    repository: Repository<LogEntity>;
}
