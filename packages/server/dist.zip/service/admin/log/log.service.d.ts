import { BaseService } from '../../../shared/service/base.service';
import { LogMapping } from './mapping/log.mapping';
import { Context } from '@midwayjs/koa';
import { LoginLogDto } from './dto/loginLog.dto';
export declare class LogService extends BaseService {
    mapping: LogMapping;
    protected get repository(): import("sequelize-typescript").Repository<import("./entities/log.entity").LogEntity>;
    /**
     * 写入日志
     */
    record(ctx: Context): Promise<void>;
    findLoginLog(params: LoginLogDto): Promise<import("../../../types/dto/list").ListResponseRes<import("sequelize-typescript").Model<any, any>>>;
}
