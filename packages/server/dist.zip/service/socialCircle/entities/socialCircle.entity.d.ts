import { BaseEntity } from "../../../shared/entities/basic.entity";
export declare class SocialCircleClassifyEntity extends BaseEntity {
    classifyName: string;
    sort: number;
}
export declare class SocialCircleEntity extends BaseEntity {
    name: string;
    icon?: string;
    cover?: string;
    creatorId: number;
    creatorName: number;
    classifyId: number;
    classifyName: number;
    desc: number;
    memberTitle: number;
    followers: number;
    vFollowers: number;
    rule: string;
    guide: number;
    status: number;
    bannedReason?: string;
}
