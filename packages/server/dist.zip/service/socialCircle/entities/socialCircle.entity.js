"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SocialCircleEntity = exports.SocialCircleClassifyEntity = void 0;
const sequelize_typescript_1 = require("sequelize-typescript");
const basic_entity_1 = require("../../../shared/entities/basic.entity");
//社交圈子分类
let SocialCircleClassifyEntity = class SocialCircleClassifyEntity extends basic_entity_1.BaseEntity {
};
__decorate([
    (0, sequelize_typescript_1.Column)({
        comment: "分类名称",
        type: sequelize_typescript_1.DataType.STRING(50),
        unique: true,
        allowNull: false
    }),
    __metadata("design:type", String)
], SocialCircleClassifyEntity.prototype, "classifyName", void 0);
__decorate([
    (0, sequelize_typescript_1.Column)({
        type: sequelize_typescript_1.DataType.INTEGER,
        allowNull: false,
        unique: true,
        comment: "排序"
    }),
    __metadata("design:type", Number)
], SocialCircleClassifyEntity.prototype, "sort", void 0);
SocialCircleClassifyEntity = __decorate([
    (0, sequelize_typescript_1.Table)({
        tableName: "social_circle_classify"
    })
], SocialCircleClassifyEntity);
exports.SocialCircleClassifyEntity = SocialCircleClassifyEntity;
let SocialCircleEntity = class SocialCircleEntity extends basic_entity_1.BaseEntity {
};
__decorate([
    (0, sequelize_typescript_1.Column)({
        comment: "圈子名称",
        type: sequelize_typescript_1.DataType.STRING(50),
        unique: true
    }),
    __metadata("design:type", String)
], SocialCircleEntity.prototype, "name", void 0);
__decorate([
    (0, sequelize_typescript_1.Column)({
        comment: "图标",
        type: sequelize_typescript_1.DataType.STRING,
        allowNull: false
    }),
    __metadata("design:type", String)
], SocialCircleEntity.prototype, "icon", void 0);
__decorate([
    (0, sequelize_typescript_1.Column)({
        comment: "封面",
        type: sequelize_typescript_1.DataType.STRING,
        allowNull: false
    }),
    __metadata("design:type", String)
], SocialCircleEntity.prototype, "cover", void 0);
__decorate([
    (0, sequelize_typescript_1.Column)({
        comment: "创建者id",
        type: sequelize_typescript_1.DataType.INTEGER
    }),
    __metadata("design:type", Number)
], SocialCircleEntity.prototype, "creatorId", void 0);
__decorate([
    (0, sequelize_typescript_1.Column)({
        comment: "创建者名字",
        type: sequelize_typescript_1.DataType.STRING(50),
        allowNull: false
    }),
    __metadata("design:type", Number)
], SocialCircleEntity.prototype, "creatorName", void 0);
__decorate([
    (0, sequelize_typescript_1.Column)({
        comment: "分类id",
        type: sequelize_typescript_1.DataType.INTEGER
    }),
    __metadata("design:type", Number)
], SocialCircleEntity.prototype, "classifyId", void 0);
__decorate([
    (0, sequelize_typescript_1.Column)({
        comment: "分类名字",
        type: sequelize_typescript_1.DataType.STRING(50)
    }),
    __metadata("design:type", Number)
], SocialCircleEntity.prototype, "classifyName", void 0);
__decorate([
    (0, sequelize_typescript_1.Column)({
        comment: "描述",
        type: sequelize_typescript_1.DataType.STRING,
        allowNull: false
    }),
    __metadata("design:type", Number)
], SocialCircleEntity.prototype, "desc", void 0);
__decorate([
    (0, sequelize_typescript_1.Column)({
        comment: "成员称号",
        type: sequelize_typescript_1.DataType.STRING(50),
        allowNull: false
    }),
    __metadata("design:type", Number)
], SocialCircleEntity.prototype, "memberTitle", void 0);
__decorate([
    (0, sequelize_typescript_1.Column)({
        comment: "关注人数",
        type: sequelize_typescript_1.DataType.INTEGER,
        defaultValue: 0
    }),
    __metadata("design:type", Number)
], SocialCircleEntity.prototype, "followers", void 0);
__decorate([
    (0, sequelize_typescript_1.Column)({
        comment: "虚拟关注人数",
        type: sequelize_typescript_1.DataType.INTEGER,
        defaultValue: 0
    }),
    __metadata("design:type", Number)
], SocialCircleEntity.prototype, "vFollowers", void 0);
__decorate([
    (0, sequelize_typescript_1.Column)({
        comment: "规则",
        type: sequelize_typescript_1.DataType.STRING,
        allowNull: false
    }),
    __metadata("design:type", String)
], SocialCircleEntity.prototype, "rule", void 0);
__decorate([
    (0, sequelize_typescript_1.Column)({
        comment: "是否展示在引导页面，1是 0否",
        type: sequelize_typescript_1.DataType.TINYINT,
        defaultValue: 0
    }),
    __metadata("design:type", Number)
], SocialCircleEntity.prototype, "guide", void 0);
__decorate([
    (0, sequelize_typescript_1.Column)({
        comment: "状态  1正常 0封禁",
        type: sequelize_typescript_1.DataType.TINYINT,
        defaultValue: 0
    }),
    __metadata("design:type", Number)
], SocialCircleEntity.prototype, "status", void 0);
__decorate([
    (0, sequelize_typescript_1.Column)({
        comment: "封禁的原因",
        type: sequelize_typescript_1.DataType.STRING
    }),
    __metadata("design:type", String)
], SocialCircleEntity.prototype, "bannedReason", void 0);
SocialCircleEntity = __decorate([
    (0, sequelize_typescript_1.Table)({
        tableName: "social_circle"
    })
], SocialCircleEntity);
exports.SocialCircleEntity = SocialCircleEntity;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic29jaWFsQ2lyY2xlLmVudGl0eS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NyYy9zZXJ2aWNlL3NvY2lhbENpcmNsZS9lbnRpdGllcy9zb2NpYWxDaXJjbGUuZW50aXR5LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7OztBQUFBLCtEQUErRDtBQUMvRCx3RUFBbUU7QUFHbkUsUUFBUTtBQUlELElBQU0sMEJBQTBCLEdBQWhDLE1BQU0sMEJBQTJCLFNBQVEseUJBQVU7Q0FpQnpELENBQUE7QUFoQkM7SUFBQyxJQUFBLDZCQUFNLEVBQUM7UUFDTixPQUFPLEVBQUUsTUFBTTtRQUNmLElBQUksRUFBRSwrQkFBUSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUM7UUFDekIsTUFBTSxFQUFFLElBQUk7UUFDWixTQUFTLEVBQUUsS0FBSztLQUNqQixDQUFDOztnRUFDbUI7QUFHckI7SUFBQyxJQUFBLDZCQUFNLEVBQUM7UUFDTixJQUFJLEVBQUUsK0JBQVEsQ0FBQyxPQUFPO1FBQ3RCLFNBQVMsRUFBRSxLQUFLO1FBQ2hCLE1BQU0sRUFBRSxJQUFJO1FBQ1osT0FBTyxFQUFFLElBQUk7S0FDZCxDQUFDOzt3REFDVztBQWhCRiwwQkFBMEI7SUFIdEMsSUFBQSw0QkFBSyxFQUFDO1FBQ0wsU0FBUyxFQUFFLHdCQUF3QjtLQUNwQyxDQUFDO0dBQ1csMEJBQTBCLENBaUJ0QztBQWpCWSxnRUFBMEI7QUFzQmhDLElBQU0sa0JBQWtCLEdBQXhCLE1BQU0sa0JBQW1CLFNBQVEseUJBQVU7Q0F1R2pELENBQUE7QUF0R0M7SUFBQyxJQUFBLDZCQUFNLEVBQUM7UUFDTixPQUFPLEVBQUUsTUFBTTtRQUNmLElBQUksRUFBRSwrQkFBUSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUM7UUFDekIsTUFBTSxFQUFFLElBQUk7S0FDYixDQUFDOztnREFDVztBQUViO0lBQUMsSUFBQSw2QkFBTSxFQUFDO1FBQ04sT0FBTyxFQUFFLElBQUk7UUFDYixJQUFJLEVBQUUsK0JBQVEsQ0FBQyxNQUFNO1FBQ3JCLFNBQVMsRUFBRSxLQUFLO0tBQ2pCLENBQUM7O2dEQUNZO0FBRWQ7SUFBQyxJQUFBLDZCQUFNLEVBQUM7UUFDTixPQUFPLEVBQUUsSUFBSTtRQUNiLElBQUksRUFBRSwrQkFBUSxDQUFDLE1BQU07UUFDckIsU0FBUyxFQUFFLEtBQUs7S0FDakIsQ0FBQzs7aURBQ2E7QUFFZjtJQUFDLElBQUEsNkJBQU0sRUFBQztRQUNOLE9BQU8sRUFBRSxPQUFPO1FBQ2hCLElBQUksRUFBRSwrQkFBUSxDQUFDLE9BQU87S0FDdkIsQ0FBQzs7cURBQ2dCO0FBRWxCO0lBQUMsSUFBQSw2QkFBTSxFQUFDO1FBQ04sT0FBTyxFQUFFLE9BQU87UUFDaEIsSUFBSSxFQUFFLCtCQUFRLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQztRQUN6QixTQUFTLEVBQUUsS0FBSztLQUNqQixDQUFDOzt1REFDa0I7QUFHcEI7SUFBQyxJQUFBLDZCQUFNLEVBQUM7UUFDTixPQUFPLEVBQUUsTUFBTTtRQUNmLElBQUksRUFBRSwrQkFBUSxDQUFDLE9BQU87S0FDdkIsQ0FBQzs7c0RBQ2lCO0FBR25CO0lBQUMsSUFBQSw2QkFBTSxFQUFDO1FBQ04sT0FBTyxFQUFFLE1BQU07UUFDZixJQUFJLEVBQUUsK0JBQVEsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDO0tBQzFCLENBQUM7O3dEQUNtQjtBQUVyQjtJQUFDLElBQUEsNkJBQU0sRUFBQztRQUNOLE9BQU8sRUFBRSxJQUFJO1FBQ2IsSUFBSSxFQUFFLCtCQUFRLENBQUMsTUFBTTtRQUNyQixTQUFTLEVBQUUsS0FBSztLQUNqQixDQUFDOztnREFDVztBQUViO0lBQUMsSUFBQSw2QkFBTSxFQUFDO1FBQ04sT0FBTyxFQUFFLE1BQU07UUFDZixJQUFJLEVBQUUsK0JBQVEsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDO1FBQ3pCLFNBQVMsRUFBRSxLQUFLO0tBQ2pCLENBQUM7O3VEQUNrQjtBQUVwQjtJQUFDLElBQUEsNkJBQU0sRUFBQztRQUNOLE9BQU8sRUFBRSxNQUFNO1FBQ2YsSUFBSSxFQUFFLCtCQUFRLENBQUMsT0FBTztRQUN0QixZQUFZLEVBQUUsQ0FBQztLQUNoQixDQUFDOztxREFDZ0I7QUFFbEI7SUFBQyxJQUFBLDZCQUFNLEVBQUM7UUFDTixPQUFPLEVBQUUsUUFBUTtRQUNqQixJQUFJLEVBQUUsK0JBQVEsQ0FBQyxPQUFPO1FBQ3RCLFlBQVksRUFBRSxDQUFDO0tBQ2hCLENBQUM7O3NEQUNpQjtBQUVuQjtJQUFDLElBQUEsNkJBQU0sRUFBQztRQUNOLE9BQU8sRUFBRSxJQUFJO1FBQ2IsSUFBSSxFQUFFLCtCQUFRLENBQUMsTUFBTTtRQUNyQixTQUFTLEVBQUUsS0FBSztLQUNqQixDQUFDOztnREFDVztBQUViO0lBQUMsSUFBQSw2QkFBTSxFQUFDO1FBQ04sT0FBTyxFQUFFLGlCQUFpQjtRQUMxQixJQUFJLEVBQUUsK0JBQVEsQ0FBQyxPQUFPO1FBQ3RCLFlBQVksRUFBRSxDQUFDO0tBQ2hCLENBQUM7O2lEQUNZO0FBRWQ7SUFBQyxJQUFBLDZCQUFNLEVBQUM7UUFDTixPQUFPLEVBQUUsYUFBYTtRQUN0QixJQUFJLEVBQUUsK0JBQVEsQ0FBQyxPQUFPO1FBQ3RCLFlBQVksRUFBRSxDQUFDO0tBQ2hCLENBQUM7O2tEQUNhO0FBRWY7SUFBQyxJQUFBLDZCQUFNLEVBQUM7UUFDTixPQUFPLEVBQUUsT0FBTztRQUNoQixJQUFJLEVBQUUsK0JBQVEsQ0FBQyxNQUFNO0tBQ3RCLENBQUM7O3dEQUNvQjtBQXRHWCxrQkFBa0I7SUFIOUIsSUFBQSw0QkFBSyxFQUFDO1FBQ0wsU0FBUyxFQUFFLGVBQWU7S0FDM0IsQ0FBQztHQUNXLGtCQUFrQixDQXVHOUI7QUF2R1ksZ0RBQWtCIn0=