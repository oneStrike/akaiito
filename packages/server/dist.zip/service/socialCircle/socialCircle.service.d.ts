import { BaseService } from "../../shared/service/base.service";
import { SocialCircleMapping } from "./mapping/socialCircle.mapping";
import { CreateSocialCircleClassifyDto, CreateSocialCircleDto, getSocialCirclePageDto } from "./dto/socialCircle.dto";
import { SocialCircleClassifyMapping } from "./mapping/socialCircleClassify.mapping";
export declare class SocialCircleService extends BaseService {
    mapping: SocialCircleMapping;
    classifyMapping: SocialCircleClassifyMapping;
    createSocialCircle(params: CreateSocialCircleDto): Promise<any>;
    createSocialCircleClassify(params: CreateSocialCircleClassifyDto): Promise<any>;
    getSocialCirclePage(params: getSocialCirclePageDto, isClient?: boolean): Promise<import("../../types/dto/list").ListResponseRes<import("sequelize-typescript").Model<any, any>>>;
}
