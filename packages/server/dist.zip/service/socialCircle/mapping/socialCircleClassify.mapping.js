"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SocialCircleClassifyMapping = void 0;
const base_mapping_1 = require("../../../shared/mapping/base.mapping");
const socialCircle_entity_1 = require("../entities/socialCircle.entity");
const sequelize_1 = require("@midwayjs/sequelize");
const core_1 = require("@midwayjs/core");
let SocialCircleClassifyMapping = class SocialCircleClassifyMapping extends base_mapping_1.BaseMapping {
};
__decorate([
    (0, sequelize_1.InjectRepository)(socialCircle_entity_1.SocialCircleClassifyEntity),
    __metadata("design:type", Object)
], SocialCircleClassifyMapping.prototype, "repository", void 0);
SocialCircleClassifyMapping = __decorate([
    (0, core_1.Provide)()
], SocialCircleClassifyMapping);
exports.SocialCircleClassifyMapping = SocialCircleClassifyMapping;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic29jaWFsQ2lyY2xlQ2xhc3NpZnkubWFwcGluZy5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NyYy9zZXJ2aWNlL3NvY2lhbENpcmNsZS9tYXBwaW5nL3NvY2lhbENpcmNsZUNsYXNzaWZ5Lm1hcHBpbmcudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7O0FBQUEsdUVBQW1FO0FBRW5FLHlFQUE2RTtBQUM3RSxtREFBdUQ7QUFDdkQseUNBQXlDO0FBR2xDLElBQU0sMkJBQTJCLEdBQWpDLE1BQU0sMkJBQTRCLFNBQVEsMEJBQVc7Q0FJM0QsQ0FBQTtBQUhDO0lBQUMsSUFBQSw0QkFBZ0IsRUFBQyxnREFBMEIsQ0FBQzs7K0RBQ2dCO0FBRmxELDJCQUEyQjtJQUR2QyxJQUFBLGNBQU8sR0FBRTtHQUNHLDJCQUEyQixDQUl2QztBQUpZLGtFQUEyQiJ9