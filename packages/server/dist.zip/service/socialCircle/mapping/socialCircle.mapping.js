"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SocialCircleMapping = void 0;
const base_mapping_1 = require("../../../shared/mapping/base.mapping");
const socialCircle_entity_1 = require("../entities/socialCircle.entity");
const sequelize_1 = require("@midwayjs/sequelize");
const core_1 = require("@midwayjs/core");
let SocialCircleMapping = class SocialCircleMapping extends base_mapping_1.BaseMapping {
};
__decorate([
    (0, sequelize_1.InjectRepository)(socialCircle_entity_1.SocialCircleEntity),
    __metadata("design:type", Object)
], SocialCircleMapping.prototype, "repository", void 0);
SocialCircleMapping = __decorate([
    (0, core_1.Provide)()
], SocialCircleMapping);
exports.SocialCircleMapping = SocialCircleMapping;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic29jaWFsQ2lyY2xlLm1hcHBpbmcuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zcmMvc2VydmljZS9zb2NpYWxDaXJjbGUvbWFwcGluZy9zb2NpYWxDaXJjbGUubWFwcGluZy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7QUFBQSx1RUFBbUU7QUFFbkUseUVBQXFFO0FBQ3JFLG1EQUF1RDtBQUN2RCx5Q0FBeUM7QUFHbEMsSUFBTSxtQkFBbUIsR0FBekIsTUFBTSxtQkFBb0IsU0FBUSwwQkFBVztDQUluRCxDQUFBO0FBSEM7SUFBQyxJQUFBLDRCQUFnQixFQUFDLHdDQUFrQixDQUFDOzt1REFDZ0I7QUFGMUMsbUJBQW1CO0lBRC9CLElBQUEsY0FBTyxHQUFFO0dBQ0csbUJBQW1CLENBSS9CO0FBSlksa0RBQW1CIn0=