import { BaseMapping } from "../../../shared/mapping/base.mapping";
import { Repository } from "sequelize-typescript";
import { SocialCircleEntity } from "../entities/socialCircle.entity";
export declare class SocialCircleMapping extends BaseMapping {
    protected repository: Repository<SocialCircleEntity>;
}
