import { BaseMapping } from "../../../shared/mapping/base.mapping";
import { Repository } from "sequelize-typescript";
import { SocialCircleClassifyEntity } from "../entities/socialCircle.entity";
export declare class SocialCircleClassifyMapping extends BaseMapping {
    protected repository: Repository<SocialCircleClassifyEntity>;
}
