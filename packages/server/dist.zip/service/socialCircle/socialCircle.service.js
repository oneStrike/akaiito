"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SocialCircleService = void 0;
const base_service_1 = require("../../shared/service/base.service");
const core_1 = require("@midwayjs/core");
const socialCircle_mapping_1 = require("./mapping/socialCircle.mapping");
const socialCircleClassify_mapping_1 = require("./mapping/socialCircleClassify.mapping");
let SocialCircleService = class SocialCircleService extends base_service_1.BaseService {
    async createSocialCircle(params) {
        const data = await this.classifyMapping.findByPk(params.classifyId);
        if (!data) {
            this.normalError("分类不存在");
            return;
        }
        try {
            params.classifyName = data.classifyName;
            if (typeof params.status === "undefined")
                params.status = 1;
            return (await this.mapping.create(params)).id;
        }
        catch (e) {
            console.log(e);
            return this.isUniqueError(e);
        }
    }
    async createSocialCircleClassify(params) {
        try {
            params.sort = (await this.getMaxSort("sort", this.classifyMapping)) + 1;
            return (await this.classifyMapping.create(params)).id;
        }
        catch (e) {
            console.log(e);
            return this.isUniqueError(e);
        }
    }
    async getSocialCirclePage(params, isClient = false) {
        const nullKeys = Number(params.orphan) ? { classifyId: "is" } : null;
        const likeKeys = params.name ? { name: "include" } : null;
        delete params.orphan;
        const exclude = ["desc", "rule", "cover"];
        isClient && exclude.push("vFollowers");
        return this.findMultiple({
            params,
            likeKeys,
            nullKeys,
            attributes: { exclude }
        });
    }
};
__decorate([
    (0, core_1.Inject)(),
    __metadata("design:type", socialCircle_mapping_1.SocialCircleMapping)
], SocialCircleService.prototype, "mapping", void 0);
__decorate([
    (0, core_1.Inject)(),
    __metadata("design:type", socialCircleClassify_mapping_1.SocialCircleClassifyMapping)
], SocialCircleService.prototype, "classifyMapping", void 0);
SocialCircleService = __decorate([
    (0, core_1.Provide)()
], SocialCircleService);
exports.SocialCircleService = SocialCircleService;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic29jaWFsQ2lyY2xlLnNlcnZpY2UuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi9zcmMvc2VydmljZS9zb2NpYWxDaXJjbGUvc29jaWFsQ2lyY2xlLnNlcnZpY2UudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7O0FBQUEsb0VBQWdFO0FBQ2hFLHlDQUFpRDtBQUNqRCx5RUFBcUU7QUFFckUseUZBQXFGO0FBSzlFLElBQU0sbUJBQW1CLEdBQXpCLE1BQU0sbUJBQW9CLFNBQVEsMEJBQVc7SUFPbEQsS0FBSyxDQUFDLGtCQUFrQixDQUFDLE1BQTZCO1FBQ3BELE1BQU0sSUFBSSxHQUFHLE1BQU0sSUFBSSxDQUFDLGVBQWUsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLFVBQVUsQ0FBK0IsQ0FBQztRQUNsRyxJQUFJLENBQUMsSUFBSSxFQUFFO1lBQ1QsSUFBSSxDQUFDLFdBQVcsQ0FBQyxPQUFPLENBQUMsQ0FBQztZQUMxQixPQUFPO1NBQ1I7UUFFRCxJQUFJO1lBQ0YsTUFBTSxDQUFDLFlBQVksR0FBRyxJQUFJLENBQUMsWUFBWSxDQUFDO1lBQ3hDLElBQUksT0FBTyxNQUFNLENBQUMsTUFBTSxLQUFLLFdBQVc7Z0JBQUUsTUFBTSxDQUFDLE1BQU0sR0FBRyxDQUFDLENBQUM7WUFDNUQsT0FBTyxDQUFDLE1BQU0sSUFBSSxDQUFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7U0FDL0M7UUFBQyxPQUFPLENBQUMsRUFBRTtZQUNWLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDZixPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUM7U0FDOUI7SUFDSCxDQUFDO0lBRUQsS0FBSyxDQUFDLDBCQUEwQixDQUFDLE1BQXFDO1FBQ3BFLElBQUk7WUFDRixNQUFNLENBQUMsSUFBSSxHQUFHLENBQUMsTUFBTSxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsZUFBZSxDQUFDLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDeEUsT0FBTyxDQUFDLE1BQU0sSUFBSSxDQUFDLGVBQWUsQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxFQUFFLENBQUM7U0FDdkQ7UUFBQyxPQUFPLENBQUMsRUFBRTtZQUNWLE9BQU8sQ0FBQyxHQUFHLENBQUMsQ0FBQyxDQUFDLENBQUM7WUFDZixPQUFPLElBQUksQ0FBQyxhQUFhLENBQUMsQ0FBQyxDQUFDLENBQUM7U0FDOUI7SUFDSCxDQUFDO0lBRUQsS0FBSyxDQUFDLG1CQUFtQixDQUFDLE1BQThCLEVBQUUsUUFBUSxHQUFHLEtBQUs7UUFDeEUsTUFBTSxRQUFRLEdBQTJDLE1BQU0sQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUUsVUFBVSxFQUFFLElBQUksRUFBRSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7UUFDN0csTUFBTSxRQUFRLEdBQTJDLE1BQU0sQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLEVBQUUsSUFBSSxFQUFFLFNBQVMsRUFBRSxDQUFDLENBQUMsQ0FBQyxJQUFJLENBQUM7UUFDbEcsT0FBTyxNQUFNLENBQUMsTUFBTSxDQUFDO1FBQ3JCLE1BQU0sT0FBTyxHQUFHLENBQUMsTUFBTSxFQUFFLE1BQU0sRUFBRSxPQUFPLENBQUMsQ0FBQztRQUMxQyxRQUFRLElBQUksT0FBTyxDQUFDLElBQUksQ0FBQyxZQUFZLENBQUMsQ0FBQztRQUN2QyxPQUFPLElBQUksQ0FBQyxZQUFZLENBQUM7WUFDdkIsTUFBTTtZQUNOLFFBQVE7WUFDUixRQUFRO1lBQ1IsVUFBVSxFQUFFLEVBQUUsT0FBTyxFQUFFO1NBQ3hCLENBQUMsQ0FBQztJQUVMLENBQUM7Q0FDRixDQUFBO0FBL0NDO0lBQUMsSUFBQSxhQUFNLEdBQUU7OEJBQ0EsMENBQW1CO29EQUFDO0FBRTdCO0lBQUMsSUFBQSxhQUFNLEdBQUU7OEJBQ1EsMERBQTJCOzREQUFDO0FBTGxDLG1CQUFtQjtJQUQvQixJQUFBLGNBQU8sR0FBRTtHQUNHLG1CQUFtQixDQWdEL0I7QUFoRFksa0RBQW1CIn0=