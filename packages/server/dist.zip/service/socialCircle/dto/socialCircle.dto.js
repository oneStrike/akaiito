"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.getSocialCirclePageDto = exports.UpdateSocialCircleGuideStatusDto = exports.UpdateSocialCircleStatusDto = exports.UpdateSocialCircleDto = exports.CreateClientSocialCircleDto = exports.CreateSocialCircleDto = exports.UpdateSocialCircleClassifyDto = exports.CreateSocialCircleClassifyDto = exports.SocialCircleClassifyDto = exports.SocialCircleDto = void 0;
const validate_1 = require("@midwayjs/validate");
const base_validate_1 = require("../../../utils/validate/base.validate");
const base_dto_1 = require("../../../shared/dto/base.dto");
class SocialCircleDto {
}
__decorate([
    (0, validate_1.Rule)(base_validate_1.requiredNumber),
    __metadata("design:type", Number)
], SocialCircleDto.prototype, "id", void 0);
__decorate([
    (0, validate_1.Rule)(base_validate_1.requiredNumber),
    __metadata("design:type", Number)
], SocialCircleDto.prototype, "creatorId", void 0);
__decorate([
    (0, validate_1.Rule)(base_validate_1.requiredString),
    __metadata("design:type", String)
], SocialCircleDto.prototype, "creatorName", void 0);
__decorate([
    (0, validate_1.Rule)(base_validate_1.validateString),
    __metadata("design:type", String)
], SocialCircleDto.prototype, "classifyName", void 0);
__decorate([
    (0, validate_1.Rule)(base_validate_1.validateNumber),
    __metadata("design:type", Number)
], SocialCircleDto.prototype, "classifyId", void 0);
__decorate([
    (0, validate_1.Rule)(base_validate_1.requiredString),
    __metadata("design:type", String)
], SocialCircleDto.prototype, "name", void 0);
__decorate([
    (0, validate_1.Rule)(base_validate_1.requiredString),
    __metadata("design:type", String)
], SocialCircleDto.prototype, "icon", void 0);
__decorate([
    (0, validate_1.Rule)(base_validate_1.validateString),
    __metadata("design:type", String)
], SocialCircleDto.prototype, "cover", void 0);
__decorate([
    (0, validate_1.Rule)(base_validate_1.requiredString),
    __metadata("design:type", String)
], SocialCircleDto.prototype, "desc", void 0);
__decorate([
    (0, validate_1.Rule)(base_validate_1.requiredString),
    __metadata("design:type", String)
], SocialCircleDto.prototype, "memberTitle", void 0);
__decorate([
    (0, validate_1.Rule)(base_validate_1.validateNumber),
    __metadata("design:type", Number)
], SocialCircleDto.prototype, "vFollowers", void 0);
__decorate([
    (0, validate_1.Rule)(base_validate_1.requiredString),
    __metadata("design:type", String)
], SocialCircleDto.prototype, "rule", void 0);
__decorate([
    (0, validate_1.Rule)((0, base_validate_1.givenValue)([0, 1], false)),
    __metadata("design:type", Number)
], SocialCircleDto.prototype, "guide", void 0);
__decorate([
    (0, validate_1.Rule)((0, base_validate_1.givenValue)([0, 1, 2, 3], false)),
    __metadata("design:type", Number)
], SocialCircleDto.prototype, "status", void 0);
__decorate([
    (0, validate_1.Rule)(base_validate_1.validateString),
    __metadata("design:type", String)
], SocialCircleDto.prototype, "bannedReason", void 0);
exports.SocialCircleDto = SocialCircleDto;
class SocialCircleClassifyDto {
}
__decorate([
    (0, validate_1.Rule)(base_validate_1.requiredNumber),
    __metadata("design:type", Number)
], SocialCircleClassifyDto.prototype, "id", void 0);
__decorate([
    (0, validate_1.Rule)(base_validate_1.requiredString),
    __metadata("design:type", String)
], SocialCircleClassifyDto.prototype, "classifyName", void 0);
__decorate([
    (0, validate_1.Rule)(base_validate_1.validateNumber),
    __metadata("design:type", Number)
], SocialCircleClassifyDto.prototype, "sort", void 0);
exports.SocialCircleClassifyDto = SocialCircleClassifyDto;
class CreateSocialCircleClassifyDto extends (0, validate_1.PickDto)(SocialCircleClassifyDto, ["classifyName", "sort"]) {
}
exports.CreateSocialCircleClassifyDto = CreateSocialCircleClassifyDto;
class UpdateSocialCircleClassifyDto extends (0, validate_1.OmitDto)(SocialCircleClassifyDto, ["sort"]) {
}
exports.UpdateSocialCircleClassifyDto = UpdateSocialCircleClassifyDto;
class CreateSocialCircleDto extends (0, validate_1.OmitDto)(SocialCircleDto, ["id", "bannedReason"]) {
}
exports.CreateSocialCircleDto = CreateSocialCircleDto;
class CreateClientSocialCircleDto extends (0, validate_1.OmitDto)(SocialCircleDto, ["id", "guide", "bannedReason"]) {
}
exports.CreateClientSocialCircleDto = CreateClientSocialCircleDto;
class UpdateSocialCircleDto extends (0, validate_1.OmitDto)(SocialCircleDto, ["status", "bannedReason"]) {
}
exports.UpdateSocialCircleDto = UpdateSocialCircleDto;
class UpdateSocialCircleStatusDto extends (0, validate_1.PickDto)(SocialCircleDto, ["id", "status", "bannedReason"]) {
}
exports.UpdateSocialCircleStatusDto = UpdateSocialCircleStatusDto;
class UpdateSocialCircleGuideStatusDto extends (0, validate_1.PickDto)(SocialCircleDto, ["id"]) {
}
__decorate([
    (0, validate_1.Rule)((0, base_validate_1.givenValue)([0, 1], true)),
    __metadata("design:type", Number)
], UpdateSocialCircleGuideStatusDto.prototype, "guide", void 0);
exports.UpdateSocialCircleGuideStatusDto = UpdateSocialCircleGuideStatusDto;
class getSocialCirclePageDto extends base_dto_1.ListDto {
}
__decorate([
    (0, validate_1.Rule)(base_validate_1.validateString),
    __metadata("design:type", String)
], getSocialCirclePageDto.prototype, "name", void 0);
__decorate([
    (0, validate_1.Rule)(base_validate_1.validateNumber),
    __metadata("design:type", Number)
], getSocialCirclePageDto.prototype, "guide", void 0);
__decorate([
    (0, validate_1.Rule)((0, base_validate_1.givenValue)([0, 1, 2, 3], false)),
    __metadata("design:type", Number)
], getSocialCirclePageDto.prototype, "status", void 0);
__decorate([
    (0, validate_1.Rule)(base_validate_1.validateNumber),
    __metadata("design:type", Number)
], getSocialCirclePageDto.prototype, "classifyId", void 0);
__decorate([
    (0, validate_1.Rule)((0, base_validate_1.givenValue)([0, 1], false)),
    __metadata("design:type", Number)
], getSocialCirclePageDto.prototype, "orphan", void 0);
exports.getSocialCirclePageDto = getSocialCirclePageDto;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic29jaWFsQ2lyY2xlLmR0by5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uL3NyYy9zZXJ2aWNlL3NvY2lhbENpcmNsZS9kdG8vc29jaWFsQ2lyY2xlLmR0by50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7QUFBQSxpREFBNEQ7QUFDNUQseUVBSytDO0FBQy9DLDJEQUF1RDtBQUV2RCxNQUFhLGVBQWU7Q0E2QzNCO0FBNUNDO0lBQUMsSUFBQSxlQUFJLEVBQUMsOEJBQWMsQ0FBQzs7MkNBQ1Y7QUFFWDtJQUFDLElBQUEsZUFBSSxFQUFDLDhCQUFjLENBQUM7O2tEQUNIO0FBRWxCO0lBQUMsSUFBQSxlQUFJLEVBQUMsOEJBQWMsQ0FBQzs7b0RBQ0Q7QUFFcEI7SUFBQyxJQUFBLGVBQUksRUFBQyw4QkFBYyxDQUFDOztxREFDQztBQUV0QjtJQUFDLElBQUEsZUFBSSxFQUFDLDhCQUFjLENBQUM7O21EQUNEO0FBRXBCO0lBQUMsSUFBQSxlQUFJLEVBQUMsOEJBQWMsQ0FBQzs7NkNBQ1I7QUFFYjtJQUFDLElBQUEsZUFBSSxFQUFDLDhCQUFjLENBQUM7OzZDQUNSO0FBRWI7SUFBQyxJQUFBLGVBQUksRUFBQyw4QkFBYyxDQUFDOzs4Q0FDTjtBQUVmO0lBQUMsSUFBQSxlQUFJLEVBQUMsOEJBQWMsQ0FBQzs7NkNBQ1A7QUFFZDtJQUFDLElBQUEsZUFBSSxFQUFDLDhCQUFjLENBQUM7O29EQUNBO0FBRXJCO0lBQUMsSUFBQSxlQUFJLEVBQUMsOEJBQWMsQ0FBQzs7bURBQ0Q7QUFFcEI7SUFBQyxJQUFBLGVBQUksRUFBQyw4QkFBYyxDQUFDOzs2Q0FDUDtBQUVkO0lBQUMsSUFBQSxlQUFJLEVBQUMsSUFBQSwwQkFBVSxFQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxDQUFDOzs4Q0FDakI7QUFFZjtJQUFDLElBQUEsZUFBSSxFQUFDLElBQUEsMEJBQVUsRUFBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxDQUFDOzsrQ0FDdEI7QUFFaEI7SUFBQyxJQUFBLGVBQUksRUFBQyw4QkFBYyxDQUFDOztxREFDQztBQTVDeEIsMENBNkNDO0FBRUQsTUFBYSx1QkFBdUI7Q0FTbkM7QUFSQztJQUFDLElBQUEsZUFBSSxFQUFDLDhCQUFjLENBQUM7O21EQUNWO0FBRVg7SUFBQyxJQUFBLGVBQUksRUFBQyw4QkFBYyxDQUFDOzs2REFDQTtBQUVyQjtJQUFDLElBQUEsZUFBSSxFQUFDLDhCQUFjLENBQUM7O3FEQUNQO0FBUmhCLDBEQVNDO0FBRUQsTUFBYSw2QkFBOEIsU0FBUSxJQUFBLGtCQUFPLEVBQUMsdUJBQXVCLEVBQUUsQ0FBQyxjQUFjLEVBQUUsTUFBTSxDQUFDLENBQUM7Q0FDNUc7QUFERCxzRUFDQztBQUVELE1BQWEsNkJBQThCLFNBQVEsSUFBQSxrQkFBTyxFQUFDLHVCQUF1QixFQUFFLENBQUMsTUFBTSxDQUFDLENBQUM7Q0FDNUY7QUFERCxzRUFDQztBQUVELE1BQWEscUJBQXNCLFNBQVEsSUFBQSxrQkFBTyxFQUFDLGVBQWUsRUFBRSxDQUFDLElBQUksRUFBRSxjQUFjLENBQUMsQ0FBQztDQUMxRjtBQURELHNEQUNDO0FBRUQsTUFBYSwyQkFBNEIsU0FBUSxJQUFBLGtCQUFPLEVBQUMsZUFBZSxFQUFFLENBQUMsSUFBSSxFQUFFLE9BQU8sRUFBRSxjQUFjLENBQUMsQ0FBQztDQUN6RztBQURELGtFQUNDO0FBRUQsTUFBYSxxQkFBc0IsU0FBUSxJQUFBLGtCQUFPLEVBQUMsZUFBZSxFQUFFLENBQUMsUUFBUSxFQUFFLGNBQWMsQ0FBQyxDQUFDO0NBQzlGO0FBREQsc0RBQ0M7QUFFRCxNQUFhLDJCQUE0QixTQUFRLElBQUEsa0JBQU8sRUFBQyxlQUFlLEVBQUUsQ0FBQyxJQUFJLEVBQUUsUUFBUSxFQUFFLGNBQWMsQ0FBQyxDQUFDO0NBQzFHO0FBREQsa0VBQ0M7QUFFRCxNQUFhLGdDQUFpQyxTQUFRLElBQUEsa0JBQU8sRUFBQyxlQUFlLEVBQUUsQ0FBQyxJQUFJLENBQUMsQ0FBQztDQUdyRjtBQUZDO0lBQUMsSUFBQSxlQUFJLEVBQUMsSUFBQSwwQkFBVSxFQUFDLENBQUMsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLElBQUksQ0FBQyxDQUFDOzsrREFDakI7QUFGaEIsNEVBR0M7QUFFRCxNQUFhLHNCQUF1QixTQUFRLGtCQUFPO0NBZWxEO0FBZEM7SUFBQyxJQUFBLGVBQUksRUFBQyw4QkFBYyxDQUFDOztvREFDUDtBQUVkO0lBQUMsSUFBQSxlQUFJLEVBQUMsOEJBQWMsQ0FBQzs7cURBQ047QUFFZjtJQUFDLElBQUEsZUFBSSxFQUFDLElBQUEsMEJBQVUsRUFBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxDQUFDOztzREFDdEI7QUFFaEI7SUFBQyxJQUFBLGVBQUksRUFBQyw4QkFBYyxDQUFDOzswREFDRDtBQUVwQjtJQUFDLElBQUEsZUFBSSxFQUFDLElBQUEsMEJBQVUsRUFBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQzs7c0RBQ2hCO0FBZGxCLHdEQWVDIn0=