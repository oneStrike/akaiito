import { ListDto } from "../../../shared/dto/base.dto";
export declare class SocialCircleDto {
    id: number;
    creatorId: number;
    creatorName: string;
    classifyName?: string;
    classifyId?: number;
    name: string;
    icon: string;
    cover?: string;
    desc?: string;
    memberTitle?: string;
    vFollowers?: number;
    rule?: string;
    guide?: number;
    status?: number;
    bannedReason?: string;
}
export declare class SocialCircleClassifyDto {
    id: number;
    classifyName: string;
    sort?: number;
}
declare const CreateSocialCircleClassifyDto_base: import("@midwayjs/validate").Dto<Pick<SocialCircleClassifyDto, "sort" | "classifyName">>;
export declare class CreateSocialCircleClassifyDto extends CreateSocialCircleClassifyDto_base {
}
declare const UpdateSocialCircleClassifyDto_base: import("@midwayjs/validate").Dto<Omit<SocialCircleClassifyDto, "sort">>;
export declare class UpdateSocialCircleClassifyDto extends UpdateSocialCircleClassifyDto_base {
}
declare const CreateSocialCircleDto_base: import("@midwayjs/validate").Dto<Omit<SocialCircleDto, "id" | "bannedReason">>;
export declare class CreateSocialCircleDto extends CreateSocialCircleDto_base {
}
declare const CreateClientSocialCircleDto_base: import("@midwayjs/validate").Dto<Omit<SocialCircleDto, "id" | "guide" | "bannedReason">>;
export declare class CreateClientSocialCircleDto extends CreateClientSocialCircleDto_base {
}
declare const UpdateSocialCircleDto_base: import("@midwayjs/validate").Dto<Omit<SocialCircleDto, "status" | "bannedReason">>;
export declare class UpdateSocialCircleDto extends UpdateSocialCircleDto_base {
}
declare const UpdateSocialCircleStatusDto_base: import("@midwayjs/validate").Dto<Pick<SocialCircleDto, "id" | "status" | "bannedReason">>;
export declare class UpdateSocialCircleStatusDto extends UpdateSocialCircleStatusDto_base {
}
declare const UpdateSocialCircleGuideStatusDto_base: import("@midwayjs/validate").Dto<Pick<SocialCircleDto, "id">>;
export declare class UpdateSocialCircleGuideStatusDto extends UpdateSocialCircleGuideStatusDto_base {
    guide: number;
}
export declare class getSocialCirclePageDto extends ListDto {
    name?: string;
    guide?: number;
    status?: number;
    classifyId?: number;
    orphan?: number;
}
export {};
