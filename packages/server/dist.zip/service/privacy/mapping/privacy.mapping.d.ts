import { BaseMapping } from '../../../shared/mapping/base.mapping';
import { PrivacyEntity } from '../entities/privacy.entity';
import { Repository } from 'sequelize-typescript';
export declare class PrivacyMapping extends BaseMapping<PrivacyEntity> {
    protected repository: Repository<PrivacyEntity>;
}
