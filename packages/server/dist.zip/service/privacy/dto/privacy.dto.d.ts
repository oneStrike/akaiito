import { ListDto } from '../../../shared/dto/base.dto';
export declare class PrivacyDto {
    name: string;
    content: string;
    platform: string;
    status?: number;
    remark?: string;
}
export declare class GetPrivacyDto extends ListDto {
    name?: string;
    platform?: string;
    status?: number;
}
export declare class AddPrivacyDto extends PrivacyDto {
}
