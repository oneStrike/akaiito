"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AddPrivacyDto = exports.GetPrivacyDto = exports.PrivacyDto = void 0;
const validate_1 = require("@midwayjs/validate");
const base_validate_1 = require("../../../utils/validate/base.validate");
const base_dto_1 = require("../../../shared/dto/base.dto");
class PrivacyDto {
}
__decorate([
    (0, validate_1.Rule)(base_validate_1.requiredString),
    __metadata("design:type", String)
], PrivacyDto.prototype, "name", void 0);
__decorate([
    (0, validate_1.Rule)(base_validate_1.requiredString),
    __metadata("design:type", String)
], PrivacyDto.prototype, "content", void 0);
__decorate([
    (0, validate_1.Rule)(base_validate_1.requiredString),
    __metadata("design:type", String)
], PrivacyDto.prototype, "platform", void 0);
__decorate([
    (0, validate_1.Rule)((0, base_validate_1.givenValue)([0, 1])),
    __metadata("design:type", Number)
], PrivacyDto.prototype, "status", void 0);
__decorate([
    (0, validate_1.Rule)(base_validate_1.validateString),
    __metadata("design:type", String)
], PrivacyDto.prototype, "remark", void 0);
exports.PrivacyDto = PrivacyDto;
class GetPrivacyDto extends base_dto_1.ListDto {
}
__decorate([
    (0, validate_1.Rule)(base_validate_1.validateString),
    __metadata("design:type", String)
], GetPrivacyDto.prototype, "name", void 0);
__decorate([
    (0, validate_1.Rule)(base_validate_1.validateString),
    __metadata("design:type", String)
], GetPrivacyDto.prototype, "platform", void 0);
__decorate([
    (0, validate_1.Rule)((0, base_validate_1.givenValue)([0, 1], false)),
    __metadata("design:type", Number)
], GetPrivacyDto.prototype, "status", void 0);
exports.GetPrivacyDto = GetPrivacyDto;
class AddPrivacyDto extends PrivacyDto {
}
exports.AddPrivacyDto = AddPrivacyDto;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHJpdmFjeS5kdG8uanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zcmMvc2VydmljZS9wcml2YWN5L2R0by9wcml2YWN5LmR0by50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7QUFBQSxpREFBeUM7QUFDekMseUVBSThDO0FBQzlDLDJEQUFzRDtBQUV0RCxNQUFhLFVBQVU7Q0FldEI7QUFkQztJQUFDLElBQUEsZUFBSSxFQUFDLDhCQUFjLENBQUM7O3dDQUNUO0FBRVo7SUFBQyxJQUFBLGVBQUksRUFBQyw4QkFBYyxDQUFDOzsyQ0FDTjtBQUVmO0lBQUMsSUFBQSxlQUFJLEVBQUMsOEJBQWMsQ0FBQzs7NENBQ0w7QUFFaEI7SUFBQyxJQUFBLGVBQUksRUFBQyxJQUFBLDBCQUFVLEVBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQzs7MENBQ1Y7QUFFZjtJQUFDLElBQUEsZUFBSSxFQUFDLDhCQUFjLENBQUM7OzBDQUNOO0FBZGpCLGdDQWVDO0FBRUQsTUFBYSxhQUFjLFNBQVEsa0JBQU87Q0FTekM7QUFSQztJQUFDLElBQUEsZUFBSSxFQUFDLDhCQUFjLENBQUM7OzJDQUNSO0FBRWI7SUFBQyxJQUFBLGVBQUksRUFBQyw4QkFBYyxDQUFDOzsrQ0FDSjtBQUVqQjtJQUFDLElBQUEsZUFBSSxFQUFDLElBQUEsMEJBQVUsRUFBQyxDQUFDLENBQUMsRUFBRSxDQUFDLENBQUMsRUFBRSxLQUFLLENBQUMsQ0FBQzs7NkNBQ2pCO0FBUmpCLHNDQVNDO0FBRUQsTUFBYSxhQUFjLFNBQVEsVUFBVTtDQUFHO0FBQWhELHNDQUFnRCJ9