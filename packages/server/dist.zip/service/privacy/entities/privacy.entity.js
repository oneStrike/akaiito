"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PrivacyEntity = void 0;
const sequelize_typescript_1 = require("sequelize-typescript");
const basic_entity_1 = require("../../../shared/entities/basic.entity");
let PrivacyEntity = class PrivacyEntity extends basic_entity_1.BaseEntity {
};
__decorate([
    (0, sequelize_typescript_1.Column)({
        type: sequelize_typescript_1.DataType.STRING(20),
        allowNull: false,
        comment: '协议名称'
    }),
    __metadata("design:type", String)
], PrivacyEntity.prototype, "name", void 0);
__decorate([
    (0, sequelize_typescript_1.Column)({
        type: sequelize_typescript_1.DataType.TEXT('medium'),
        allowNull: false,
        comment: '协议内容'
    }),
    __metadata("design:type", String)
], PrivacyEntity.prototype, "content", void 0);
__decorate([
    (0, sequelize_typescript_1.Column)({
        type: sequelize_typescript_1.DataType.STRING(10),
        allowNull: false,
        comment: '平台，可多选 1>APP 2>web 3>小程序'
    }),
    __metadata("design:type", String)
], PrivacyEntity.prototype, "platform", void 0);
__decorate([
    (0, sequelize_typescript_1.Column)({
        type: sequelize_typescript_1.DataType.TINYINT,
        allowNull: false,
        defaultValue: 1,
        comment: '状态 1启用 0 禁用'
    }),
    __metadata("design:type", String)
], PrivacyEntity.prototype, "status", void 0);
__decorate([
    (0, sequelize_typescript_1.Column)({
        type: sequelize_typescript_1.DataType.STRING,
        comment: '备注'
    }),
    __metadata("design:type", String)
], PrivacyEntity.prototype, "remark", void 0);
PrivacyEntity = __decorate([
    (0, sequelize_typescript_1.Table)({
        tableName: 'privacy'
    })
], PrivacyEntity);
exports.PrivacyEntity = PrivacyEntity;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicHJpdmFjeS5lbnRpdHkuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zcmMvc2VydmljZS9wcml2YWN5L2VudGl0aWVzL3ByaXZhY3kuZW50aXR5LnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7OztBQUFBLCtEQUE4RDtBQUM5RCx3RUFBa0U7QUFLM0QsSUFBTSxhQUFhLEdBQW5CLE1BQU0sYUFBYyxTQUFRLHlCQUFVO0NBbUM1QyxDQUFBO0FBbENDO0lBQUMsSUFBQSw2QkFBTSxFQUFDO1FBQ04sSUFBSSxFQUFFLCtCQUFRLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQztRQUN6QixTQUFTLEVBQUUsS0FBSztRQUNoQixPQUFPLEVBQUUsTUFBTTtLQUNoQixDQUFDOzsyQ0FDVTtBQUVaO0lBQUMsSUFBQSw2QkFBTSxFQUFDO1FBQ04sSUFBSSxFQUFFLCtCQUFRLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQztRQUM3QixTQUFTLEVBQUUsS0FBSztRQUNoQixPQUFPLEVBQUUsTUFBTTtLQUNoQixDQUFDOzs4Q0FDYTtBQUVmO0lBQUMsSUFBQSw2QkFBTSxFQUFDO1FBQ04sSUFBSSxFQUFFLCtCQUFRLENBQUMsTUFBTSxDQUFDLEVBQUUsQ0FBQztRQUN6QixTQUFTLEVBQUUsS0FBSztRQUNoQixPQUFPLEVBQUUsMEJBQTBCO0tBQ3BDLENBQUM7OytDQUNjO0FBRWhCO0lBQUMsSUFBQSw2QkFBTSxFQUFDO1FBQ04sSUFBSSxFQUFFLCtCQUFRLENBQUMsT0FBTztRQUN0QixTQUFTLEVBQUUsS0FBSztRQUNoQixZQUFZLEVBQUUsQ0FBQztRQUNmLE9BQU8sRUFBRSxhQUFhO0tBQ3ZCLENBQUM7OzZDQUNZO0FBRWQ7SUFBQyxJQUFBLDZCQUFNLEVBQUM7UUFDTixJQUFJLEVBQUUsK0JBQVEsQ0FBQyxNQUFNO1FBQ3JCLE9BQU8sRUFBRSxJQUFJO0tBQ2QsQ0FBQzs7NkNBQ1k7QUFsQ0gsYUFBYTtJQUh6QixJQUFBLDRCQUFLLEVBQUM7UUFDTCxTQUFTLEVBQUUsU0FBUztLQUNyQixDQUFDO0dBQ1csYUFBYSxDQW1DekI7QUFuQ1ksc0NBQWEifQ==