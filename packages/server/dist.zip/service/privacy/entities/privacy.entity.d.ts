import { BaseEntity } from '../../../shared/entities/basic.entity';
export declare class PrivacyEntity extends BaseEntity {
    name: string;
    content: string;
    platform: string;
    status: string;
    remark: string;
}
