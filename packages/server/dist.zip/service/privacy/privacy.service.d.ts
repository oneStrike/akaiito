import { BaseService } from '../../shared/service/base.service';
import { PrivacyMapping } from './mapping/privacy.mapping';
export declare class PrivacyService extends BaseService {
    mapping: PrivacyMapping;
    getPrivacyList(params: any): Promise<import("../../types/dto/list").ListResponseRes<import("sequelize-typescript").Model<any, any>>>;
}
