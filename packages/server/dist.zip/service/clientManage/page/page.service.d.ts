import { BaseService } from '../../../shared/service/base.service';
import { PageMapping } from './mapping/page.mapping';
export declare class PageService extends BaseService {
    mapping: PageMapping;
    createClientPage(): Promise<import("./entities/page.entity").ClientPageEntity[]>;
}
