export declare class PageDto {
    id: number;
    pageName: string;
    pagePath: string;
    pageTitle: string;
    role: string;
    vipLevel?: number;
    status: number;
}
export declare class updatePageDto extends PageDto {
}
