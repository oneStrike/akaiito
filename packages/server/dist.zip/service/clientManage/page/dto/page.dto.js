"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.updatePageDto = exports.PageDto = void 0;
const validate_1 = require("@midwayjs/validate");
const base_validate_1 = require("../../../../utils/validate/base.validate");
class PageDto {
}
__decorate([
    (0, validate_1.Rule)(base_validate_1.requiredNumber),
    __metadata("design:type", Number)
], PageDto.prototype, "id", void 0);
__decorate([
    (0, validate_1.Rule)(base_validate_1.requiredString),
    __metadata("design:type", String)
], PageDto.prototype, "pageName", void 0);
__decorate([
    (0, validate_1.Rule)(base_validate_1.requiredString),
    __metadata("design:type", String)
], PageDto.prototype, "pagePath", void 0);
__decorate([
    (0, validate_1.Rule)(base_validate_1.requiredString),
    __metadata("design:type", String)
], PageDto.prototype, "pageTitle", void 0);
__decorate([
    (0, validate_1.Rule)((0, base_validate_1.givenValue)(['normal', 'vip', 'vipLevel'])),
    __metadata("design:type", String)
], PageDto.prototype, "role", void 0);
__decorate([
    (0, validate_1.Rule)(base_validate_1.validateNumber),
    __metadata("design:type", Number)
], PageDto.prototype, "vipLevel", void 0);
__decorate([
    (0, validate_1.Rule)((0, base_validate_1.givenValue)([1, 2, 3])),
    __metadata("design:type", Number)
], PageDto.prototype, "status", void 0);
exports.PageDto = PageDto;
class updatePageDto extends PageDto {
}
exports.updatePageDto = updatePageDto;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGFnZS5kdG8uanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zcmMvc2VydmljZS9jbGllbnRNYW5hZ2UvcGFnZS9kdG8vcGFnZS5kdG8udHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7O0FBQUEsaURBQXlDO0FBQ3pDLDRFQUtpRDtBQUVqRCxNQUFhLE9BQU87Q0FxQm5CO0FBcEJDO0lBQUMsSUFBQSxlQUFJLEVBQUMsOEJBQWMsQ0FBQzs7bUNBQ1g7QUFFVjtJQUFDLElBQUEsZUFBSSxFQUFDLDhCQUFjLENBQUM7O3lDQUNKO0FBRWpCO0lBQUMsSUFBQSxlQUFJLEVBQUMsOEJBQWMsQ0FBQzs7eUNBQ0w7QUFFaEI7SUFBQyxJQUFBLGVBQUksRUFBQyw4QkFBYyxDQUFDOzswQ0FDSjtBQUVqQjtJQUFDLElBQUEsZUFBSSxFQUFDLElBQUEsMEJBQVUsRUFBQyxDQUFDLFFBQVEsRUFBRSxLQUFLLEVBQUUsVUFBVSxDQUFDLENBQUMsQ0FBQzs7cUNBQ3BDO0FBRVo7SUFBQyxJQUFBLGVBQUksRUFBQyw4QkFBYyxDQUFDOzt5Q0FDSjtBQUVqQjtJQUFDLElBQUEsZUFBSSxFQUFDLElBQUEsMEJBQVUsRUFBQyxDQUFDLENBQUMsRUFBRSxDQUFDLEVBQUUsQ0FBQyxDQUFDLENBQUMsQ0FBQzs7dUNBQ2Q7QUFwQmhCLDBCQXFCQztBQUVELE1BQWEsYUFBYyxTQUFRLE9BQU87Q0FBRztBQUE3QyxzQ0FBNkMifQ==