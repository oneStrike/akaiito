"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.PageMapping = void 0;
const base_mapping_1 = require("../../../../shared/mapping/base.mapping");
const page_entity_1 = require("../entities/page.entity");
const sequelize_1 = require("@midwayjs/sequelize");
const core_1 = require("@midwayjs/core");
let PageMapping = class PageMapping extends base_mapping_1.BaseMapping {
    constructor() {
        super(...arguments);
        this.pageList = [
            {
                pageName: '首页',
                pagePath: '/pages/tabBar/home/home',
                pageTitle: '首页',
                role: 'normal',
                status: 1
            },
            {
                pageName: '用户中心',
                pagePath: '/pages/tabBar/profile/profile',
                pageTitle: '用户中心',
                role: 'normal',
                status: 1
            },
            {
                pageName: '会员中心',
                pagePath: '/pages/memberCenter/memberCenter',
                pageTitle: '会员中心',
                role: 'normal',
                status: 1
            },
            {
                pageName: '搜索',
                pagePath: '/pages/search/search',
                pageTitle: '搜索',
                role: 'normal',
                status: 1
            },
            {
                pageName: '扫码',
                pagePath: '/pages/scanCode/scanCode',
                pageTitle: '扫码',
                role: 'normal',
                status: 1
            },
            {
                pageName: '设置',
                pagePath: '/pages/setting/setting',
                pageTitle: '设置',
                role: 'normal',
                status: 1
            },
            {
                pageName: '用户隐私协议',
                pagePath: '/pages/agreement/agreement',
                pageTitle: '用户隐私协议',
                role: 'normal',
                status: 1
            },
            {
                pageName: 'H5',
                pagePath: '/pages/webview/webview',
                pageTitle: 'H5',
                role: 'normal',
                status: 1
            }
        ];
    }
    async createPage() {
        await this.clearTable();
        return await this.bulkCreate(this.pageList);
    }
};
__decorate([
    (0, sequelize_1.InjectRepository)(page_entity_1.ClientPageEntity),
    __metadata("design:type", Object)
], PageMapping.prototype, "repository", void 0);
PageMapping = __decorate([
    (0, core_1.Provide)()
], PageMapping);
exports.PageMapping = PageMapping;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGFnZS5tYXBwaW5nLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vLi4vLi4vc3JjL3NlcnZpY2UvY2xpZW50TWFuYWdlL3BhZ2UvbWFwcGluZy9wYWdlLm1hcHBpbmcudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7O0FBQUEsMEVBQXFFO0FBQ3JFLHlEQUEwRDtBQUUxRCxtREFBc0Q7QUFFdEQseUNBQXdDO0FBR2pDLElBQU0sV0FBVyxHQUFqQixNQUFNLFdBQVksU0FBUSwwQkFBNkI7SUFBdkQ7O1FBSUwsYUFBUSxHQUEwQjtZQUNoQztnQkFDRSxRQUFRLEVBQUUsSUFBSTtnQkFDZCxRQUFRLEVBQUUseUJBQXlCO2dCQUNuQyxTQUFTLEVBQUUsSUFBSTtnQkFDZixJQUFJLEVBQUUsUUFBUTtnQkFDZCxNQUFNLEVBQUUsQ0FBQzthQUNWO1lBQ0Q7Z0JBQ0UsUUFBUSxFQUFFLE1BQU07Z0JBQ2hCLFFBQVEsRUFBRSwrQkFBK0I7Z0JBQ3pDLFNBQVMsRUFBRSxNQUFNO2dCQUNqQixJQUFJLEVBQUUsUUFBUTtnQkFDZCxNQUFNLEVBQUUsQ0FBQzthQUNWO1lBQ0Q7Z0JBQ0UsUUFBUSxFQUFFLE1BQU07Z0JBQ2hCLFFBQVEsRUFBRSxrQ0FBa0M7Z0JBQzVDLFNBQVMsRUFBRSxNQUFNO2dCQUNqQixJQUFJLEVBQUUsUUFBUTtnQkFDZCxNQUFNLEVBQUUsQ0FBQzthQUNWO1lBQ0Q7Z0JBQ0UsUUFBUSxFQUFFLElBQUk7Z0JBQ2QsUUFBUSxFQUFFLHNCQUFzQjtnQkFDaEMsU0FBUyxFQUFFLElBQUk7Z0JBQ2YsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsTUFBTSxFQUFFLENBQUM7YUFDVjtZQUNEO2dCQUNFLFFBQVEsRUFBRSxJQUFJO2dCQUNkLFFBQVEsRUFBRSwwQkFBMEI7Z0JBQ3BDLFNBQVMsRUFBRSxJQUFJO2dCQUNmLElBQUksRUFBRSxRQUFRO2dCQUNkLE1BQU0sRUFBRSxDQUFDO2FBQ1Y7WUFDRDtnQkFDRSxRQUFRLEVBQUUsSUFBSTtnQkFDZCxRQUFRLEVBQUUsd0JBQXdCO2dCQUNsQyxTQUFTLEVBQUUsSUFBSTtnQkFDZixJQUFJLEVBQUUsUUFBUTtnQkFDZCxNQUFNLEVBQUUsQ0FBQzthQUNWO1lBQ0Q7Z0JBQ0UsUUFBUSxFQUFFLFFBQVE7Z0JBQ2xCLFFBQVEsRUFBRSw0QkFBNEI7Z0JBQ3RDLFNBQVMsRUFBRSxRQUFRO2dCQUNuQixJQUFJLEVBQUUsUUFBUTtnQkFDZCxNQUFNLEVBQUUsQ0FBQzthQUNWO1lBQ0Q7Z0JBQ0UsUUFBUSxFQUFFLElBQUk7Z0JBQ2QsUUFBUSxFQUFFLHdCQUF3QjtnQkFDbEMsU0FBUyxFQUFFLElBQUk7Z0JBQ2YsSUFBSSxFQUFFLFFBQVE7Z0JBQ2QsTUFBTSxFQUFFLENBQUM7YUFDVjtTQUNGLENBQUE7SUFNSCxDQUFDO0lBSkMsS0FBSyxDQUFDLFVBQVU7UUFDZCxNQUFNLElBQUksQ0FBQyxVQUFVLEVBQUUsQ0FBQTtRQUN2QixPQUFPLE1BQU0sSUFBSSxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUE7SUFDN0MsQ0FBQztDQUNGLENBQUE7QUFsRUM7SUFBQyxJQUFBLDRCQUFnQixFQUFDLDhCQUFnQixDQUFDOzsrQ0FDZTtBQUZ2QyxXQUFXO0lBRHZCLElBQUEsY0FBTyxHQUFFO0dBQ0csV0FBVyxDQW1FdkI7QUFuRVksa0NBQVcifQ==