import { BaseMapping } from '../../../../shared/mapping/base.mapping';
import { ClientPageEntity } from '../entities/page.entity';
import { Repository } from 'sequelize-typescript';
import { PageDto } from '../dto/page.dto';
export declare class PageMapping extends BaseMapping<ClientPageEntity> {
    protected repository: Repository<ClientPageEntity>;
    pageList: Omit<PageDto, 'id'>[];
    createPage(): Promise<ClientPageEntity[]>;
}
