"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ClientPageEntity = void 0;
const sequelize_typescript_1 = require("sequelize-typescript");
const basic_entity_1 = require("../../../../shared/entities/basic.entity");
let ClientPageEntity = class ClientPageEntity extends basic_entity_1.BaseEntity {
};
__decorate([
    (0, sequelize_typescript_1.Column)({
        type: sequelize_typescript_1.DataType.STRING(50),
        allowNull: false,
        comment: '页面名称'
    }),
    __metadata("design:type", String)
], ClientPageEntity.prototype, "pageName", void 0);
__decorate([
    (0, sequelize_typescript_1.Column)({
        type: sequelize_typescript_1.DataType.STRING(100),
        allowNull: false,
        comment: '页面路径'
    }),
    __metadata("design:type", String)
], ClientPageEntity.prototype, "pagePath", void 0);
__decorate([
    (0, sequelize_typescript_1.Column)({
        type: sequelize_typescript_1.DataType.STRING(50),
        allowNull: false,
        comment: '页面标题'
    }),
    __metadata("design:type", String)
], ClientPageEntity.prototype, "pageTitle", void 0);
__decorate([
    (0, sequelize_typescript_1.Column)({
        type: sequelize_typescript_1.DataType.STRING(10),
        allowNull: false,
        comment: '页面权限',
        defaultValue: 'normal'
    }),
    __metadata("design:type", String)
], ClientPageEntity.prototype, "role", void 0);
__decorate([
    (0, sequelize_typescript_1.Column)({
        type: sequelize_typescript_1.DataType.INTEGER,
        comment: '会员登记访问，等级不到不允许访问'
    }),
    __metadata("design:type", Number)
], ClientPageEntity.prototype, "vipLevel", void 0);
__decorate([
    (0, sequelize_typescript_1.Column)({
        type: sequelize_typescript_1.DataType.INTEGER,
        defaultValue: 1,
        comment: '页面状态1启用，2禁用，3开发中'
    }),
    __metadata("design:type", Number)
], ClientPageEntity.prototype, "status", void 0);
ClientPageEntity = __decorate([
    (0, sequelize_typescript_1.Table)({
        tableName: 'client_manage_page'
    })
], ClientPageEntity);
exports.ClientPageEntity = ClientPageEntity;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicGFnZS5lbnRpdHkuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi8uLi9zcmMvc2VydmljZS9jbGllbnRNYW5hZ2UvcGFnZS9lbnRpdGllcy9wYWdlLmVudGl0eS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7QUFBQSwrREFBOEQ7QUFDOUQsMkVBQXFFO0FBSzlELElBQU0sZ0JBQWdCLEdBQXRCLE1BQU0sZ0JBQWlCLFNBQVEseUJBQVU7Q0EwQy9DLENBQUE7QUF6Q0M7SUFBQyxJQUFBLDZCQUFNLEVBQUM7UUFDTixJQUFJLEVBQUUsK0JBQVEsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDO1FBQ3pCLFNBQVMsRUFBRSxLQUFLO1FBQ2hCLE9BQU8sRUFBRSxNQUFNO0tBQ2hCLENBQUM7O2tEQUNjO0FBRWhCO0lBQUMsSUFBQSw2QkFBTSxFQUFDO1FBQ04sSUFBSSxFQUFFLCtCQUFRLENBQUMsTUFBTSxDQUFDLEdBQUcsQ0FBQztRQUMxQixTQUFTLEVBQUUsS0FBSztRQUNoQixPQUFPLEVBQUUsTUFBTTtLQUNoQixDQUFDOztrREFDYztBQUVoQjtJQUFDLElBQUEsNkJBQU0sRUFBQztRQUNOLElBQUksRUFBRSwrQkFBUSxDQUFDLE1BQU0sQ0FBQyxFQUFFLENBQUM7UUFDekIsU0FBUyxFQUFFLEtBQUs7UUFDaEIsT0FBTyxFQUFFLE1BQU07S0FDaEIsQ0FBQzs7bURBQ2U7QUFFakI7SUFBQyxJQUFBLDZCQUFNLEVBQUM7UUFDTixJQUFJLEVBQUUsK0JBQVEsQ0FBQyxNQUFNLENBQUMsRUFBRSxDQUFDO1FBQ3pCLFNBQVMsRUFBRSxLQUFLO1FBQ2hCLE9BQU8sRUFBRSxNQUFNO1FBQ2YsWUFBWSxFQUFFLFFBQVE7S0FDdkIsQ0FBQzs7OENBQ1U7QUFFWjtJQUFDLElBQUEsNkJBQU0sRUFBQztRQUNOLElBQUksRUFBRSwrQkFBUSxDQUFDLE9BQU87UUFDdEIsT0FBTyxFQUFFLGtCQUFrQjtLQUM1QixDQUFDOztrREFDYztBQUVoQjtJQUFDLElBQUEsNkJBQU0sRUFBQztRQUNOLElBQUksRUFBRSwrQkFBUSxDQUFDLE9BQU87UUFDdEIsWUFBWSxFQUFFLENBQUM7UUFDZixPQUFPLEVBQUUsa0JBQWtCO0tBQzVCLENBQUM7O2dEQUNZO0FBekNILGdCQUFnQjtJQUg1QixJQUFBLDRCQUFLLEVBQUM7UUFDTCxTQUFTLEVBQUUsb0JBQW9CO0tBQ2hDLENBQUM7R0FDVyxnQkFBZ0IsQ0EwQzVCO0FBMUNZLDRDQUFnQiJ9