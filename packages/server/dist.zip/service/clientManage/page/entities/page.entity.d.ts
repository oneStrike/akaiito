import { BaseEntity } from '../../../../shared/entities/basic.entity';
export declare class ClientPageEntity extends BaseEntity {
    pageName: string;
    pagePath: string;
    pageTitle: string;
    role: string;
    vipLevel: number;
    status: number;
}
