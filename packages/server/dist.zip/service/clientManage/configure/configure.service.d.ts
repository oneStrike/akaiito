import { BaseService } from "../../../shared/service/base.service";
import { BaseMapping } from "../../../shared/mapping/base.mapping";
import { ClientConfigureDto } from "./dto/configure.dto";
import { Application } from "@midwayjs/koa";
export declare class ConfigureService extends BaseService {
    protected mapping: BaseMapping;
    staticService: Record<string | symbol, any>;
    app: Application;
    uploadConfigure(configure: ClientConfigureDto): Promise<any>;
    getConfigure(): Promise<{
        privacyTitle: any;
        privacyMessage: any;
        privacySecondTitle: any;
        privacySecondMessage: any;
    }>;
    exportClientPackage(): Promise<string>;
    getClientPackagePath(): string;
    getPrivacyContent(): any;
}
