export declare class ClientConfigureDto {
    privacyTitle: string;
    privacyMessage: string;
    privacySecondTitle: string;
    privacySecondMessage: string;
}
