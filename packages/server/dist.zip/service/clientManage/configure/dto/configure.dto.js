"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ClientConfigureDto = void 0;
const validate_1 = require("@midwayjs/validate");
const base_validate_1 = require("../../../../utils/validate/base.validate");
class ClientConfigureDto {
}
__decorate([
    (0, validate_1.Rule)(base_validate_1.requiredString),
    __metadata("design:type", String)
], ClientConfigureDto.prototype, "privacyTitle", void 0);
__decorate([
    (0, validate_1.Rule)(base_validate_1.requiredString),
    __metadata("design:type", String)
], ClientConfigureDto.prototype, "privacyMessage", void 0);
__decorate([
    (0, validate_1.Rule)(base_validate_1.requiredString),
    __metadata("design:type", String)
], ClientConfigureDto.prototype, "privacySecondTitle", void 0);
__decorate([
    (0, validate_1.Rule)(base_validate_1.requiredString),
    __metadata("design:type", String)
], ClientConfigureDto.prototype, "privacySecondMessage", void 0);
exports.ClientConfigureDto = ClientConfigureDto;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29uZmlndXJlLmR0by5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uLy4uLy4uLy4uL3NyYy9zZXJ2aWNlL2NsaWVudE1hbmFnZS9jb25maWd1cmUvZHRvL2NvbmZpZ3VyZS5kdG8udHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7O0FBQUEsaURBQXlDO0FBQ3pDLDRFQUF5RTtBQUV6RSxNQUFhLGtCQUFrQjtDQVk5QjtBQVhDO0lBQUMsSUFBQSxlQUFJLEVBQUMsOEJBQWMsQ0FBQzs7d0RBQ0Q7QUFFcEI7SUFBQyxJQUFBLGVBQUksRUFBQyw4QkFBYyxDQUFDOzswREFDQztBQUV0QjtJQUFDLElBQUEsZUFBSSxFQUFDLDhCQUFjLENBQUM7OzhEQUNLO0FBRTFCO0lBQUMsSUFBQSxlQUFJLEVBQUMsOEJBQWMsQ0FBQzs7Z0VBQ087QUFYOUIsZ0RBWUMifQ==