"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ConfigureService = void 0;
const base_service_1 = require("../../../shared/service/base.service");
const core_1 = require("@midwayjs/core");
const fs = require("fs");
const archiver = require("archiver");
let ConfigureService = class ConfigureService extends base_service_1.BaseService {
    //修改客户端系统配置信息
    async uploadConfigure(configure) {
        const privacy = this.getPrivacyContent();
        const { privacyTitle, privacyMessage, privacySecondTitle, privacySecondMessage } = configure;
        privacy.title = privacyTitle;
        privacy.message = privacyMessage;
        privacy.second.title = privacySecondTitle;
        privacy.second.message = privacySecondMessage;
        try {
            const privacyPath = this.getClientPackagePath() + "/src/androidPrivacy.json";
            fs.writeFileSync(privacyPath, JSON.stringify(privacy, null, 2), "utf8");
            return privacy;
        }
        catch (error) {
            this.normalError("更新失败");
        }
    }
    //获取客户端系统配置信息
    async getConfigure() {
        const { title, message, second } = this.getPrivacyContent();
        return {
            privacyTitle: title,
            privacyMessage: message,
            privacySecondTitle: second.title,
            privacySecondMessage: second.message
        };
    }
    //导出客户端代码包
    async exportClientPackage() {
        return new Promise((resolve) => {
            const sourceFile = this.app.getAppDir() + "/public/clientPackage.zip";
            const output = fs.createWriteStream(sourceFile);
            const archive = archiver("zip", {
                zlib: { level: 9 }
            });
            archive.pipe(output);
            archive.directory("../client", false);
            archive.finalize();
            output.on("close", function () {
                resolve(sourceFile);
            });
        });
    }
    //获取客户端包路径地址
    getClientPackagePath() {
        if (this.app.getEnv().includes("prod")) {
            return this.app.getAppDir() + "/public/clientPackage";
        }
        return this.app.getAppDir().replace("server", "client");
    }
    //获取客户端隐私协议json文件
    getPrivacyContent() {
        return require(this.getClientPackagePath() + "/src/androidPrivacy.json");
    }
};
__decorate([
    (0, core_1.Config)("static"),
    __metadata("design:type", Object)
], ConfigureService.prototype, "staticService", void 0);
__decorate([
    (0, core_1.App)(),
    __metadata("design:type", Object)
], ConfigureService.prototype, "app", void 0);
ConfigureService = __decorate([
    (0, core_1.Provide)()
], ConfigureService);
exports.ConfigureService = ConfigureService;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29uZmlndXJlLnNlcnZpY2UuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi8uLi9zcmMvc2VydmljZS9jbGllbnRNYW5hZ2UvY29uZmlndXJlL2NvbmZpZ3VyZS5zZXJ2aWNlLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7OztBQUFBLHVFQUFtRTtBQUNuRSx5Q0FBc0Q7QUFJdEQseUJBQXlCO0FBRXpCLE1BQU0sUUFBUSxHQUFHLE9BQU8sQ0FBQyxVQUFVLENBQUMsQ0FBQztBQUc5QixJQUFNLGdCQUFnQixHQUF0QixNQUFNLGdCQUFpQixTQUFRLDBCQUFXO0lBUy9DLGFBQWE7SUFDYixLQUFLLENBQUMsZUFBZSxDQUFDLFNBQTZCO1FBQ2pELE1BQU0sT0FBTyxHQUFHLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO1FBQ3pDLE1BQU0sRUFBRSxZQUFZLEVBQUUsY0FBYyxFQUFFLGtCQUFrQixFQUFFLG9CQUFvQixFQUFFLEdBQUcsU0FBUyxDQUFDO1FBQzdGLE9BQU8sQ0FBQyxLQUFLLEdBQUcsWUFBWSxDQUFDO1FBQzdCLE9BQU8sQ0FBQyxPQUFPLEdBQUcsY0FBYyxDQUFDO1FBQ2pDLE9BQU8sQ0FBQyxNQUFNLENBQUMsS0FBSyxHQUFHLGtCQUFrQixDQUFDO1FBQzFDLE9BQU8sQ0FBQyxNQUFNLENBQUMsT0FBTyxHQUFHLG9CQUFvQixDQUFDO1FBRTlDLElBQUk7WUFDRixNQUFNLFdBQVcsR0FBRyxJQUFJLENBQUMsb0JBQW9CLEVBQUUsR0FBRywwQkFBMEIsQ0FBQztZQUM3RSxFQUFFLENBQUMsYUFBYSxDQUFDLFdBQVcsRUFBRSxJQUFJLENBQUMsU0FBUyxDQUFDLE9BQU8sRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFDLEVBQUUsTUFBTSxDQUFDLENBQUM7WUFDeEUsT0FBTyxPQUFPLENBQUM7U0FDaEI7UUFBQyxPQUFPLEtBQUssRUFBRTtZQUNkLElBQUksQ0FBQyxXQUFXLENBQUMsTUFBTSxDQUFDLENBQUM7U0FDMUI7SUFDSCxDQUFDO0lBRUQsYUFBYTtJQUNiLEtBQUssQ0FBQyxZQUFZO1FBQ2hCLE1BQU0sRUFBRSxLQUFLLEVBQUUsT0FBTyxFQUFFLE1BQU0sRUFBRSxHQUFHLElBQUksQ0FBQyxpQkFBaUIsRUFBRSxDQUFDO1FBQzVELE9BQU87WUFDTCxZQUFZLEVBQUUsS0FBSztZQUNuQixjQUFjLEVBQUUsT0FBTztZQUN2QixrQkFBa0IsRUFBRSxNQUFNLENBQUMsS0FBSztZQUNoQyxvQkFBb0IsRUFBRSxNQUFNLENBQUMsT0FBTztTQUNyQyxDQUFDO0lBQ0osQ0FBQztJQUVELFVBQVU7SUFDVixLQUFLLENBQUMsbUJBQW1CO1FBQ3ZCLE9BQU8sSUFBSSxPQUFPLENBQUMsQ0FBQyxPQUFPLEVBQUUsRUFBRTtZQUM3QixNQUFNLFVBQVUsR0FBRyxJQUFJLENBQUMsR0FBRyxDQUFDLFNBQVMsRUFBRSxHQUFHLDJCQUEyQixDQUFDO1lBQ3RFLE1BQU0sTUFBTSxHQUFHLEVBQUUsQ0FBQyxpQkFBaUIsQ0FBQyxVQUFVLENBQUMsQ0FBQztZQUNoRCxNQUFNLE9BQU8sR0FBRyxRQUFRLENBQUMsS0FBSyxFQUFFO2dCQUM5QixJQUFJLEVBQUUsRUFBRSxLQUFLLEVBQUUsQ0FBQyxFQUFFO2FBQ25CLENBQUMsQ0FBQztZQUNILE9BQU8sQ0FBQyxJQUFJLENBQUMsTUFBTSxDQUFDLENBQUM7WUFDckIsT0FBTyxDQUFDLFNBQVMsQ0FBQyxXQUFXLEVBQUUsS0FBSyxDQUFDLENBQUM7WUFDdEMsT0FBTyxDQUFDLFFBQVEsRUFBRSxDQUFDO1lBQ25CLE1BQU0sQ0FBQyxFQUFFLENBQUMsT0FBTyxFQUFFO2dCQUNqQixPQUFPLENBQUMsVUFBVSxDQUFDLENBQUM7WUFDdEIsQ0FBQyxDQUFDLENBQUM7UUFDTCxDQUFDLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRCxZQUFZO0lBQ1osb0JBQW9CO1FBQ2xCLElBQUksSUFBSSxDQUFDLEdBQUcsQ0FBQyxNQUFNLEVBQUUsQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLEVBQUU7WUFDdEMsT0FBTyxJQUFJLENBQUMsR0FBRyxDQUFDLFNBQVMsRUFBRSxHQUFHLHVCQUF1QixDQUFDO1NBQ3ZEO1FBQ0QsT0FBTyxJQUFJLENBQUMsR0FBRyxDQUFDLFNBQVMsRUFBRSxDQUFDLE9BQU8sQ0FBQyxRQUFRLEVBQUUsUUFBUSxDQUFDLENBQUM7SUFFMUQsQ0FBQztJQUVELGlCQUFpQjtJQUNqQixpQkFBaUI7UUFDZixPQUFPLE9BQU8sQ0FBQyxJQUFJLENBQUMsb0JBQW9CLEVBQUUsR0FBRywwQkFBMEIsQ0FBQyxDQUFDO0lBQzNFLENBQUM7Q0FDRixDQUFBO0FBakVDO0lBQUMsSUFBQSxhQUFNLEVBQUMsUUFBUSxDQUFDOzt1REFDMkI7QUFFNUM7SUFBQyxJQUFBLFVBQUcsR0FBRTs7NkNBQ1c7QUFQTixnQkFBZ0I7SUFENUIsSUFBQSxjQUFPLEdBQUU7R0FDRyxnQkFBZ0IsQ0FvRTVCO0FBcEVZLDRDQUFnQiJ9