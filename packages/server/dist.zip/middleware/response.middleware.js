"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ResponseMiddleware = void 0;
const core_1 = require("@midwayjs/core");
const log_service_1 = require("../service/admin/log/log.service");
let ResponseMiddleware = class ResponseMiddleware {
    resolve() {
        return async (ctx, next) => {
            const result = await next();
            const responseRes = {
                code: 1,
                status: "success",
                data: result
            };
            ctx.setAttr("responseRes", responseRes);
            const baseSysLogService = await ctx.requestContext.getAsync(log_service_1.LogService);
            await baseSysLogService.record(ctx);
            if (result === null)
                ctx.status = 200;
            return ctx.response.headers["content-type"] === "application/octet-stream" ? result : responseRes;
        };
    }
};
ResponseMiddleware = __decorate([
    (0, core_1.Middleware)()
], ResponseMiddleware);
exports.ResponseMiddleware = ResponseMiddleware;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoicmVzcG9uc2UubWlkZGxld2FyZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9taWRkbGV3YXJlL3Jlc3BvbnNlLm1pZGRsZXdhcmUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7O0FBQUEseUNBQXlEO0FBR3pELGtFQUE4RDtBQUd2RCxJQUFNLGtCQUFrQixHQUF4QixNQUFNLGtCQUFrQjtJQUM3QixPQUFPO1FBQ0wsT0FBTyxLQUFLLEVBQUUsR0FBWSxFQUFFLElBQWtCLEVBQUUsRUFBRTtZQUNoRCxNQUFNLE1BQU0sR0FBRyxNQUFNLElBQUksRUFBRSxDQUFDO1lBQzVCLE1BQU0sV0FBVyxHQUFrQjtnQkFDakMsSUFBSSxFQUFFLENBQUM7Z0JBQ1AsTUFBTSxFQUFFLFNBQVM7Z0JBQ2pCLElBQUksRUFBRSxNQUFNO2FBQ2IsQ0FBQztZQUNGLEdBQUcsQ0FBQyxPQUFPLENBQUMsYUFBYSxFQUFFLFdBQVcsQ0FBQyxDQUFDO1lBQ3hDLE1BQU0saUJBQWlCLEdBQUcsTUFBTSxHQUFHLENBQUMsY0FBYyxDQUFDLFFBQVEsQ0FBQyx3QkFBVSxDQUFDLENBQUM7WUFDeEUsTUFBTSxpQkFBaUIsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDcEMsSUFBSSxNQUFNLEtBQUssSUFBSTtnQkFBRSxHQUFHLENBQUMsTUFBTSxHQUFHLEdBQUcsQ0FBQztZQUN0QyxPQUFPLEdBQUcsQ0FBQyxRQUFRLENBQUMsT0FBTyxDQUFDLGNBQWMsQ0FBQyxLQUFLLDBCQUEwQixDQUFDLENBQUMsQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLFdBQVcsQ0FBQztRQUNwRyxDQUFDLENBQUM7SUFDSixDQUFDO0NBQ0YsQ0FBQTtBQWhCWSxrQkFBa0I7SUFEOUIsSUFBQSxpQkFBVSxHQUFFO0dBQ0Esa0JBQWtCLENBZ0I5QjtBQWhCWSxnREFBa0IifQ==