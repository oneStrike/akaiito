"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.SerializeMiddleware = void 0;
const core_1 = require("@midwayjs/core");
/**
 * 净化入参，只保留有效值
 */
let SerializeMiddleware = class SerializeMiddleware {
    resolve() {
        return async (ctx, next) => {
            const query = ctx.request.query;
            if (ctx.method === 'GET' && query) {
                const pureQuery = {};
                for (const queryKey in query) {
                    const item = query[queryKey];
                    if (item)
                        pureQuery[queryKey] = item;
                }
                ctx.request.query = pureQuery;
            }
            await next();
        };
    }
};
SerializeMiddleware = __decorate([
    (0, core_1.Middleware)()
], SerializeMiddleware);
exports.SerializeMiddleware = SerializeMiddleware;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VyaWFsaXplLm1pZGRsZXdhcmUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi9zcmMvbWlkZGxld2FyZS9zZXJpYWxpemUubWlkZGxld2FyZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7QUFBQSx5Q0FBd0Q7QUFHeEQ7O0dBRUc7QUFFSSxJQUFNLG1CQUFtQixHQUF6QixNQUFNLG1CQUFtQjtJQUM5QixPQUFPO1FBQ0wsT0FBTyxLQUFLLEVBQUUsR0FBWSxFQUFFLElBQWtCLEVBQUUsRUFBRTtZQUNoRCxNQUFNLEtBQUssR0FBRyxHQUFHLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQTtZQUMvQixJQUFJLEdBQUcsQ0FBQyxNQUFNLEtBQUssS0FBSyxJQUFJLEtBQUssRUFBRTtnQkFDakMsTUFBTSxTQUFTLEdBQUcsRUFBRSxDQUFBO2dCQUNwQixLQUFLLE1BQU0sUUFBUSxJQUFJLEtBQUssRUFBRTtvQkFDNUIsTUFBTSxJQUFJLEdBQUcsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFBO29CQUM1QixJQUFJLElBQUk7d0JBQUUsU0FBUyxDQUFDLFFBQVEsQ0FBQyxHQUFHLElBQUksQ0FBQTtpQkFDckM7Z0JBQ0QsR0FBRyxDQUFDLE9BQU8sQ0FBQyxLQUFLLEdBQUcsU0FBUyxDQUFBO2FBQzlCO1lBQ0QsTUFBTSxJQUFJLEVBQUUsQ0FBQTtRQUNkLENBQUMsQ0FBQTtJQUNILENBQUM7Q0FDRixDQUFBO0FBZlksbUJBQW1CO0lBRC9CLElBQUEsaUJBQVUsR0FBRTtHQUNBLG1CQUFtQixDQWUvQjtBQWZZLGtEQUFtQiJ9