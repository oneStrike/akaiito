"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ContainerLifeCycle = void 0;
const core_1 = require("@midwayjs/core");
const koa = require("@midwayjs/koa");
const validate = require("@midwayjs/validate");
const info = require("@midwayjs/info");
const passport = require("@midwayjs/passport");
const jwt = require("@midwayjs/jwt");
const cache = require("@midwayjs/cache");
const captcha = require("@midwayjs/captcha");
const sequlize = require("@midwayjs/sequelize");
const upload = require("@midwayjs/upload");
const staticFile = require("@midwayjs/static-file");
const crossDomain = require("@midwayjs/cross-domain");
const path_1 = require("path");
const exception_filter_1 = require("./filter/exception.filter");
const response_middleware_1 = require("./middleware/response.middleware");
const jwt_guard_1 = require("./guard/jwt.guard");
const serialize_middleware_1 = require("./middleware/serialize.middleware");
let ContainerLifeCycle = class ContainerLifeCycle {
    async onReady() {
        this.app.useFilter([exception_filter_1.ExceptionFilter]);
        this.app.useMiddleware([serialize_middleware_1.SerializeMiddleware, response_middleware_1.ResponseMiddleware]);
        this.app.useGuard([jwt_guard_1.JwtGuard]);
    }
};
__decorate([
    (0, core_1.App)(),
    __metadata("design:type", Object)
], ContainerLifeCycle.prototype, "app", void 0);
__decorate([
    (0, core_1.Logger)(),
    __metadata("design:type", Object)
], ContainerLifeCycle.prototype, "logger", void 0);
ContainerLifeCycle = __decorate([
    (0, core_1.Configuration)({
        imports: [
            jwt,
            koa,
            cache,
            upload,
            captcha,
            validate,
            passport,
            sequlize,
            staticFile,
            crossDomain,
            {
                component: info,
                enabledEnvironment: ['local', 'prod']
            }
        ],
        importConfigs: [(0, path_1.join)(__dirname, './config')]
    })
], ContainerLifeCycle);
exports.ContainerLifeCycle = ContainerLifeCycle;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29uZmlndXJhdGlvbi5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uL3NyYy9jb25maWd1cmF0aW9uLnRzIl0sIm5hbWVzIjpbXSwibWFwcGluZ3MiOiI7Ozs7Ozs7Ozs7OztBQUFBLHlDQUEyRDtBQUMzRCxxQ0FBb0M7QUFDcEMsK0NBQThDO0FBQzlDLHVDQUFzQztBQUN0QywrQ0FBOEM7QUFDOUMscUNBQW9DO0FBQ3BDLHlDQUF3QztBQUN4Qyw2Q0FBNEM7QUFDNUMsZ0RBQStDO0FBQy9DLDJDQUEwQztBQUMxQyxvREFBbUQ7QUFDbkQsc0RBQXFEO0FBRXJELCtCQUEyQjtBQUMzQixnRUFBMkQ7QUFDM0QsMEVBQXFFO0FBQ3JFLGlEQUE0QztBQUU1Qyw0RUFBdUU7QUFxQmhFLElBQU0sa0JBQWtCLEdBQXhCLE1BQU0sa0JBQWtCO0lBTzdCLEtBQUssQ0FBQyxPQUFPO1FBQ1gsSUFBSSxDQUFDLEdBQUcsQ0FBQyxTQUFTLENBQUMsQ0FBQyxrQ0FBZSxDQUFDLENBQUMsQ0FBQTtRQUNyQyxJQUFJLENBQUMsR0FBRyxDQUFDLGFBQWEsQ0FBQyxDQUFDLDBDQUFtQixFQUFFLHdDQUFrQixDQUFDLENBQUMsQ0FBQTtRQUNqRSxJQUFJLENBQUMsR0FBRyxDQUFDLFFBQVEsQ0FBQyxDQUFDLG9CQUFRLENBQUMsQ0FBQyxDQUFBO0lBQy9CLENBQUM7Q0FDRixDQUFBO0FBWEM7SUFBQyxJQUFBLFVBQUcsR0FBRTs7K0NBQ2M7QUFFcEI7SUFBQyxJQUFBLGFBQU0sR0FBRTs7a0RBQ3FCO0FBTG5CLGtCQUFrQjtJQW5COUIsSUFBQSxvQkFBYSxFQUFDO1FBQ2IsT0FBTyxFQUFFO1lBQ1AsR0FBRztZQUNILEdBQUc7WUFDSCxLQUFLO1lBQ0wsTUFBTTtZQUNOLE9BQU87WUFDUCxRQUFRO1lBQ1IsUUFBUTtZQUNSLFFBQVE7WUFDUixVQUFVO1lBQ1YsV0FBVztZQUNYO2dCQUNFLFNBQVMsRUFBRSxJQUFJO2dCQUNmLGtCQUFrQixFQUFFLENBQUMsT0FBTyxFQUFFLE1BQU0sQ0FBQzthQUN0QztTQUNGO1FBQ0QsYUFBYSxFQUFFLENBQUMsSUFBQSxXQUFJLEVBQUMsU0FBUyxFQUFFLFVBQVUsQ0FBQyxDQUFDO0tBQzdDLENBQUM7R0FDVyxrQkFBa0IsQ0FZOUI7QUFaWSxnREFBa0IifQ==