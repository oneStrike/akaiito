import * as koa from '@midwayjs/koa';
import { IMidwayLogger } from '@midwayjs/logger';
export declare class ContainerLifeCycle {
    app: koa.Application;
    readonly logger: IMidwayLogger;
    onReady(): Promise<void>;
}
