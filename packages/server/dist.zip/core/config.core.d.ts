import { MidwayConfigService } from '@midwayjs/core';
import { ConfigService } from '../service/config.service';
import { BaseMapping } from '../shared/mapping/base.mapping';
import { BaseService } from '../shared/service/base.service';
export declare class ConfigCore extends BaseService {
    protected mapping: BaseMapping;
    midwayConfigService: MidwayConfigService;
    configService: ConfigService;
    initConfig(): Promise<void>;
}
