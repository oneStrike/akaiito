"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.AutoLoadCore = void 0;
const core_1 = require("@midwayjs/core");
const serialize_decorator_1 = require("../decorator/serialize.decorator");
const config_core_1 = require("./config.core");
const page_service_1 = require("../service/clientManage/page/page.service");
let AutoLoadCore = class AutoLoadCore {
    async init() {
        //加载自定义方法装饰器
        this.midwayDecoratorService.registerMethodHandler(serialize_decorator_1.SERIALIZE_KEY, serialize_decorator_1.SerializeHandle);
        //初始化项目配置
        await this.configCore.initConfig();
        //插入客户端页面数据
        await this.pageService.createClientPage();
    }
};
__decorate([
    (0, core_1.Inject)(),
    __metadata("design:type", core_1.MidwayDecoratorService)
], AutoLoadCore.prototype, "midwayDecoratorService", void 0);
__decorate([
    (0, core_1.Inject)(),
    __metadata("design:type", config_core_1.ConfigCore)
], AutoLoadCore.prototype, "configCore", void 0);
__decorate([
    (0, core_1.Inject)(),
    __metadata("design:type", page_service_1.PageService)
], AutoLoadCore.prototype, "pageService", void 0);
__decorate([
    (0, core_1.Init)(),
    __metadata("design:type", Function),
    __metadata("design:paramtypes", []),
    __metadata("design:returntype", Promise)
], AutoLoadCore.prototype, "init", null);
AutoLoadCore = __decorate([
    (0, core_1.Autoload)(),
    (0, core_1.Provide)()
], AutoLoadCore);
exports.AutoLoadCore = AutoLoadCore;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYXV0b2xvYWQuY29yZS5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9jb3JlL2F1dG9sb2FkLmNvcmUudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7O0FBQUEseUNBTXVCO0FBQ3ZCLDBFQUd5QztBQUN6QywrQ0FBMEM7QUFDMUMsNEVBQXVFO0FBSWhFLElBQU0sWUFBWSxHQUFsQixNQUFNLFlBQVk7SUFXakIsQUFBTixLQUFLLENBQUMsSUFBSTtRQUNSLFlBQVk7UUFDWixJQUFJLENBQUMsc0JBQXNCLENBQUMscUJBQXFCLENBQy9DLG1DQUFhLEVBQ2IscUNBQWUsQ0FDaEIsQ0FBQTtRQUVELFNBQVM7UUFDVCxNQUFNLElBQUksQ0FBQyxVQUFVLENBQUMsVUFBVSxFQUFFLENBQUE7UUFFbEMsV0FBVztRQUNYLE1BQU0sSUFBSSxDQUFDLFdBQVcsQ0FBQyxnQkFBZ0IsRUFBRSxDQUFBO0lBQzNDLENBQUM7Q0FDRixDQUFBO0FBdkJDO0lBQUMsSUFBQSxhQUFNLEdBQUU7OEJBQ2UsNkJBQXNCOzREQUFBO0FBRTlDO0lBQUMsSUFBQSxhQUFNLEdBQUU7OEJBQ0csd0JBQVU7Z0RBQUE7QUFFdEI7SUFBQyxJQUFBLGFBQU0sR0FBRTs4QkFDSSwwQkFBVztpREFBQTtBQUdsQjtJQURMLElBQUEsV0FBSSxHQUFFOzs7O3dDQWFOO0FBdkJVLFlBQVk7SUFGeEIsSUFBQSxlQUFRLEdBQUU7SUFDVixJQUFBLGNBQU8sR0FBRTtHQUNHLFlBQVksQ0F3QnhCO0FBeEJZLG9DQUFZIn0=