import { MidwayDecoratorService } from '@midwayjs/core';
import { ConfigCore } from './config.core';
import { PageService } from '../service/clientManage/page/page.service';
export declare class AutoLoadCore {
    midwayDecoratorService: MidwayDecoratorService;
    configCore: ConfigCore;
    pageService: PageService;
    init(): Promise<void>;
}
