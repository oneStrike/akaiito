"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ConfigCore = void 0;
const core_1 = require("@midwayjs/core");
const config_service_1 = require("../service/config.service");
const config_enum_1 = require("../shared/enum/config.enum");
const base_service_1 = require("../shared/service/base.service");
const path_1 = require("path");
let ConfigCore = class ConfigCore extends base_service_1.BaseService {
    async initConfig() {
        Promise.all([
            this.configService.getConfig(config_enum_1.ConfigEnum.JWT),
            this.configService.getConfig(config_enum_1.ConfigEnum.STATIC),
            this.configService.getConfig(config_enum_1.ConfigEnum.UPLOAD),
            this.configService.getConfig(config_enum_1.ConfigEnum.WHITELIST)
        ]).then(async ([jwt, staticCache, { upload }, whitelist]) => {
            upload.tmpdir = (0, path_1.join)(__dirname, '../../') + upload.tmpdir;
            await this.utils.fs.ensureDir(upload.tmpdir);
            this.midwayConfigService.addObject(jwt);
            this.midwayConfigService.addObject({ static: staticCache });
            this.midwayConfigService.addObject({ upload });
            this.midwayConfigService.addObject(whitelist);
        });
    }
};
__decorate([
    (0, core_1.Inject)(),
    __metadata("design:type", core_1.MidwayConfigService)
], ConfigCore.prototype, "midwayConfigService", void 0);
__decorate([
    (0, core_1.Inject)(),
    __metadata("design:type", config_service_1.ConfigService)
], ConfigCore.prototype, "configService", void 0);
ConfigCore = __decorate([
    (0, core_1.Provide)()
], ConfigCore);
exports.ConfigCore = ConfigCore;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29uZmlnLmNvcmUuanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi9zcmMvY29yZS9jb25maWcuY29yZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7QUFBQSx5Q0FBcUU7QUFDckUsOERBQXlEO0FBQ3pELDREQUF1RDtBQUV2RCxpRUFBNEQ7QUFDNUQsK0JBQTJCO0FBR3BCLElBQU0sVUFBVSxHQUFoQixNQUFNLFVBQVcsU0FBUSwwQkFBVztJQVN6QyxLQUFLLENBQUMsVUFBVTtRQUNkLE9BQU8sQ0FBQyxHQUFHLENBQUM7WUFDVixJQUFJLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQyx3QkFBVSxDQUFDLEdBQUcsQ0FBQztZQUM1QyxJQUFJLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQyx3QkFBVSxDQUFDLE1BQU0sQ0FBQztZQUMvQyxJQUFJLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQyx3QkFBVSxDQUFDLE1BQU0sQ0FBQztZQUMvQyxJQUFJLENBQUMsYUFBYSxDQUFDLFNBQVMsQ0FBQyx3QkFBVSxDQUFDLFNBQVMsQ0FBQztTQUNuRCxDQUFDLENBQUMsSUFBSSxDQUNMLEtBQUssRUFBRSxDQUFDLEdBQUcsRUFBRSxXQUFXLEVBQUUsRUFBRSxNQUFNLEVBQUUsRUFBRSxTQUFTLENBRzVDLEVBQUUsRUFBRTtZQUNMLE1BQU0sQ0FBQyxNQUFNLEdBQUcsSUFBQSxXQUFJLEVBQUMsU0FBUyxFQUFFLFFBQVEsQ0FBQyxHQUFHLE1BQU0sQ0FBQyxNQUFNLENBQUE7WUFDekQsTUFBTSxJQUFJLENBQUMsS0FBSyxDQUFDLEVBQUUsQ0FBQyxTQUFTLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxDQUFBO1lBQzVDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxTQUFTLENBQUMsR0FBRyxDQUFDLENBQUE7WUFDdkMsSUFBSSxDQUFDLG1CQUFtQixDQUFDLFNBQVMsQ0FBQyxFQUFFLE1BQU0sRUFBRSxXQUFXLEVBQUUsQ0FBQyxDQUFBO1lBQzNELElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxTQUFTLENBQUMsRUFBRSxNQUFNLEVBQUUsQ0FBQyxDQUFBO1lBQzlDLElBQUksQ0FBQyxtQkFBbUIsQ0FBQyxTQUFTLENBQUMsU0FBUyxDQUFDLENBQUE7UUFDL0MsQ0FBQyxDQUNGLENBQUE7SUFDSCxDQUFDO0NBQ0YsQ0FBQTtBQTFCQztJQUFDLElBQUEsYUFBTSxHQUFFOzhCQUNZLDBCQUFtQjt1REFBQTtBQUV4QztJQUFDLElBQUEsYUFBTSxHQUFFOzhCQUNNLDhCQUFhO2lEQUFBO0FBUGpCLFVBQVU7SUFEdEIsSUFBQSxjQUFPLEdBQUU7R0FDRyxVQUFVLENBNkJ0QjtBQTdCWSxnQ0FBVSJ9