import { Model, Repository } from 'sequelize-typescript';
import { ListResponseRes } from '../../types/dto/list';
import Utils from '../../utils';
import { MakeNullishOptional } from 'sequelize/types/utils';
import { Attributes, FindOptions, WhereOptions } from 'sequelize';
import { BaseEntity } from '../entities/basic.entity';
import { FindMultipleMappingOptions } from '../../types/service/base';
import { BulkCreateOptions } from 'sequelize/types/model';
export declare abstract class BaseMapping<T extends BaseEntity = Model> {
    utils: Utils;
    protected abstract repository: Repository<T>;
    /**
     * 查到单条数据
     * @param where 查询条件
     * @param withDeleted 是否查询软删除的数据
     */
    findOne(where: WhereOptions, withDeleted?: boolean): Promise<T>;
    /**
     * 根据主键查询一条数据
     * @param id
     */
    findByPk(id: number): Promise<T>;
    /**
     * 查到多条数据
     * @param queryParams
     * @param options 附属查询条件
     */
    findMultiple(options: FindMultipleMappingOptions): Promise<ListResponseRes<T>>;
    /**
     * 查找所有
     * @param options
     */
    findAll(options?: FindOptions<Attributes<T>>): Promise<T[]>;
    /**
     * 插入一条数据
     * @param val 插入的数据
     */
    create(val: MakeNullishOptional<T>): Promise<T>;
    /**
     * 批量插入数据
     */
    bulkCreate(params: MakeNullishOptional<T>[], options?: BulkCreateOptions<Attributes<T>>): Promise<T[]>;
    /**
     * 更新数据
     * @param updateData
     * @param where 更新条件
     */
    updateOne(updateData: Partial<T>, where: WhereOptions<Attributes<T>>): Promise<[affectedCount: number]>;
    /**
     * 删除一条数据
     * @param where
     */
    destroy(where: WhereOptions<Attributes<T>>): Promise<number>;
    /**
     * 恢复软删除一条数据
     * @param id 主键
     */
    softRestore(id: number): Promise<void>;
    /**
     * 清空数据表
     * 根据表的paranoid决定是否是软删除
     */
    clearTable(): Promise<number>;
}
