"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BaseMapping = void 0;
const core_1 = require("@midwayjs/core");
const utils_1 = require("../../utils");
let BaseMapping = class BaseMapping {
    /**
     * 查到单条数据
     * @param where 查询条件
     * @param withDeleted 是否查询软删除的数据
     */
    async findOne(where, withDeleted = false) {
        return this.repository.findOne({
            where,
            paranoid: !withDeleted,
            raw: true
        });
    }
    /**
     * 根据主键查询一条数据
     * @param id
     */
    async findByPk(id) {
        return this.repository.findByPk(id, { raw: true });
    }
    /**
     * 查到多条数据
     * @param queryParams
     * @param options 附属查询条件
     */
    async findMultiple(options) {
        const { where, listOptions, withDeleted } = options;
        let order;
        if (listOptions.sortField) {
            const { sort, sortField } = listOptions;
            order = [sortField, sort];
        }
        delete listOptions.sort;
        delete listOptions.sortField;
        const listData = await this.repository.findAndCountAll({
            ...where,
            paranoid: !withDeleted,
            order: order ? [order] : [],
            offset: listOptions.pageIndex * listOptions.pageSize,
            limit: listOptions.pageSize,
            raw: true
        });
        const { rows, count } = listData;
        return {
            list: rows,
            total: count,
            count: rows.length,
            ...options.listOptions
        };
    }
    /**
     * 查找所有
     * @param options
     */
    async findAll(options) {
        return await this.repository.findAll(options);
    }
    /**
     * 插入一条数据
     * @param val 插入的数据
     */
    async create(val) {
        return await this.repository.create(val);
    }
    /**
     * 批量插入数据
     */
    async bulkCreate(params, options) {
        return await this.repository.bulkCreate(params, options);
    }
    /**
     * 更新数据
     * @param updateData
     * @param where 更新条件
     */
    async updateOne(updateData, where) {
        return await this.repository.update(updateData, {
            where
        });
    }
    /**
     * 删除一条数据
     * @param where
     */
    async destroy(where) {
        return this.repository.destroy({ where });
    }
    /**
     * 恢复软删除一条数据
     * @param id 主键
     */
    async softRestore(id) {
        return (await this.findOne({ id }, true)).restore();
    }
    /**
     * 清空数据表
     * 根据表的paranoid决定是否是软删除
     */
    async clearTable() {
        return await this.repository.destroy({ truncate: true });
    }
};
__decorate([
    (0, core_1.Inject)(),
    __metadata("design:type", utils_1.default
    //实体
    )
], BaseMapping.prototype, "utils", void 0);
BaseMapping = __decorate([
    (0, core_1.Provide)()
], BaseMapping);
exports.BaseMapping = BaseMapping;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYmFzZS5tYXBwaW5nLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vc3JjL3NoYXJlZC9tYXBwaW5nL2Jhc2UubWFwcGluZy50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7QUFBQSx5Q0FBZ0Q7QUFHaEQsdUNBQStCO0FBUXhCLElBQWUsV0FBVyxHQUExQixNQUFlLFdBQVc7SUFPL0I7Ozs7T0FJRztJQUNILEtBQUssQ0FBQyxPQUFPLENBQUMsS0FBbUIsRUFBRSxXQUFXLEdBQUcsS0FBSztRQUNwRCxPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDO1lBQzdCLEtBQUs7WUFDTCxRQUFRLEVBQUUsQ0FBQyxXQUFXO1lBQ3RCLEdBQUcsRUFBRSxJQUFJO1NBQ1YsQ0FBQyxDQUFBO0lBQ0osQ0FBQztJQUVEOzs7T0FHRztJQUNILEtBQUssQ0FBQyxRQUFRLENBQUMsRUFBVTtRQUN2QixPQUFPLElBQUksQ0FBQyxVQUFVLENBQUMsUUFBUSxDQUFDLEVBQUUsRUFBRSxFQUFFLEdBQUcsRUFBRSxJQUFJLEVBQUUsQ0FBQyxDQUFBO0lBQ3BELENBQUM7SUFFRDs7OztPQUlHO0lBQ0gsS0FBSyxDQUFDLFlBQVksQ0FDaEIsT0FBbUM7UUFFbkMsTUFBTSxFQUFFLEtBQUssRUFBRSxXQUFXLEVBQUUsV0FBVyxFQUFFLEdBQUcsT0FBTyxDQUFBO1FBQ25ELElBQUksS0FBSyxDQUFBO1FBQ1QsSUFBSSxXQUFXLENBQUMsU0FBUyxFQUFFO1lBQ3pCLE1BQU0sRUFBRSxJQUFJLEVBQUUsU0FBUyxFQUFFLEdBQUcsV0FBVyxDQUFBO1lBQ3ZDLEtBQUssR0FBRyxDQUFDLFNBQVMsRUFBRSxJQUFJLENBQUMsQ0FBQTtTQUMxQjtRQUVELE9BQU8sV0FBVyxDQUFDLElBQUksQ0FBQTtRQUN2QixPQUFPLFdBQVcsQ0FBQyxTQUFTLENBQUE7UUFDNUIsTUFBTSxRQUFRLEdBQUcsTUFBTSxJQUFJLENBQUMsVUFBVSxDQUFDLGVBQWUsQ0FBQztZQUNyRCxHQUFHLEtBQUs7WUFDUixRQUFRLEVBQUUsQ0FBQyxXQUFXO1lBQ3RCLEtBQUssRUFBRSxLQUFLLENBQUMsQ0FBQyxDQUFDLENBQUMsS0FBSyxDQUFDLENBQUMsQ0FBQyxDQUFDLEVBQUU7WUFDM0IsTUFBTSxFQUFFLFdBQVcsQ0FBQyxTQUFTLEdBQUcsV0FBVyxDQUFDLFFBQVE7WUFDcEQsS0FBSyxFQUFFLFdBQVcsQ0FBQyxRQUFRO1lBQzNCLEdBQUcsRUFBRSxJQUFJO1NBQ1YsQ0FBQyxDQUFBO1FBRUYsTUFBTSxFQUFFLElBQUksRUFBRSxLQUFLLEVBQUUsR0FBRyxRQUFRLENBQUE7UUFDaEMsT0FBTztZQUNMLElBQUksRUFBRSxJQUFJO1lBQ1YsS0FBSyxFQUFFLEtBQUs7WUFDWixLQUFLLEVBQUUsSUFBSSxDQUFDLE1BQU07WUFDbEIsR0FBRyxPQUFPLENBQUMsV0FBVztTQUN2QixDQUFBO0lBQ0gsQ0FBQztJQUVEOzs7T0FHRztJQUNILEtBQUssQ0FBQyxPQUFPLENBQUMsT0FBb0M7UUFDaEQsT0FBTyxNQUFNLElBQUksQ0FBQyxVQUFVLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxDQUFBO0lBQy9DLENBQUM7SUFFRDs7O09BR0c7SUFDSCxLQUFLLENBQUMsTUFBTSxDQUFDLEdBQTJCO1FBQ3RDLE9BQU8sTUFBTSxJQUFJLENBQUMsVUFBVSxDQUFDLE1BQU0sQ0FBQyxHQUFHLENBQUMsQ0FBQTtJQUMxQyxDQUFDO0lBRUQ7O09BRUc7SUFDSCxLQUFLLENBQUMsVUFBVSxDQUNkLE1BQWdDLEVBQ2hDLE9BQTBDO1FBRTFDLE9BQU8sTUFBTSxJQUFJLENBQUMsVUFBVSxDQUFDLFVBQVUsQ0FBQyxNQUFNLEVBQUUsT0FBTyxDQUFDLENBQUE7SUFDMUQsQ0FBQztJQUVEOzs7O09BSUc7SUFDSCxLQUFLLENBQUMsU0FBUyxDQUFDLFVBQXNCLEVBQUUsS0FBa0M7UUFDeEUsT0FBTyxNQUFNLElBQUksQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLFVBQVUsRUFBRTtZQUM5QyxLQUFLO1NBQ04sQ0FBQyxDQUFBO0lBQ0osQ0FBQztJQUVEOzs7T0FHRztJQUNILEtBQUssQ0FBQyxPQUFPLENBQUMsS0FBa0M7UUFDOUMsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFDLE9BQU8sQ0FBQyxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUE7SUFDM0MsQ0FBQztJQUVEOzs7T0FHRztJQUNILEtBQUssQ0FBQyxXQUFXLENBQUMsRUFBVTtRQUMxQixPQUFPLENBQUMsTUFBTSxJQUFJLENBQUMsT0FBTyxDQUFDLEVBQUUsRUFBRSxFQUFFLEVBQUUsSUFBSSxDQUFDLENBQUMsQ0FBQyxPQUFPLEVBQUUsQ0FBQTtJQUNyRCxDQUFDO0lBRUQ7OztPQUdHO0lBQ0gsS0FBSyxDQUFDLFVBQVU7UUFDZCxPQUFPLE1BQU0sSUFBSSxDQUFDLFVBQVUsQ0FBQyxPQUFPLENBQUMsRUFBRSxRQUFRLEVBQUUsSUFBSSxFQUFFLENBQUMsQ0FBQTtJQUMxRCxDQUFDO0NBQ0YsQ0FBQTtBQTFIQztJQUFDLElBQUEsYUFBTSxHQUFFOzhCQUNGLGVBQUs7SUFFWixJQUFJOzswQ0FGUTtBQUZRLFdBQVc7SUFEaEMsSUFBQSxjQUFPLEdBQUU7R0FDWSxXQUFXLENBMkhoQztBQTNIcUIsa0NBQVcifQ==