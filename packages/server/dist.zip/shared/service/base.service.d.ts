import { MidwayWebRouterService } from "@midwayjs/core";
import { Application, Context } from "@midwayjs/koa";
import Util from "../../utils";
import type { ListQueryOptions } from "../../types/dto/list";
import { WhereOptions } from "sequelize";
import { ConfigService } from "../../service/config.service";
import { BaseMapping } from "../mapping/base.mapping";
import { Model } from "sequelize-typescript";
import type { FindMultipleServiceOptions, NullReg } from "../../types/service/base";
import { RegExpMatch } from "../../types/service/base";
export declare abstract class BaseService {
    pageIndex: number;
    pageSize: number;
    maxPageSize: number;
    sort: ListQueryOptions["sort"];
    protected app: Application;
    webRouterService: MidwayWebRouterService;
    protected abstract mapping: BaseMapping;
    configService: ConfigService;
    midwayConfig: any;
    protected ctx: Context;
    protected utils: Util;
    normalError(tips: string): void;
    create<T>(params: T): Promise<number>;
    bulkCreate<T>(params: T[]): Promise<Model[]>;
    findOne(where: WhereOptions): Promise<Model<any, any>>;
    findByPk(id: number): Promise<Model<any, any>>;
    findMultiple(options: FindMultipleServiceOptions): Promise<import("../../types/dto/list").ListResponseRes<Model<any, any>>>;
    /**
     * 查找所有
     */
    findAll(): Promise<Model<any, any>[]>;
    update<T>(params: T, id: number | number[]): Promise<number | number[]>;
    updateMultiple<T extends {
        ids: number[];
    }>(params: Partial<T>): Promise<number | number[]>;
    destroy(id: number | number[]): Promise<number | number[]>;
    /**
     *  获取最大排序值
     */
    getMaxSort(field?: string, mapping?: BaseMapping<Model<any, any>>): Promise<number>;
    isUniqueError(err: any, isHandler?: boolean): boolean | void;
    /**
     * 判断是否已经存在
     */
    isExists(where: WhereOptions | number, isPk?: boolean, isError?: boolean): Promise<any>;
    /**
     * 生成where查询接口
     * @param where
     */
    getWhere(where: Record<string, any>): {
        where: any;
        listOptions: {
            sort: any;
            pageIndex: number;
            pageSize: number;
            sortField: any;
        };
    };
    /**
     * 处理时间查询
     */
    handleDate(params: any): any;
    /**
     *格式化查询列表数据的附属参数
     * @param param
     */
    formatListQueryParams(param: any): {
        sort: any;
        pageIndex: number;
        pageSize: number;
        sortField: any;
    };
    /**
     * 多条查询语句时生成or查询语句
     * @param where 查询体检
     * @private
     */
    generateORSql(where: WhereOptions): WhereOptions;
    generateNullSql(nullKeys: NullReg, params: Record<string | symbol, any>): {};
    /**
     * 生成like查询参数
     * @param likeKeys
     * @param params
     */
    generateLikeSql(likeKeys: RegExpMatch, params: Record<string, any>): {};
}
