"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BaseService = void 0;
const core_1 = require("@midwayjs/core");
const utils_1 = require("../../utils");
const sequelize_1 = require("sequelize");
const config_service_1 = require("../../service/config.service");
class BaseService {
    constructor() {
        //列表查询初始参数
        this.pageIndex = 0; //默认页偏移量
        this.pageSize = 15; //默认页大小
        this.maxPageSize = 500; //默认最大页大小
        this.sort = ""; //默认排序方式
    }
    normalError(tips) {
        throw new core_1.httpError.BadRequestError(tips);
    }
    //创建
    async create(params) {
        return (await this.mapping.create(params)).id;
    }
    //批量创建
    async bulkCreate(params) {
        return await this.mapping.bulkCreate(params);
    }
    async findOne(where) {
        return await this.mapping.findOne(where);
    }
    async findByPk(id) {
        return await this.mapping.findByPk(id);
    }
    //查找多个
    async findMultiple(options) {
        let { params, attributes, likeKeys, nullKeys } = options;
        if (likeKeys) {
            params = this.generateLikeSql(likeKeys, params);
        }
        if (nullKeys) {
            params = this.generateNullSql(nullKeys, params);
        }
        const { where, listOptions } = this.getWhere(params);
        console.log(params, 123);
        return await this.mapping.findMultiple({
            where: { where, attributes },
            listOptions
        });
    }
    /**
     * 查找所有
     */
    async findAll() {
        return await this.mapping.findAll();
    }
    //更新
    async update(params, id) {
        await this.mapping.updateOne(params, { id });
        return id;
    }
    //批量更新
    async updateMultiple(params) {
        const ids = this.utils.lodash.cloneDeep(params.ids);
        delete params.ids;
        return await this.update(this.utils.lodash.omit(params, "ids"), ids);
    }
    //删除
    async destroy(id) {
        await this.mapping.destroy({ id });
        return id;
    }
    /**
     *  获取最大排序值
     */
    async getMaxSort(field = "sort", mapping = this.mapping) {
        const maxSortArr = await mapping.findAll({
            limit: 1,
            order: [[field, "desc"]],
            paranoid: false,
            raw: true
        });
        let maxSort = 0;
        if (maxSortArr.length) {
            maxSort = maxSortArr[0][field];
        }
        return maxSort;
    }
    isUniqueError(err, isHandler = true) {
        if (!err || !err.name)
            return false;
        const isError = err.name === "SequelizeUniqueConstraintError";
        if (isError && isHandler) {
            return this.normalError("数据重复");
        }
        return isError;
    }
    /**
     * 判断是否已经存在
     */
    async isExists(where, isPk = false, isError = true) {
        let result;
        if (isPk && typeof where === "number") {
            result = await this.mapping.findByPk(where);
        }
        else if (!isPk && typeof where !== "number") {
            result = await this.mapping.findOne(where, true);
        }
        let errMsg = "";
        if (isError && result !== null) {
            if (typeof where === "number") {
                errMsg = "id：" + where;
            }
            else if (typeof where !== "number") {
                for (const whereKey in where) {
                    errMsg = where[whereKey];
                }
            }
        }
        return errMsg ? this.normalError(`【${errMsg}】已经存在`) : result;
    }
    /**
     * 生成where查询接口
     * @param where
     */
    getWhere(where) {
        const listOptionsKeys = ["pageSize", "pageIndex", "sort", "sortField"];
        //过滤空值
        const trueWhere = this.utils.lodash.pickBy(where, (val) => {
            return !this.utils.lodash.isNil(val);
        });
        //生成列表查询参数
        const listOptions = this.formatListQueryParams(where);
        //过滤掉列表查询参数
        const prueWhere = this.utils.lodash.omit(trueWhere, [
            ...listOptionsKeys,
            "attributes"
        ]);
        //生成时间查询参数
        return {
            where: this.handleDate(prueWhere),
            listOptions
        };
    }
    /**
     * 处理时间查询
     */
    handleDate(params) {
        const { startDate, endDate } = params;
        if (!startDate && !endDate)
            return params;
        const start = startDate || "2022-12-03 23:57:32";
        const end = endDate || this.utils.dayjs().format("YY-MM-DD HH:mm:ss");
        params.createdAt = {
            [sequelize_1.Op.between]: [start, end]
        };
        delete params.startDate;
        delete params.endDate;
        return params;
    }
    /**
     *格式化查询列表数据的附属参数
     * @param param
     */
    formatListQueryParams(param) {
        const pageSize = param?.pageSize ?? this.pageSize;
        return {
            sort: param?.sort || this.sort,
            pageIndex: Number(param?.pageIndex) || this.pageIndex,
            pageSize: Number(pageSize > 100 ? this.maxPageSize : pageSize),
            sortField: param?.sort ? param?.sortField ?? "" : ""
        };
    }
    /**
     * 多条查询语句时生成or查询语句
     * @param where 查询体检
     * @private
     */
    generateORSql(where) {
        if (!this.utils.lodash.isObject(where))
            return;
        const whereLen = Object.keys(where).length;
        if (whereLen === 1)
            return where;
        const whereStatement = [];
        for (const whereKey in where) {
            const item = where[whereKey];
            whereStatement.push({
                [whereKey]: item
            });
        }
        return { [sequelize_1.Op.or]: whereStatement };
    }
    generateNullSql(nullKeys, params) {
        if (!nullKeys)
            return;
        const keys = Object.keys(nullKeys);
        if (!keys.length)
            return;
        const nullRes = {};
        this.utils.lodash.forOwn(nullKeys, (value, key) => {
            const mode = nullKeys[key];
            const flag = mode === "is" ? sequelize_1.Op.is : sequelize_1.Op.not;
            nullRes[key] = { [flag]: null };
        });
        return {
            ...this.utils.lodash.omit(params, keys),
            ...nullRes
        };
    }
    /**
     * 生成like查询参数
     * @param likeKeys
     * @param params
     */
    generateLikeSql(likeKeys, params) {
        const keys = Object.keys(likeKeys);
        const likeObj = this.utils.lodash.pick(params, keys);
        const likeRes = {};
        this.utils.lodash.forOwn(likeObj, (value, key) => {
            const mode = likeKeys[key];
            if (mode === "sporadic") {
                likeRes[key] = {
                    [sequelize_1.Op.regexp]: `[${value.replaceAll(",", "|")}]`
                };
            }
            else if (mode === "include") {
                const valueArr = value.split(",");
                let reg = "";
                valueArr.forEach((item) => {
                    reg += `(?=.*${item})`;
                });
                likeRes[key] = {
                    [sequelize_1.Op.regexp]: `^${reg}.*$`
                };
            }
        });
        return {
            ...this.utils.lodash.omit(params, keys),
            ...likeRes
        };
    }
}
__decorate([
    (0, core_1.App)(),
    __metadata("design:type", Object)
], BaseService.prototype, "app", void 0);
__decorate([
    (0, core_1.Inject)(),
    __metadata("design:type", core_1.MidwayWebRouterService)
], BaseService.prototype, "webRouterService", void 0);
__decorate([
    (0, core_1.Inject)(),
    __metadata("design:type", config_service_1.ConfigService)
], BaseService.prototype, "configService", void 0);
__decorate([
    (0, core_1.Config)(core_1.ALL),
    __metadata("design:type", Object)
], BaseService.prototype, "midwayConfig", void 0);
__decorate([
    (0, core_1.Inject)(),
    __metadata("design:type", Object)
], BaseService.prototype, "ctx", void 0);
__decorate([
    (0, core_1.Inject)(),
    __metadata("design:type", utils_1.default)
], BaseService.prototype, "utils", void 0);
exports.BaseService = BaseService;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYmFzZS5zZXJ2aWNlLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vc3JjL3NoYXJlZC9zZXJ2aWNlL2Jhc2Uuc2VydmljZS50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7QUFBQSx5Q0FPd0I7QUFFeEIsdUNBQStCO0FBRS9CLHlDQUE2QztBQUM3QyxpRUFBNkQ7QUFNN0QsTUFBc0IsV0FBVztJQUFqQztRQUNFLFVBQVU7UUFDVixjQUFTLEdBQUcsQ0FBQyxDQUFDLENBQUMsUUFBUTtRQUN2QixhQUFRLEdBQUcsRUFBRSxDQUFDLENBQUMsT0FBTztRQUN0QixnQkFBVyxHQUFHLEdBQUcsQ0FBQyxDQUFDLFNBQVM7UUFDNUIsU0FBSSxHQUE2QixFQUFFLENBQUMsQ0FBQyxRQUFRO0lBNFEvQyxDQUFDO0lBdFBDLFdBQVcsQ0FBQyxJQUFZO1FBQ3RCLE1BQU0sSUFBSSxnQkFBUyxDQUFDLGVBQWUsQ0FBQyxJQUFJLENBQUMsQ0FBQztJQUM1QyxDQUFDO0lBRUQsSUFBSTtJQUNKLEtBQUssQ0FBQyxNQUFNLENBQUksTUFBUztRQUN2QixPQUFPLENBQUMsTUFBTSxJQUFJLENBQUMsT0FBTyxDQUFDLE1BQU0sQ0FBQyxNQUFNLENBQUMsQ0FBQyxDQUFDLEVBQUUsQ0FBQztJQUNoRCxDQUFDO0lBRUQsTUFBTTtJQUNOLEtBQUssQ0FBQyxVQUFVLENBQUksTUFBVztRQUM3QixPQUFPLE1BQU0sSUFBSSxDQUFDLE9BQU8sQ0FBQyxVQUFVLENBQUMsTUFBTSxDQUFDLENBQUM7SUFDL0MsQ0FBQztJQUVELEtBQUssQ0FBQyxPQUFPLENBQUMsS0FBbUI7UUFDL0IsT0FBTyxNQUFNLElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxDQUFDLEtBQUssQ0FBQyxDQUFDO0lBQzNDLENBQUM7SUFFRCxLQUFLLENBQUMsUUFBUSxDQUFDLEVBQVU7UUFDdkIsT0FBTyxNQUFNLElBQUksQ0FBQyxPQUFPLENBQUMsUUFBUSxDQUFDLEVBQUUsQ0FBQyxDQUFDO0lBQ3pDLENBQUM7SUFFRCxNQUFNO0lBQ04sS0FBSyxDQUFDLFlBQVksQ0FBQyxPQUFtQztRQUNwRCxJQUFJLEVBQUUsTUFBTSxFQUFFLFVBQVUsRUFBRSxRQUFRLEVBQUUsUUFBUSxFQUFFLEdBQUcsT0FBTyxDQUFDO1FBQ3pELElBQUksUUFBUSxFQUFFO1lBQ1osTUFBTSxHQUFHLElBQUksQ0FBQyxlQUFlLENBQUMsUUFBUSxFQUFFLE1BQU0sQ0FBQyxDQUFDO1NBQ2pEO1FBQ0QsSUFBSSxRQUFRLEVBQUU7WUFDWixNQUFNLEdBQUcsSUFBSSxDQUFDLGVBQWUsQ0FBQyxRQUFRLEVBQUUsTUFBTSxDQUFDLENBQUM7U0FDakQ7UUFDRCxNQUFNLEVBQUUsS0FBSyxFQUFFLFdBQVcsRUFBRSxHQUFHLElBQUksQ0FBQyxRQUFRLENBQUMsTUFBTSxDQUFDLENBQUM7UUFDckQsT0FBTyxDQUFDLEdBQUcsQ0FBQyxNQUFNLEVBQUUsR0FBRyxDQUFDLENBQUM7UUFDekIsT0FBTyxNQUFNLElBQUksQ0FBQyxPQUFPLENBQUMsWUFBWSxDQUFDO1lBQ3JDLEtBQUssRUFBRSxFQUFFLEtBQUssRUFBRSxVQUFVLEVBQUU7WUFDNUIsV0FBVztTQUNaLENBQUMsQ0FBQztJQUNMLENBQUM7SUFFRDs7T0FFRztJQUNILEtBQUssQ0FBQyxPQUFPO1FBQ1gsT0FBTyxNQUFNLElBQUksQ0FBQyxPQUFPLENBQUMsT0FBTyxFQUFFLENBQUM7SUFDdEMsQ0FBQztJQUVELElBQUk7SUFDSixLQUFLLENBQUMsTUFBTSxDQUNWLE1BQVMsRUFDVCxFQUFxQjtRQUVyQixNQUFNLElBQUksQ0FBQyxPQUFPLENBQUMsU0FBUyxDQUFDLE1BQU0sRUFBRSxFQUFFLEVBQUUsRUFBRSxDQUFDLENBQUM7UUFDN0MsT0FBTyxFQUFFLENBQUM7SUFDWixDQUFDO0lBRUQsTUFBTTtJQUNOLEtBQUssQ0FBQyxjQUFjLENBQ2xCLE1BQWtCO1FBRWxCLE1BQU0sR0FBRyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLFNBQVMsQ0FBQyxNQUFNLENBQUMsR0FBRyxDQUFDLENBQUM7UUFDcEQsT0FBTyxNQUFNLENBQUMsR0FBRyxDQUFDO1FBQ2xCLE9BQU8sTUFBTSxJQUFJLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsS0FBSyxDQUFDLEVBQUUsR0FBRyxDQUFDLENBQUM7SUFDdkUsQ0FBQztJQUVELElBQUk7SUFDSixLQUFLLENBQUMsT0FBTyxDQUFDLEVBQXFCO1FBQ2pDLE1BQU0sSUFBSSxDQUFDLE9BQU8sQ0FBQyxPQUFPLENBQUMsRUFBRSxFQUFFLEVBQUUsQ0FBQyxDQUFDO1FBQ25DLE9BQU8sRUFBRSxDQUFDO0lBQ1osQ0FBQztJQUVEOztPQUVHO0lBQ0gsS0FBSyxDQUFDLFVBQVUsQ0FBQyxLQUFLLEdBQUcsTUFBTSxFQUFFLE9BQU8sR0FBRyxJQUFJLENBQUMsT0FBTztRQUNyRCxNQUFNLFVBQVUsR0FBRyxNQUFNLE9BQU8sQ0FBQyxPQUFPLENBQUM7WUFDdkMsS0FBSyxFQUFFLENBQUM7WUFDUixLQUFLLEVBQUUsQ0FBQyxDQUFDLEtBQUssRUFBRSxNQUFNLENBQUMsQ0FBQztZQUN4QixRQUFRLEVBQUUsS0FBSztZQUNmLEdBQUcsRUFBRSxJQUFJO1NBQ1YsQ0FBQyxDQUFDO1FBQ0gsSUFBSSxPQUFPLEdBQUcsQ0FBQyxDQUFDO1FBQ2hCLElBQUksVUFBVSxDQUFDLE1BQU0sRUFBRTtZQUNyQixPQUFPLEdBQUcsVUFBVSxDQUFDLENBQUMsQ0FBQyxDQUFDLEtBQUssQ0FBQyxDQUFDO1NBQ2hDO1FBRUQsT0FBTyxPQUFPLENBQUM7SUFDakIsQ0FBQztJQUVELGFBQWEsQ0FBQyxHQUFRLEVBQUUsU0FBUyxHQUFHLElBQUk7UUFDdEMsSUFBSSxDQUFDLEdBQUcsSUFBSSxDQUFDLEdBQUcsQ0FBQyxJQUFJO1lBQUUsT0FBTyxLQUFLLENBQUM7UUFDcEMsTUFBTSxPQUFPLEdBQUcsR0FBRyxDQUFDLElBQUksS0FBSyxnQ0FBZ0MsQ0FBQztRQUM5RCxJQUFJLE9BQU8sSUFBSSxTQUFTLEVBQUU7WUFDeEIsT0FBTyxJQUFJLENBQUMsV0FBVyxDQUFDLE1BQU0sQ0FBQyxDQUFDO1NBQ2pDO1FBQ0QsT0FBTyxPQUFPLENBQUM7SUFDakIsQ0FBQztJQUVEOztPQUVHO0lBQ0gsS0FBSyxDQUFDLFFBQVEsQ0FBQyxLQUE0QixFQUFFLElBQUksR0FBRyxLQUFLLEVBQUUsT0FBTyxHQUFHLElBQUk7UUFDdkUsSUFBSSxNQUFNLENBQUM7UUFDWCxJQUFJLElBQUksSUFBSSxPQUFPLEtBQUssS0FBSyxRQUFRLEVBQUU7WUFDckMsTUFBTSxHQUFHLE1BQU0sSUFBSSxDQUFDLE9BQU8sQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDLENBQUM7U0FDN0M7YUFBTSxJQUFJLENBQUMsSUFBSSxJQUFJLE9BQU8sS0FBSyxLQUFLLFFBQVEsRUFBRTtZQUM3QyxNQUFNLEdBQUcsTUFBTSxJQUFJLENBQUMsT0FBTyxDQUFDLE9BQU8sQ0FBQyxLQUFLLEVBQUUsSUFBSSxDQUFDLENBQUM7U0FDbEQ7UUFFRCxJQUFJLE1BQU0sR0FBRyxFQUFFLENBQUM7UUFDaEIsSUFBSSxPQUFPLElBQUksTUFBTSxLQUFLLElBQUksRUFBRTtZQUM5QixJQUFJLE9BQU8sS0FBSyxLQUFLLFFBQVEsRUFBRTtnQkFDN0IsTUFBTSxHQUFHLEtBQUssR0FBRyxLQUFLLENBQUM7YUFDeEI7aUJBQU0sSUFBSSxPQUFPLEtBQUssS0FBSyxRQUFRLEVBQUU7Z0JBQ3BDLEtBQUssTUFBTSxRQUFRLElBQUksS0FBSyxFQUFFO29CQUM1QixNQUFNLEdBQUcsS0FBSyxDQUFDLFFBQVEsQ0FBQyxDQUFDO2lCQUMxQjthQUNGO1NBQ0Y7UUFDRCxPQUFPLE1BQU0sQ0FBQyxDQUFDLENBQUMsSUFBSSxDQUFDLFdBQVcsQ0FBQyxJQUFJLE1BQU0sT0FBTyxDQUFDLENBQUMsQ0FBQyxDQUFDLE1BQU0sQ0FBQztJQUMvRCxDQUFDO0lBRUQ7OztPQUdHO0lBQ0gsUUFBUSxDQUFDLEtBQTBCO1FBQ2pDLE1BQU0sZUFBZSxHQUFHLENBQUMsVUFBVSxFQUFFLFdBQVcsRUFBRSxNQUFNLEVBQUUsV0FBVyxDQUFDLENBQUM7UUFDdkUsTUFBTTtRQUNOLE1BQU0sU0FBUyxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FDeEMsS0FBSyxFQUNMLENBQUMsR0FBRyxFQUFFLEVBQUU7WUFDTixPQUFPLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsS0FBSyxDQUFDLEdBQUcsQ0FBQyxDQUFDO1FBQ3ZDLENBQUMsQ0FDRixDQUFDO1FBRUYsVUFBVTtRQUNWLE1BQU0sV0FBVyxHQUFHLElBQUksQ0FBQyxxQkFBcUIsQ0FBQyxLQUFLLENBQUMsQ0FBQztRQUN0RCxXQUFXO1FBQ1gsTUFBTSxTQUFTLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLFNBQVMsRUFBRTtZQUNsRCxHQUFHLGVBQWU7WUFDbEIsWUFBWTtTQUNiLENBQUMsQ0FBQztRQUVILFVBQVU7UUFDVixPQUFPO1lBQ0wsS0FBSyxFQUFFLElBQUksQ0FBQyxVQUFVLENBQUMsU0FBUyxDQUFDO1lBQ2pDLFdBQVc7U0FDWixDQUFDO0lBQ0osQ0FBQztJQUVEOztPQUVHO0lBQ0gsVUFBVSxDQUFDLE1BQVc7UUFDcEIsTUFBTSxFQUFFLFNBQVMsRUFBRSxPQUFPLEVBQUUsR0FBRyxNQUFNLENBQUM7UUFDdEMsSUFBSSxDQUFDLFNBQVMsSUFBSSxDQUFDLE9BQU87WUFBRSxPQUFPLE1BQU0sQ0FBQztRQUMxQyxNQUFNLEtBQUssR0FBRyxTQUFTLElBQUkscUJBQXFCLENBQUM7UUFDakQsTUFBTSxHQUFHLEdBQUcsT0FBTyxJQUFJLElBQUksQ0FBQyxLQUFLLENBQUMsS0FBSyxFQUFFLENBQUMsTUFBTSxDQUFDLG1CQUFtQixDQUFDLENBQUM7UUFDdEUsTUFBTSxDQUFDLFNBQVMsR0FBRztZQUNqQixDQUFDLGNBQUUsQ0FBQyxPQUFPLENBQUMsRUFBRSxDQUFDLEtBQUssRUFBRSxHQUFHLENBQUM7U0FDM0IsQ0FBQztRQUNGLE9BQU8sTUFBTSxDQUFDLFNBQVMsQ0FBQztRQUN4QixPQUFPLE1BQU0sQ0FBQyxPQUFPLENBQUM7UUFDdEIsT0FBTyxNQUFNLENBQUM7SUFDaEIsQ0FBQztJQUVEOzs7T0FHRztJQUNILHFCQUFxQixDQUFDLEtBQUs7UUFDekIsTUFBTSxRQUFRLEdBQUcsS0FBSyxFQUFFLFFBQVEsSUFBSSxJQUFJLENBQUMsUUFBUSxDQUFDO1FBQ2xELE9BQU87WUFDTCxJQUFJLEVBQUUsS0FBSyxFQUFFLElBQUksSUFBSSxJQUFJLENBQUMsSUFBSTtZQUM5QixTQUFTLEVBQUUsTUFBTSxDQUFDLEtBQUssRUFBRSxTQUFTLENBQUMsSUFBSSxJQUFJLENBQUMsU0FBUztZQUNyRCxRQUFRLEVBQUUsTUFBTSxDQUFDLFFBQVEsR0FBRyxHQUFHLENBQUMsQ0FBQyxDQUFDLElBQUksQ0FBQyxXQUFXLENBQUMsQ0FBQyxDQUFDLFFBQVEsQ0FBQztZQUM5RCxTQUFTLEVBQUUsS0FBSyxFQUFFLElBQUksQ0FBQyxDQUFDLENBQUMsS0FBSyxFQUFFLFNBQVMsSUFBSSxFQUFFLENBQUMsQ0FBQyxDQUFDLEVBQUU7U0FDckQsQ0FBQztJQUNKLENBQUM7SUFFRDs7OztPQUlHO0lBQ0gsYUFBYSxDQUFDLEtBQW1CO1FBQy9CLElBQUksQ0FBQyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxRQUFRLENBQUMsS0FBSyxDQUFDO1lBQUUsT0FBTztRQUMvQyxNQUFNLFFBQVEsR0FBRyxNQUFNLENBQUMsSUFBSSxDQUFDLEtBQUssQ0FBQyxDQUFDLE1BQU0sQ0FBQztRQUMzQyxJQUFJLFFBQVEsS0FBSyxDQUFDO1lBQUUsT0FBTyxLQUFLLENBQUM7UUFDakMsTUFBTSxjQUFjLEdBQUcsRUFBRSxDQUFDO1FBQzFCLEtBQUssTUFBTSxRQUFRLElBQUksS0FBSyxFQUFFO1lBQzVCLE1BQU0sSUFBSSxHQUFHLEtBQUssQ0FBQyxRQUFRLENBQUMsQ0FBQztZQUM3QixjQUFjLENBQUMsSUFBSSxDQUFDO2dCQUNsQixDQUFDLFFBQVEsQ0FBQyxFQUFFLElBQUk7YUFDakIsQ0FBQyxDQUFDO1NBQ0o7UUFDRCxPQUFPLEVBQUUsQ0FBQyxjQUFFLENBQUMsRUFBRSxDQUFDLEVBQUUsY0FBYyxFQUFFLENBQUM7SUFDckMsQ0FBQztJQUVELGVBQWUsQ0FBQyxRQUFpQixFQUFFLE1BQW9DO1FBQ3JFLElBQUksQ0FBQyxRQUFRO1lBQUUsT0FBTztRQUN0QixNQUFNLElBQUksR0FBRyxNQUFNLENBQUMsSUFBSSxDQUFDLFFBQVEsQ0FBQyxDQUFDO1FBQ25DLElBQUksQ0FBQyxJQUFJLENBQUMsTUFBTTtZQUFFLE9BQU87UUFDekIsTUFBTSxPQUFPLEdBQUcsRUFBRSxDQUFDO1FBQ25CLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLE1BQU0sQ0FBQyxRQUFRLEVBQUUsQ0FBQyxLQUFLLEVBQUUsR0FBRyxFQUFFLEVBQUU7WUFDaEQsTUFBTSxJQUFJLEdBQUcsUUFBUSxDQUFDLEdBQUcsQ0FBQyxDQUFDO1lBQzNCLE1BQU0sSUFBSSxHQUFHLElBQUksS0FBSyxJQUFJLENBQUMsQ0FBQyxDQUFDLGNBQUUsQ0FBQyxFQUFFLENBQUMsQ0FBQyxDQUFDLGNBQUUsQ0FBQyxHQUFHLENBQUM7WUFDNUMsT0FBTyxDQUFDLEdBQUcsQ0FBQyxHQUFHLEVBQUUsQ0FBQyxJQUFJLENBQUMsRUFBRSxJQUFJLEVBQUUsQ0FBQztRQUNsQyxDQUFDLENBQUMsQ0FBQztRQUNILE9BQU87WUFDTCxHQUFHLElBQUksQ0FBQyxLQUFLLENBQUMsTUFBTSxDQUFDLElBQUksQ0FBQyxNQUFNLEVBQUUsSUFBSSxDQUFDO1lBQ3ZDLEdBQUcsT0FBTztTQUNYLENBQUM7SUFDSixDQUFDO0lBRUQ7Ozs7T0FJRztJQUNILGVBQWUsQ0FBQyxRQUFxQixFQUFFLE1BQTJCO1FBQ2hFLE1BQU0sSUFBSSxHQUFHLE1BQU0sQ0FBQyxJQUFJLENBQUMsUUFBUSxDQUFDLENBQUM7UUFDbkMsTUFBTSxPQUFPLEdBQUcsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsSUFBSSxDQUFDLE1BQU0sRUFBRSxJQUFJLENBQUMsQ0FBQztRQUNyRCxNQUFNLE9BQU8sR0FBRyxFQUFFLENBQUM7UUFDbkIsSUFBSSxDQUFDLEtBQUssQ0FBQyxNQUFNLENBQUMsTUFBTSxDQUFDLE9BQU8sRUFBRSxDQUFDLEtBQWEsRUFBRSxHQUFHLEVBQUUsRUFBRTtZQUN2RCxNQUFNLElBQUksR0FBRyxRQUFRLENBQUMsR0FBRyxDQUFDLENBQUM7WUFDM0IsSUFBSSxJQUFJLEtBQUssVUFBVSxFQUFFO2dCQUN2QixPQUFPLENBQUMsR0FBRyxDQUFDLEdBQUc7b0JBQ2IsQ0FBQyxjQUFFLENBQUMsTUFBTSxDQUFDLEVBQUUsSUFBSSxLQUFLLENBQUMsVUFBVSxDQUFDLEdBQUcsRUFBRSxHQUFHLENBQUMsR0FBRztpQkFDL0MsQ0FBQzthQUNIO2lCQUFNLElBQUksSUFBSSxLQUFLLFNBQVMsRUFBRTtnQkFDN0IsTUFBTSxRQUFRLEdBQUcsS0FBSyxDQUFDLEtBQUssQ0FBQyxHQUFHLENBQUMsQ0FBQztnQkFDbEMsSUFBSSxHQUFHLEdBQUcsRUFBRSxDQUFDO2dCQUNiLFFBQVEsQ0FBQyxPQUFPLENBQUMsQ0FBQyxJQUFJLEVBQUUsRUFBRTtvQkFDeEIsR0FBRyxJQUFJLFFBQVEsSUFBSSxHQUFHLENBQUM7Z0JBQ3pCLENBQUMsQ0FBQyxDQUFDO2dCQUNILE9BQU8sQ0FBQyxHQUFHLENBQUMsR0FBRztvQkFDYixDQUFDLGNBQUUsQ0FBQyxNQUFNLENBQUMsRUFBRSxJQUFJLEdBQUcsS0FBSztpQkFDMUIsQ0FBQzthQUNIO1FBQ0gsQ0FBQyxDQUFDLENBQUM7UUFDSCxPQUFPO1lBQ0wsR0FBRyxJQUFJLENBQUMsS0FBSyxDQUFDLE1BQU0sQ0FBQyxJQUFJLENBQUMsTUFBTSxFQUFFLElBQUksQ0FBQztZQUN2QyxHQUFHLE9BQU87U0FDWCxDQUFDO0lBQ0osQ0FBQztDQUNGO0FBMVFDO0lBQUMsSUFBQSxVQUFHLEdBQUU7O3dDQUNxQjtBQUUzQjtJQUFDLElBQUEsYUFBTSxHQUFFOzhCQUNTLDZCQUFzQjtxREFBQztBQUl6QztJQUFDLElBQUEsYUFBTSxHQUFFOzhCQUNNLDhCQUFhO2tEQUFDO0FBRTdCO0lBQUMsSUFBQSxhQUFNLEVBQUMsVUFBRyxDQUFDOztpREFDQztBQUViO0lBQUMsSUFBQSxhQUFNLEdBQUU7O3dDQUNjO0FBRXZCO0lBQUMsSUFBQSxhQUFNLEdBQUU7OEJBQ1EsZUFBSTswQ0FBQztBQXpCeEIsa0NBaVJDIn0=