export declare class IdDto {
    id: number;
}
export declare class IdsDto {
    ids: number[];
}
export declare class ToggleStatusDto extends IdsDto {
    status: number;
}
export declare class ListDto {
    pageIndex?: number;
    pageSize?: number;
    sort?: 'desc' | 'asc';
    sortField?: string;
}
