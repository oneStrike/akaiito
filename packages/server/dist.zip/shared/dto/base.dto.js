"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.ListDto = exports.ToggleStatusDto = exports.IdsDto = exports.IdDto = void 0;
const validate_1 = require("@midwayjs/validate");
const base_validate_1 = require("../../utils/validate/base.validate");
class IdDto {
}
__decorate([
    (0, validate_1.Rule)(base_validate_1.requiredNumber),
    __metadata("design:type", Number)
], IdDto.prototype, "id", void 0);
exports.IdDto = IdDto;
class IdsDto {
}
__decorate([
    (0, validate_1.Rule)(base_validate_1.requiredNumberArray),
    __metadata("design:type", Array)
], IdsDto.prototype, "ids", void 0);
exports.IdsDto = IdsDto;
class ToggleStatusDto extends IdsDto {
}
__decorate([
    (0, validate_1.Rule)(base_validate_1.requiredNumber),
    __metadata("design:type", Number)
], ToggleStatusDto.prototype, "status", void 0);
exports.ToggleStatusDto = ToggleStatusDto;
class ListDto {
}
__decorate([
    (0, validate_1.Rule)(base_validate_1.validateNumber),
    __metadata("design:type", Number)
], ListDto.prototype, "pageIndex", void 0);
__decorate([
    (0, validate_1.Rule)((0, base_validate_1.givenRange)([100, 1], false)),
    __metadata("design:type", Number)
], ListDto.prototype, "pageSize", void 0);
__decorate([
    (0, validate_1.Rule)((0, base_validate_1.givenValue)(['desc', 'asc'], false)),
    __metadata("design:type", String)
], ListDto.prototype, "sort", void 0);
__decorate([
    (0, validate_1.Rule)(base_validate_1.validateString),
    __metadata("design:type", String)
], ListDto.prototype, "sortField", void 0);
exports.ListDto = ListDto;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYmFzZS5kdG8uanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi9zcmMvc2hhcmVkL2R0by9iYXNlLmR0by50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7QUFBQSxpREFBeUM7QUFDekMsc0VBTzJDO0FBRTNDLE1BQWEsS0FBSztDQUdqQjtBQUZDO0lBQUMsSUFBQSxlQUFJLEVBQUMsOEJBQWMsQ0FBQzs7aUNBQ1g7QUFGWixzQkFHQztBQUVELE1BQWEsTUFBTTtDQUdsQjtBQUZDO0lBQUMsSUFBQSxlQUFJLEVBQUMsbUNBQW1CLENBQUM7O21DQUNiO0FBRmYsd0JBR0M7QUFFRCxNQUFhLGVBQWdCLFNBQVEsTUFBTTtDQUcxQztBQUZDO0lBQUMsSUFBQSxlQUFJLEVBQUMsOEJBQWMsQ0FBQzs7K0NBQ1A7QUFGaEIsMENBR0M7QUFFRCxNQUFhLE9BQU87Q0FZbkI7QUFYQztJQUFDLElBQUEsZUFBSSxFQUFDLDhCQUFjLENBQUM7OzBDQUNIO0FBRWxCO0lBQUMsSUFBQSxlQUFJLEVBQUMsSUFBQSwwQkFBVSxFQUFDLENBQUMsR0FBRyxFQUFFLENBQUMsQ0FBQyxFQUFFLEtBQUssQ0FBQyxDQUFDOzt5Q0FDakI7QUFFakI7SUFBQyxJQUFBLGVBQUksRUFBQyxJQUFBLDBCQUFVLEVBQUMsQ0FBQyxNQUFNLEVBQUUsS0FBSyxDQUFDLEVBQUUsS0FBSyxDQUFDLENBQUM7O3FDQUNwQjtBQUVyQjtJQUFDLElBQUEsZUFBSSxFQUFDLDhCQUFjLENBQUM7OzBDQUNIO0FBWHBCLDBCQVlDIn0=