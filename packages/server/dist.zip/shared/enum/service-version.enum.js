"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ServiceVersionEnum = void 0;
/**
 * 服务版本类型
 * admin 管理端
 * client 客户端
 * open 开放接口
 * common 公共接口
 */
var ServiceVersionEnum;
(function (ServiceVersionEnum) {
    ServiceVersionEnum["ADMIN"] = "admin";
    ServiceVersionEnum["CLIENT"] = "client";
    ServiceVersionEnum["OPEN"] = "open";
    ServiceVersionEnum["COMMON"] = "common";
})(ServiceVersionEnum = exports.ServiceVersionEnum || (exports.ServiceVersionEnum = {}));
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VydmljZS12ZXJzaW9uLmVudW0uanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi9zcmMvc2hhcmVkL2VudW0vc2VydmljZS12ZXJzaW9uLmVudW0udHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUE7Ozs7OztHQU1HO0FBQ0gsSUFBWSxrQkFLWDtBQUxELFdBQVksa0JBQWtCO0lBQzVCLHFDQUFlLENBQUE7SUFDZix1Q0FBaUIsQ0FBQTtJQUNqQixtQ0FBYSxDQUFBO0lBQ2IsdUNBQWlCLENBQUE7QUFDbkIsQ0FBQyxFQUxXLGtCQUFrQixHQUFsQiwwQkFBa0IsS0FBbEIsMEJBQWtCLFFBSzdCIn0=