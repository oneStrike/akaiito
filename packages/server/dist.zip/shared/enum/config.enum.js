"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.ConfigEnum = void 0;
var ConfigEnum;
(function (ConfigEnum) {
    ConfigEnum["JWT"] = "/config/yml/jwt.yml";
    ConfigEnum["STATIC"] = "/config/yml/static.yml";
    ConfigEnum["UPLOAD"] = "/config/yml/upload.yml";
    ConfigEnum["WHITELIST"] = "/config/yml/whitelist.yml";
})(ConfigEnum = exports.ConfigEnum || (exports.ConfigEnum = {}));
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiY29uZmlnLmVudW0uanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi9zcmMvc2hhcmVkL2VudW0vY29uZmlnLmVudW0udHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUEsSUFBWSxVQUtYO0FBTEQsV0FBWSxVQUFVO0lBQ3BCLHlDQUEyQixDQUFBO0lBQzNCLCtDQUFpQyxDQUFBO0lBQ2pDLCtDQUFpQyxDQUFBO0lBQ2pDLHFEQUF1QyxDQUFBO0FBQ3pDLENBQUMsRUFMVyxVQUFVLEdBQVYsa0JBQVUsS0FBVixrQkFBVSxRQUtyQiJ9