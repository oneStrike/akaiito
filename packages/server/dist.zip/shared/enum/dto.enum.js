"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.DtoStatusEnum = void 0;
/**
 * 用于标识状态的dto,多用于Swagger
 * 1 通常表述为 正常
 * 0 通常表述为 非正常
 */
var DtoStatusEnum;
(function (DtoStatusEnum) {
    DtoStatusEnum[DtoStatusEnum["ZERO"] = 0] = "ZERO";
    DtoStatusEnum[DtoStatusEnum["ONE"] = 1] = "ONE";
})(DtoStatusEnum = exports.DtoStatusEnum || (exports.DtoStatusEnum = {}));
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiZHRvLmVudW0uanMiLCJzb3VyY2VSb290IjoiIiwic291cmNlcyI6WyIuLi8uLi8uLi9zcmMvc2hhcmVkL2VudW0vZHRvLmVudW0udHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7O0FBQUE7Ozs7R0FJRztBQUNILElBQVksYUFHWDtBQUhELFdBQVksYUFBYTtJQUN2QixpREFBUSxDQUFBO0lBQ1IsK0NBQU8sQ0FBQTtBQUNULENBQUMsRUFIVyxhQUFhLEdBQWIscUJBQWEsS0FBYixxQkFBYSxRQUd4QiJ9