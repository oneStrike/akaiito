export declare enum ConfigEnum {
    JWT = "/config/yml/jwt.yml",
    STATIC = "/config/yml/static.yml",
    UPLOAD = "/config/yml/upload.yml",
    WHITELIST = "/config/yml/whitelist.yml"
}
