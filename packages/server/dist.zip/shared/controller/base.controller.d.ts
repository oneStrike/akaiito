import { Context } from '@midwayjs/koa';
import Util from '../../utils';
export declare abstract class BaseController {
    protected ctx: Context;
    protected utils: Util;
}
