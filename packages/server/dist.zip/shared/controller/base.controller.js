"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BaseController = void 0;
const core_1 = require("@midwayjs/core");
const utils_1 = require("../../utils");
let BaseController = class BaseController {
};
__decorate([
    (0, core_1.Inject)(),
    __metadata("design:type", Object)
], BaseController.prototype, "ctx", void 0);
__decorate([
    (0, core_1.Inject)(),
    __metadata("design:type", utils_1.default)
], BaseController.prototype, "utils", void 0);
BaseController = __decorate([
    (0, core_1.Controller)()
], BaseController);
exports.BaseController = BaseController;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYmFzZS5jb250cm9sbGVyLmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vc3JjL3NoYXJlZC9jb250cm9sbGVyL2Jhc2UuY29udHJvbGxlci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7Ozs7Ozs7Ozs7QUFBQSx5Q0FBbUQ7QUFFbkQsdUNBQThCO0FBRXZCLElBQWUsY0FBYyxHQUE3QixNQUFlLGNBQWM7Q0FNbkMsQ0FBQTtBQUxDO0lBQUMsSUFBQSxhQUFNLEdBQUU7OzJDQUNhO0FBRXRCO0lBQUMsSUFBQSxhQUFNLEdBQUU7OEJBQ1EsZUFBSTs2Q0FBQTtBQUxELGNBQWM7SUFEbkMsSUFBQSxpQkFBVSxHQUFFO0dBQ1MsY0FBYyxDQU1uQztBQU5xQix3Q0FBYyJ9