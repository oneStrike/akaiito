"use strict";
var __decorate = (this && this.__decorate) || function (decorators, target, key, desc) {
    var c = arguments.length, r = c < 3 ? target : desc === null ? desc = Object.getOwnPropertyDescriptor(target, key) : desc, d;
    if (typeof Reflect === "object" && typeof Reflect.decorate === "function") r = Reflect.decorate(decorators, target, key, desc);
    else for (var i = decorators.length - 1; i >= 0; i--) if (d = decorators[i]) r = (c < 3 ? d(r) : c > 3 ? d(target, key, r) : d(target, key)) || r;
    return c > 3 && r && Object.defineProperty(target, key, r), r;
};
var __metadata = (this && this.__metadata) || function (k, v) {
    if (typeof Reflect === "object" && typeof Reflect.metadata === "function") return Reflect.metadata(k, v);
};
Object.defineProperty(exports, "__esModule", { value: true });
exports.BaseEntity = void 0;
const sequelize_typescript_1 = require("sequelize-typescript");
let BaseEntity = class BaseEntity extends sequelize_typescript_1.Model {
    // @Column({
    //   type: DataType.TINYINT,
    //   comment: '删除标识',
    //   unique: 'deleteFlag',
    //   allowNull: false,
    //   defaultValue: 0,
    // })
    // deleteFlag: number;
    static afterFindHook(instance) {
        if (Array.isArray(instance)) {
            instance.map((item) => {
                delete item.deleteFlag;
                delete item.deletedAt;
                return item;
            });
        }
        else if (instance?.toString() === '[object Object]') {
            delete instance.deleteFlag;
            delete instance.deletedAt;
        }
    }
};
__decorate([
    sequelize_typescript_1.AfterFind,
    __metadata("design:type", Function),
    __metadata("design:paramtypes", [Object]),
    __metadata("design:returntype", void 0)
], BaseEntity, "afterFindHook", null);
BaseEntity = __decorate([
    sequelize_typescript_1.Table
], BaseEntity);
exports.BaseEntity = BaseEntity;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoiYmFzaWMuZW50aXR5LmpzIiwic291cmNlUm9vdCI6IiIsInNvdXJjZXMiOlsiLi4vLi4vLi4vc3JjL3NoYXJlZC9lbnRpdGllcy9iYXNpYy5lbnRpdHkudHMiXSwibmFtZXMiOltdLCJtYXBwaW5ncyI6Ijs7Ozs7Ozs7Ozs7O0FBQUEsK0RBQThEO0FBR3ZELElBQU0sVUFBVSxHQUFoQixNQUFNLFVBQVcsU0FBUSw0QkFBSztJQUNuQyxZQUFZO0lBQ1osNEJBQTRCO0lBQzVCLHFCQUFxQjtJQUNyQiwwQkFBMEI7SUFDMUIsc0JBQXNCO0lBQ3RCLHFCQUFxQjtJQUNyQixLQUFLO0lBQ0wsc0JBQXNCO0lBR2YsQUFBUCxNQUFNLENBQUMsYUFBYSxDQUFDLFFBQVE7UUFDM0IsSUFBSSxLQUFLLENBQUMsT0FBTyxDQUFDLFFBQVEsQ0FBQyxFQUFFO1lBQzNCLFFBQVEsQ0FBQyxHQUFHLENBQUMsQ0FBQyxJQUFJLEVBQUUsRUFBRTtnQkFDcEIsT0FBTyxJQUFJLENBQUMsVUFBVSxDQUFBO2dCQUN0QixPQUFPLElBQUksQ0FBQyxTQUFTLENBQUE7Z0JBQ3JCLE9BQU8sSUFBSSxDQUFBO1lBQ2IsQ0FBQyxDQUFDLENBQUE7U0FDSDthQUFNLElBQUksUUFBUSxFQUFFLFFBQVEsRUFBRSxLQUFLLGlCQUFpQixFQUFFO1lBQ3JELE9BQU8sUUFBUSxDQUFDLFVBQVUsQ0FBQTtZQUMxQixPQUFPLFFBQVEsQ0FBQyxTQUFTLENBQUE7U0FDMUI7SUFDSCxDQUFDO0NBQ0YsQ0FBQTtBQVpRO0lBRE4sZ0NBQVM7Ozs7cUNBWVQ7QUF0QlUsVUFBVTtJQUR0Qiw0QkFBSztHQUNPLFVBQVUsQ0F1QnRCO0FBdkJZLGdDQUFVIn0=