import { Model } from 'sequelize-typescript';
export declare class BaseEntity extends Model {
    static afterFindHook(instance: any): void;
}
