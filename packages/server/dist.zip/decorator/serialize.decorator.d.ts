import { IMethodAspect } from '@midwayjs/decorator';
import { IClassConstructor } from '../types/utils';
export declare const SERIALIZE_KEY = "decorator:serialize";
export declare function Serialize(field?: string, pure?: IClassConstructor): MethodDecorator;
export declare function SerializeHandle(options: any): IMethodAspect;
