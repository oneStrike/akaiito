"use strict";
Object.defineProperty(exports, "__esModule", { value: true });
exports.SerializeHandle = exports.Serialize = exports.SERIALIZE_KEY = void 0;
// src/decorator/logging.decorator.ts
const decorator_1 = require("@midwayjs/decorator");
const utils_1 = require("../utils");
const { lodash } = new utils_1.default();
// 装饰器内部的唯一 id
exports.SERIALIZE_KEY = 'decorator:serialize';
function Serialize(field = '', pure) {
    return (0, decorator_1.createCustomMethodDecorator)(exports.SERIALIZE_KEY, { pure, field });
}
exports.Serialize = Serialize;
function SerializeHandle(options) {
    return {
        afterReturn: async (point, responseData) => {
            let { pure } = options.metadata;
            const { field } = options.metadata;
            if (!pure) {
                pure = point.target.constructor.pure;
            }
            const fields = field?.split('.') ?? [];
            let handleData;
            fields.forEach((item) => {
                if (item) {
                    handleData = handleData ? handleData[item] : responseData[item];
                }
            });
            handleData = handleData || responseData;
            if (lodash.isArray(handleData)) {
                handleData = handleData.map((item) => {
                    return lodash.omit(item, pure);
                });
            }
            else {
                handleData = lodash.omit(handleData, pure);
            }
            if (!field) {
                responseData = handleData;
            }
            else if (fields.length === 1) {
                responseData[field] = handleData;
            }
            return responseData;
        }
    };
}
exports.SerializeHandle = SerializeHandle;
//# sourceMappingURL=data:application/json;base64,eyJ2ZXJzaW9uIjozLCJmaWxlIjoic2VyaWFsaXplLmRlY29yYXRvci5qcyIsInNvdXJjZVJvb3QiOiIiLCJzb3VyY2VzIjpbIi4uLy4uL3NyYy9kZWNvcmF0b3Ivc2VyaWFsaXplLmRlY29yYXRvci50cyJdLCJuYW1lcyI6W10sIm1hcHBpbmdzIjoiOzs7QUFBQSxxQ0FBcUM7QUFDckMsbURBSTRCO0FBRTVCLG9DQUE0QjtBQUU1QixNQUFNLEVBQUUsTUFBTSxFQUFFLEdBQUcsSUFBSSxlQUFLLEVBQUUsQ0FBQTtBQUU5QixjQUFjO0FBQ0QsUUFBQSxhQUFhLEdBQUcscUJBQXFCLENBQUE7QUFFbEQsU0FBZ0IsU0FBUyxDQUN2QixLQUFLLEdBQUcsRUFBRSxFQUNWLElBQXdCO0lBRXhCLE9BQU8sSUFBQSx1Q0FBMkIsRUFBQyxxQkFBYSxFQUFFLEVBQUUsSUFBSSxFQUFFLEtBQUssRUFBRSxDQUFDLENBQUE7QUFDcEUsQ0FBQztBQUxELDhCQUtDO0FBRUQsU0FBZ0IsZUFBZSxDQUFDLE9BQU87SUFDckMsT0FBTztRQUNMLFdBQVcsRUFBRSxLQUFLLEVBQUUsS0FBZ0IsRUFBRSxZQUFZLEVBQUUsRUFBRTtZQUNwRCxJQUFJLEVBQUUsSUFBSSxFQUFFLEdBQUcsT0FBTyxDQUFDLFFBQVEsQ0FBQTtZQUMvQixNQUFNLEVBQUUsS0FBSyxFQUFFLEdBQUcsT0FBTyxDQUFDLFFBQVEsQ0FBQTtZQUNsQyxJQUFJLENBQUMsSUFBSSxFQUFFO2dCQUNULElBQUksR0FBRyxLQUFLLENBQUMsTUFBTSxDQUFDLFdBQVcsQ0FBQyxJQUFJLENBQUE7YUFDckM7WUFFRCxNQUFNLE1BQU0sR0FBRyxLQUFLLEVBQUUsS0FBSyxDQUFDLEdBQUcsQ0FBQyxJQUFJLEVBQUUsQ0FBQTtZQUN0QyxJQUFJLFVBQWUsQ0FBQTtZQUNuQixNQUFNLENBQUMsT0FBTyxDQUFDLENBQUMsSUFBSSxFQUFFLEVBQUU7Z0JBQ3RCLElBQUksSUFBSSxFQUFFO29CQUNSLFVBQVUsR0FBRyxVQUFVLENBQUMsQ0FBQyxDQUFDLFVBQVUsQ0FBQyxJQUFJLENBQUMsQ0FBQyxDQUFDLENBQUMsWUFBWSxDQUFDLElBQUksQ0FBQyxDQUFBO2lCQUNoRTtZQUNILENBQUMsQ0FBQyxDQUFBO1lBQ0YsVUFBVSxHQUFHLFVBQVUsSUFBSSxZQUFZLENBQUE7WUFDdkMsSUFBSSxNQUFNLENBQUMsT0FBTyxDQUFDLFVBQVUsQ0FBQyxFQUFFO2dCQUM5QixVQUFVLEdBQUcsVUFBVSxDQUFDLEdBQUcsQ0FBQyxDQUFDLElBQUksRUFBRSxFQUFFO29CQUNuQyxPQUFPLE1BQU0sQ0FBQyxJQUFJLENBQUMsSUFBSSxFQUFFLElBQUksQ0FBQyxDQUFBO2dCQUNoQyxDQUFDLENBQUMsQ0FBQTthQUNIO2lCQUFNO2dCQUNMLFVBQVUsR0FBRyxNQUFNLENBQUMsSUFBSSxDQUFDLFVBQVUsRUFBRSxJQUFJLENBQUMsQ0FBQTthQUMzQztZQUVELElBQUksQ0FBQyxLQUFLLEVBQUU7Z0JBQ1YsWUFBWSxHQUFHLFVBQVUsQ0FBQTthQUMxQjtpQkFBTSxJQUFJLE1BQU0sQ0FBQyxNQUFNLEtBQUssQ0FBQyxFQUFFO2dCQUM5QixZQUFZLENBQUMsS0FBSyxDQUFDLEdBQUcsVUFBVSxDQUFBO2FBQ2pDO1lBQ0QsT0FBTyxZQUFZLENBQUE7UUFDckIsQ0FBQztLQUNGLENBQUE7QUFDSCxDQUFDO0FBakNELDBDQWlDQyJ9